
from flask import Flask, render_template
import mysql.connector

app = Flask(__name__)

db_config = {
    'user': 'student1',
    'password': 'spsnet',
    'host': 'dbs.spskladno.cz',
    'database': 'vyuka1'
}

def get_db_connection():
    try:
        conn = mysql.connector.connect(**db_config)
        return conn
    except Exception as e:
        print(f"DB Error: {e}")
        return None

@app.route('/')
def index():
    conn = get_db_connection()
    
    leaderboard = []
    top_per_mode = {}
    
    if conn:
        cursor = conn.cursor(dictionary=True)
        
        # 1. Main Leaderboard (Top 10)
        # Tie breaker: Score DESC, Status (Survived > Died) DESC (Survived starts with S, Died with D, so S > D works alphabetically)
        cursor.execute("SELECT * FROM Ubermosh ORDER BY score DESC, status DESC LIMIT 10")
        leaderboard = cursor.fetchall()
        
        # 2. Top 1 per Gamemode
        modes = ['Normal', 'Gunner', 'Reflect']
        for mode in modes:
            cursor.execute("SELECT * FROM Ubermosh WHERE gamemode = %s ORDER BY score DESC, status DESC LIMIT 1", (mode,))
            res = cursor.fetchone()
            if res:
                top_per_mode[mode] = res
                
        cursor.close()
        conn.close()
        
    return render_template('index.html', leaderboard=leaderboard, top_per_mode=top_per_mode)

if __name__ == '__main__':
    app.run(debug=True)

"""Flask web presentation, auth and leaderboard for Zombie Defense."""

from __future__ import annotations

import os
from pathlib import Path
from urllib.parse import urljoin, urlparse

from flask import Flask, flash, redirect, render_template, request, session, url_for

from game import database


def _safe_redirect_target(target: str) -> bool:
    """Allow redirects only to this app host."""
    # Prevent open redirects by allowing only same-host destinations.
    ref_url = urlparse(request.host_url)
    test_url = urlparse(urljoin(request.host_url, target))
    return test_url.scheme in {"http", "https"} and ref_url.netloc == test_url.netloc


def create_app(test_config: dict[str, object] | None = None) -> Flask:
    """Create configured Flask app."""
    app = Flask(__name__, template_folder="templates", static_folder="static")
    app.config.from_mapping(
        SECRET_KEY=os.environ.get("ZOMBIE_WEB_SECRET", "dev-secret-change-me"),
        DATABASE_PATH=str(database.DB_PATH),
    )

    if test_config:
        app.config.update(test_config)

    db_path = Path(str(app.config["DATABASE_PATH"]))
    app.config["DATABASE_PATH"] = str(db_path)
    # Initialize schema once during app startup.
    database.init_db(db_path=db_path)

    def _db_path() -> Path:
        """Return configured database file path as a Path instance."""
        return Path(str(app.config["DATABASE_PATH"]))

    def _current_user() -> dict[str, object] | None:
        """Return the active session payload or None when logged out."""
        if "user_id" not in session:
            return None
        return {
            "user_id": session.get("user_id"),
            "player_id": session.get("player_id"),
            "username": session.get("username"),
            "player_name": session.get("player_name"),
        }

    def _login_required() -> bool:
        """Enforce authentication and flash a login prompt when missing."""
        if "user_id" in session:
            return True
        flash("Nejprve se přihlas.")
        return False

    def _store_session(user_payload: dict[str, str | int]) -> None:
        """Store authenticated user payload in Flask session keys."""
        session["user_id"] = int(user_payload["user_id"])
        session["player_id"] = int(user_payload["player_id"])
        session["username"] = str(user_payload["username"])
        session["player_name"] = str(user_payload["player_name"])

    @app.context_processor
    def inject_navigation_context() -> dict[str, object]:
        """Expose current_user in every rendered template."""
        return {"current_user": _current_user()}

    @app.get("/")
    def index():
        """Render the main landing page."""
        return render_template("index.html", page_title="Hlavní stránka")

    @app.get("/diagramy")
    def diagramy():
        """Render the flowchart and algorithm overview page."""
        return render_template("diagramy.html", page_title="Vývojové diagramy")

    @app.get("/dokumentace")
    def dokumentace():
        """Render complete project documentation page for defense."""
        return render_template("dokumentace.html", page_title="Dokumentace")

    @app.get("/o-hre")
    def o_hre():
        """Render gameplay rules, controls and technical overview page."""
        return render_template("o-hre.html", page_title="O hře")

    @app.get("/o-nas")
    def o_nas():
        """Render project author and presentation information page."""
        return render_template("o-nas.html", page_title="O projektu")

    @app.get("/leaderboard")
    def leaderboard():
        """Render leaderboard page from database results."""
        rows = database.get_leaderboard(30, db_path=_db_path())
        return render_template("leaderboard.html", page_title="Žebříček", leaderboard=rows)

    @app.route("/register", methods=["GET", "POST"])
    def register():
        """Render registration form and create a user on submit."""
        if request.method == "GET":
            return render_template("register.html", page_title="Registrace")

        username = request.form.get("username", "").strip()
        email = request.form.get("email", "").strip()
        password = request.form.get("password", "")

        if not username:
            flash("Uživatelské jméno je povinné.")
            return render_template("register.html", page_title="Registrace")
        if not password:
            flash("Heslo je povinné.")
            return render_template("register.html", page_title="Registrace")

        try:
            # Surface DB/user validation errors as flash messages.
            database.create_web_user(
                username=username,
                password=password,
                email=email or None,
                db_path=_db_path(),
            )
        except ValueError as exc:
            flash(str(exc))
            return render_template("register.html", page_title="Registrace")

        user = database.authenticate_web_user(username, password, db_path=_db_path())
        if user is None:
            flash("Registrace proběhla, ale nelze ověřit přihlášení.")
            return redirect(url_for("login"))

        _store_session(user)
        flash("Registrace proběhla úspěšně.")
        return redirect(url_for("profil"))

    @app.route("/login", methods=["GET", "POST"])
    def login():
        """Render login form and authenticate submitted credentials."""
        next_target = request.args.get("next", "").strip()

        if request.method == "GET":
            return render_template("login.html", page_title="Přihlášení", next_target=next_target)

        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")
        next_target = request.form.get("next_target", "").strip()

        user = database.authenticate_web_user(username, password, db_path=_db_path())
        if user is None:
            flash("Neplatné přihlašovací údaje.")
            return render_template("login.html", page_title="Přihlášení", next_target=next_target)

        _store_session(user)
        flash("Přihlášení proběhlo úspěšně.")

        # Respect safe 'next' target for post-login navigation.
        if next_target and _safe_redirect_target(next_target):
            return redirect(next_target)
        return redirect(url_for("profil"))

    @app.post("/logout")
    def logout():
        """Clear session state and redirect to the home page."""
        session.clear()
        flash("Byl jsi odhlášen.")
        return redirect(url_for("index"))

    @app.get("/profil")
    def profil():
        """Render authenticated player profile with recent match history."""
        if not _login_required():
            return redirect(url_for("login", next=request.path))

        player_id = int(session["player_id"])
        matches = database.get_player_matches(player_id, limit=20, db_path=_db_path())
        best_score = max((int(row["skore"]) for row in matches), default=0)
        total_games = len(matches)
        return render_template(
            "profil.html",
            page_title="Profil",
            matches=matches,
            best_score=best_score,
            total_games=total_games,
        )

    return app


if __name__ == "__main__":
    create_app().run(debug=True)

@echo off
setlocal

set "ROOT=%~dp0"
cd /d "%ROOT%"

set "SCHOOL_PYTHON=G:\win32app\Portable Python-3.13.3 x64\python.exe"
if exist "%ROOT%venv\Scripts\python.exe" (
  echo [INFO] Running school PC setup...
  call "%ROOT%setup_school_pc.bat"
  if errorlevel 1 (
    echo [ERROR] School PC setup failed.
    pause
    exit /b 1
  )
) else (
  if exist "%SCHOOL_PYTHON%" (
    echo [INFO] Running school PC setup...
    call "%ROOT%setup_school_pc.bat"
    if errorlevel 1 (
      echo [ERROR] School PC setup failed.
      pause
      exit /b 1
    )
  )
)

set "PYEXE="
if defined ZOMBIE_DEFENSE_PYTHON (
  set "PYEXE=%ZOMBIE_DEFENSE_PYTHON%"
)

if defined PYEXE (
  if not exist "%PYEXE%" (
    echo [WARN] ZOMBIE_DEFENSE_PYTHON points to a missing file:
    echo        %PYEXE%
    set "PYEXE="
  )
)

if not defined PYEXE if exist "%ROOT%venv\Scripts\python.exe" (
  set "PYEXE=%ROOT%venv\Scripts\python.exe"
)

if not defined PYEXE if exist "%ROOT%\.venv\Scripts\python.exe" (
  set "PYEXE=%ROOT%\.venv\Scripts\python.exe"
)

if not defined PYEXE if exist "%ROOT%python_path.txt" (
  for /f "usebackq delims=" %%p in ("%ROOT%python_path.txt") do (
    if not defined PYEXE if not "%%~p"=="" set "PYEXE=%%~p"
  )
)

if defined PYEXE (
  if not exist "%PYEXE%" (
    echo [WARN] Saved Python path in python_path.txt was not found:
    echo        %PYEXE%
    set "PYEXE="
  )
)

if not defined PYEXE (
  where python >nul 2>nul
  if not errorlevel 1 set "PYEXE=python"
)

if not defined PYEXE (
  where py >nul 2>nul
  if not errorlevel 1 set "PYEXE=py"
)

if not defined PYEXE (
  echo [INFO] Python was not found automatically.
  echo [INFO] Enter full path to python.exe ^(local or school network share^).
  set /p "MANUAL_PY=Python path: "
  if "%MANUAL_PY%"=="" (
    echo [ERROR] Python path was not provided.
    pause
    exit /b 1
  )
  if not exist "%MANUAL_PY%" (
    echo [ERROR] File not found:
    echo        %MANUAL_PY%
    pause
    exit /b 1
  )
  set "PYEXE=%MANUAL_PY%"
  >"%ROOT%python_path.txt" echo %PYEXE%
  echo [INFO] Saved Python path to python_path.txt
)

"%PYEXE%" -c "import sys; print(sys.version)" >nul 2>nul
if errorlevel 1 (
  echo [ERROR] Selected Python launcher is not runnable:
  echo        %PYEXE%
  pause
  exit /b 1
)

echo [INFO] Starting game...
echo [INFO] Project root: %ROOT%
echo.
"%PYEXE%" game\main.py

if errorlevel 1 (
  echo.
  echo [ERROR] Game exited with an error.
  pause
  exit /b 1
)

echo.
echo [INFO] Game closed.
pause
exit /b 0

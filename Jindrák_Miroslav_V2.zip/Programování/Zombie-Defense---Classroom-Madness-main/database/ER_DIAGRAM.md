# ER diagram

```mermaid
erDiagram
    PLAYERS ||--|| USERS : "1:1 web account"
    PLAYERS ||--o{ MATCHES : "1:N"
    MATCHES ||--o{ MATCH_WEAPONS : "1:N"
    WEAPONS ||--o{ MATCH_WEAPONS : "1:N"
    PLAYERS ||--o{ PLAYER_SKINS : "1:N"
    SKINS ||--o{ PLAYER_SKINS : "1:N"

    PLAYERS {
        int id PK
        string name UNIQUE NOT_NULL
        string email UNIQUE
        int coins DEFAULT_0
        datetime registered_at
    }

    USERS {
        int id PK
        int player_id FK UNIQUE NOT_NULL
        string username UNIQUE NOT_NULL
        string password_hash NOT_NULL
        datetime created_at
    }

    MATCHES {
        int id PK
        int player_id FK NOT_NULL
        int score DEFAULT_0
        float duration_seconds DEFAULT_0
        datetime match_date
    }

    WEAPONS {
        int id PK
        string name UNIQUE NOT_NULL
        int damage DEFAULT_10
        string rarity DEFAULT_common
    }

    MATCH_WEAPONS {
        int match_id PK, FK
        int weapon_id PK, FK
        int kills_with_weapon DEFAULT_0
    }

    SKINS {
        int id PK
        string skin_key UNIQUE NOT_NULL
        string display_name NOT_NULL
        int price_coins DEFAULT_0
        string primary_color NOT_NULL
        string secondary_color NOT_NULL
        bool is_default DEFAULT_0
    }

    PLAYER_SKINS {
        int player_id PK, FK
        int skin_id PK, FK
        datetime unlocked_at
        bool is_selected DEFAULT_0
    }
```

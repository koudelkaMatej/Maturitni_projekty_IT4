-- 1) Zakladni leaderboard (JOIN + ORDER BY)
SELECT
    p.name AS jmeno,
    m.score AS skore,
    m.duration_seconds AS doba,
    m.match_date AS datum
FROM matches m
JOIN players p ON p.id = m.player_id
ORDER BY m.score DESC, m.match_date DESC
LIMIT 20;

-- 2) Filtrovani podle minima score a casoveho intervalu
-- Parametry: ?1 = min score, ?2 = datum od, ?3 = datum do
SELECT
    p.name AS jmeno,
    m.score AS skore,
    m.match_date AS datum
FROM matches m
JOIN players p ON p.id = m.player_id
WHERE m.score >= ?1
  AND m.match_date BETWEEN ?2 AND ?3
ORDER BY m.match_date DESC;

-- 3) Vyhledavani podle casti jmena hrace
-- Parametr: ?1 = '%ali%'
SELECT
    p.name AS jmeno,
    m.score AS skore,
    m.match_date AS datum
FROM players p
JOIN matches m ON m.player_id = p.id
WHERE LOWER(p.name) LIKE LOWER(?1)
ORDER BY m.score DESC;

-- 4) Agregace nad M:N vazbou (match_weapons)
SELECT
    p.name AS jmeno,
    w.name AS zbran,
    SUM(mw.kills_with_weapon) AS zabiti_celkem,
    COUNT(DISTINCT m.id) AS odehrane_zapasy
FROM match_weapons mw
JOIN matches m ON m.id = mw.match_id
JOIN players p ON p.id = m.player_id
JOIN weapons w ON w.id = mw.weapon_id
GROUP BY p.name, w.name
ORDER BY zabiti_celkem DESC, odehrane_zapasy DESC;

-- 5) UPDATE - navyseni minci hrace
-- Parametry: ?1 = bonus mince, ?2 = player_id
UPDATE players
SET coins = coins + ?1
WHERE id = ?2;

-- 6) DELETE - odstraneni testovaciho zapasu
-- Parametr: ?1 = match_id
DELETE FROM matches
WHERE id = ?1;

INSERT INTO players (name, email, coins) VALUES
('Alice', 'alice@school.local', 250),
('Bob', 'bob@school.local', 120),
('Cyril', 'cyril@school.local', 80)
ON CONFLICT(name) DO NOTHING;

INSERT INTO users (player_id, username, password_hash) VALUES
((SELECT id FROM players WHERE name = 'Alice'), 'alice', 'scrypt:32768:8:1$DVP85aEtZ1FmetMS$ea66034b413b6d61c61fcad6485d8e2757d837be3b528202baa614bead29313002945051421a1efcde1326edd4d25056445c26c98b96d11e0648fb1cfd034f45'),
((SELECT id FROM players WHERE name = 'Bob'), 'bob', 'scrypt:32768:8:1$itd5PGX52wH2KU1K$2b726c145452faa939d008ec0d7d4e945e4008212135eb653114e3caf8689784bf237f50525f524d77f379111a6b39c3ec8362c8d2daec580f53ff2d9af711d4'),
((SELECT id FROM players WHERE name = 'Cyril'), 'cyril', 'scrypt:32768:8:1$EnRXPzZttMxmDJzf$e7de7bb82aa3deee7d1e5802c85641efc3f179c6fb8cc423e717555234d6f3d2cd26c40a65439379a3a686a0bf41e1a981d031d38daf34b36a0054485d4480d0')
ON CONFLICT(username) DO NOTHING;

INSERT INTO weapons (name, damage, rarity) VALUES
('Pistol', 12, 'common'),
('Shotgun', 25, 'rare'),
('Laser', 35, 'epic')
ON CONFLICT(name) DO NOTHING;

INSERT INTO skins (skin_key, display_name, price_coins, primary_color, secondary_color, is_default) VALUES
('classic', 'Classic', 0, '70,160,255', '220,240,255', 1),
('ember', 'Ember', 120, '255,145,80', '255,220,180', 0),
('toxic', 'Toxic', 180, '90,230,120', '210,255,220', 0),
('frost', 'Frost', 260, '110,180,255', '220,245,255', 0)
ON CONFLICT(skin_key) DO NOTHING;

INSERT OR IGNORE INTO player_skins (player_id, skin_id, is_selected)
SELECT p.id, s.id, CASE WHEN s.skin_key = 'classic' THEN 1 ELSE 0 END
FROM players p
JOIN skins s ON s.skin_key = 'classic';

INSERT INTO matches (player_id, score, duration_seconds, match_date) VALUES
((SELECT id FROM players WHERE name = 'Alice'), 15, 102.5, '2026-01-10 14:00:00'),
((SELECT id FROM players WHERE name = 'Bob'), 22, 140.0, '2026-01-11 14:00:00'),
((SELECT id FROM players WHERE name = 'Alice'), 30, 180.3, '2026-01-12 14:00:00');

INSERT INTO match_weapons (match_id, weapon_id, kills_with_weapon) VALUES
(1, 1, 8),
(1, 2, 7),
(2, 2, 12),
(2, 3, 10),
(3, 3, 30);

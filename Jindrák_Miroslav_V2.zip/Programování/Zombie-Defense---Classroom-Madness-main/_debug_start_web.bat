@echo on
setlocal

set "ROOT=%~dp0"
cd /d "%ROOT%"

set "PYEXE="
if defined ZOMBIE_DEFENSE_PYTHON (
  set "PYEXE=%ZOMBIE_DEFENSE_PYTHON%"
)

if defined PYEXE (
  if not exist "%PYEXE%" (
    echo [WARN] ZOMBIE_DEFENSE_PYTHON points to a missing file:
    echo        %PYEXE%
    set "PYEXE="
  )
)

if not defined PYEXE if exist "%ROOT%venv\Scripts\python.exe" (
  set "PYEXE=%ROOT%venv\Scripts\python.exe"
)

if not defined PYEXE if exist "%ROOT%\.venv\Scripts\python.exe" (
  set "PYEXE=%ROOT%\.venv\Scripts\python.exe"
)

if not defined PYEXE if exist "%ROOT%python_path.txt" (
  for /f "usebackq delims=" %%p in ("%ROOT%python_path.txt") do (
    if not defined PYEXE if not "%%~p"=="" set "PYEXE=%%~p"
  )
)

if defined PYEXE (
  if not exist "%PYEXE%" (
    echo [WARN] Saved Python path in python_path.txt was not found:
    echo        %PYEXE%
    set "PYEXE="
  )
)

if not defined PYEXE (
  where python >nul 2>nul
  if not errorlevel 1 set "PYEXE=python"
)

if not defined PYEXE (
  where py >nul 2>nul
  if not errorlevel 1 set "PYEXE=py"
)

if not defined PYEXE (
  echo [INFO] Python was not found automatically.
  echo [INFO] Enter full path to python.exe ^(local or school network share^).
  set /p "MANUAL_PY=Python path: "
  if "%MANUAL_PY%"=="" (
    echo [ERROR] Python path was not provided.
    pause
    exit /b 1
  )
  if not exist "%MANUAL_PY%" (
    echo [ERROR] File not found:
    echo        %MANUAL_PY%
    pause
    exit /b 1
  )
  set "PYEXE=%MANUAL_PY%"
  >"%ROOT%python_path.txt" echo %PYEXE%
  echo [INFO] Saved Python path to python_path.txt
)

"%PYEXE%" -c "import sys; print(sys.version)" >nul 2>nul
if errorlevel 1 (
  echo [ERROR] Selected Python launcher is not runnable:
  echo        %PYEXE%
  pause
  exit /b 1
)

echo [INFO] Using Python launcher: %PYEXE%
"%PYEXE%" -c "import flask" >nul 2>nul
if errorlevel 1 (
  echo [ERROR] Flask is missing in this Python environment.
  echo [HINT] Run install_requirements.bat first.
  pause
  exit /b 1
)

echo [INFO] Starting web server...
echo [INFO] Project root: %ROOT%
echo [INFO] Open in browser: http://127.0.0.1:5000
echo.
"%PYEXE%" -u -m web.backend_app

if errorlevel 1 (
  echo.
  echo [ERROR] Web server exited with an error.
  pause
  exit /b 1
)

echo.
echo [INFO] Web server stopped.
pause
exit /b 0

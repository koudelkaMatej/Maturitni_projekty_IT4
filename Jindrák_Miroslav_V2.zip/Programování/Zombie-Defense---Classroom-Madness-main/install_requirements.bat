@echo off
setlocal

set "ROOT=%~dp0"
cd /d "%ROOT%"

set "PYEXE="
if defined ZOMBIE_DEFENSE_PYTHON (
  set "PYEXE=%ZOMBIE_DEFENSE_PYTHON%"
)

if defined PYEXE (
  if not exist "%PYEXE%" (
    echo [WARN] ZOMBIE_DEFENSE_PYTHON points to a missing file:
    echo        %PYEXE%
    set "PYEXE="
  )
)

if not defined PYEXE if exist "%ROOT%venv\Scripts\python.exe" (
  set "PYEXE=%ROOT%venv\Scripts\python.exe"
)

if not defined PYEXE if exist "%ROOT%\.venv\Scripts\python.exe" (
  set "PYEXE=%ROOT%\.venv\Scripts\python.exe"
)

if not defined PYEXE if exist "%ROOT%python_path.txt" (
  for /f "usebackq delims=" %%p in ("%ROOT%python_path.txt") do (
    if not defined PYEXE if not "%%~p"=="" set "PYEXE=%%~p"
  )
)

if defined PYEXE (
  if not exist "%PYEXE%" (
    echo [WARN] Saved Python path in python_path.txt was not found:
    echo        %PYEXE%
    set "PYEXE="
  )
)

if not defined PYEXE (
  where python >nul 2>nul
  if not errorlevel 1 set "PYEXE=python"
)

if not defined PYEXE (
  where py >nul 2>nul
  if not errorlevel 1 set "PYEXE=py"
)

if not defined PYEXE (
  echo [INFO] Python was not found automatically.
  echo [INFO] Enter full path to python.exe ^(local or school network share^).
  set /p "MANUAL_PY=Python path: "
  if "%MANUAL_PY%"=="" (
    echo [ERROR] Python path was not provided.
    pause
    exit /b 1
  )
  if not exist "%MANUAL_PY%" (
    echo [ERROR] File not found:
    echo        %MANUAL_PY%
    pause
    exit /b 1
  )
  set "PYEXE=%MANUAL_PY%"
  >"%ROOT%python_path.txt" echo %PYEXE%
  echo [INFO] Saved Python path to python_path.txt
)

"%PYEXE%" -c "import sys; print(sys.version)" >nul 2>nul
if errorlevel 1 (
  echo [ERROR] Selected Python launcher is not runnable:
  echo        %PYEXE%
  pause
  exit /b 1
)

echo [INFO] Using Python launcher: %PYEXE%
for /f "delims=" %%v in ('^""%PYEXE%" -c "import sys; print(str(sys.version_info[0]) + '.' + str(sys.version_info[1]))"^"') do set "PYVER=%%v"
echo [INFO] Detected Python version: %PYVER%

for /f "tokens=1,2 delims=." %%a in ("%PYVER%") do (
  set "PYMAJOR=%%a"
  set "PYMINOR=%%b"
)

if "%PYMAJOR%"=="" (
  echo [ERROR] Cannot parse Python version.
  pause
  exit /b 1
)

if %PYMAJOR% LSS 3 (
  echo [ERROR] Python 2 is not supported. Use Python 3.7+.
  pause
  exit /b 1
)

if %PYMAJOR% EQU 3 if %PYMINOR% LSS 7 (
  echo [ERROR] Python %PYVER% is too old. Minimum supported version is 3.7.
  pause
  exit /b 1
)

set "REQ_FILE=requirements.txt"
set "PYTAG=%PYVER:.=%"
set "VERSION_FILE=requirements_py%PYTAG%.txt"
if exist "%VERSION_FILE%" (
  echo [INFO] Using version-specific requirements: %VERSION_FILE%
  set "REQ_FILE=%VERSION_FILE%"
)

if "%REQ_FILE%"=="requirements.txt" (
  echo [INFO] Using default requirements.txt
)

"%PYEXE%" -m pip --version >nul 2>nul
if errorlevel 1 (
  echo [ERROR] pip is not available in this Python environment.
  echo [HINT] Ask school admin/teacher for Python interpreter with pip enabled.
  pause
  exit /b 1
)

"%PYEXE%" -m pip install -r %REQ_FILE%
if errorlevel 1 (
  echo [ERROR] Dependency installation failed.
  pause
  exit /b 1
)

echo [OK] Requirements installed.
pause
exit /b 0

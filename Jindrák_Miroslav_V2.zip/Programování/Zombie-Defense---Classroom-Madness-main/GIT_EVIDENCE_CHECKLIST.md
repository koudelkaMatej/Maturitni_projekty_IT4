# Git Evidence Checklist

This file is for the non-code requirements that must be demonstrably visible to the teacher.

## 1) Repository Basics

1. Ensure local repository exists:
   - `git status`
2. Ensure default branch is `main`:
   - `git branch --show-current`
3. Add remote origin:
   - `git remote add origin <YOUR_REMOTE_URL>`
4. Push:
   - `git push -u origin main`

## 2) Teacher Access

1. Add teacher account as collaborator (or confirm public repository visibility).
2. Capture screenshot from repository settings:
   - Collaborators/member access page
   - Repository visibility page (public/private)

## 3) Activity Evidence

1. Show commit log:
   - `git log --oneline --decorate --graph -n 30`
2. Show file contribution trail:
   - `git log --name-only --oneline -n 30`
3. Keep at least one screenshot/PDF export for submission packet.

## 4) Submission Metadata (fill before final hand-in)

- Repository URL: `<FILL_ME>`
- Teacher account added: `<FILL_ME>`
- Visibility (public/private): `<FILL_ME>`
- Last commit hash used for submission: `<FILL_ME>`

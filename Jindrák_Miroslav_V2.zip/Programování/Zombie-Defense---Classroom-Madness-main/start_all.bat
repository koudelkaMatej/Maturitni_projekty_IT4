@echo off
setlocal

set "ROOT=%~dp0"
set "SCHOOL_PYTHON=G:\win32app\Portable Python-3.13.3 x64\python.exe"

set "HAS_PY="
if exist "%ROOT%python_path.txt" set "HAS_PY=1"
if not defined HAS_PY if exist "%ROOT%\.venv\Scripts\python.exe" set "HAS_PY=1"
if not defined HAS_PY if exist "%ROOT%venv\Scripts\python.exe" set "HAS_PY=1"
if not defined HAS_PY (
  where python >nul 2>nul
  if not errorlevel 1 set "HAS_PY=1"
)
if not defined HAS_PY (
  where py >nul 2>nul
  if not errorlevel 1 set "HAS_PY=1"
)

if not defined HAS_PY (
  echo [INFO] Python interpreter not detected.
  echo [INFO] Running one-time interpreter setup...
  call "%ROOT%set_python_path.bat"
  if errorlevel 1 (
    echo [ERROR] Interpreter setup failed.
    pause
    exit /b 1
  )
)

if exist "%ROOT%venv\Scripts\python.exe" (
  echo [INFO] Running school PC setup...
  call "%ROOT%setup_school_pc.bat"
  if errorlevel 1 (
    echo [ERROR] School PC setup failed.
    pause
    exit /b 1
  )
) else (
  if exist "%SCHOOL_PYTHON%" (
    echo [INFO] Running school PC setup...
    call "%ROOT%setup_school_pc.bat"
    if errorlevel 1 (
      echo [ERROR] School PC setup failed.
      pause
      exit /b 1
    )
  ) else (
    echo [INFO] School PC setup skipped ^(G: path not detected and venv not present^).
  )
)

echo [INFO] Opening web server and game in separate windows...
start "Zombie Defense - Web" "%ROOT%start_web.bat"
ping 127.0.0.1 -n 6 >nul
start "" "http://127.0.0.1:5000"
start "Zombie Defense - Game" "%ROOT%start_game.bat"

exit /b 0

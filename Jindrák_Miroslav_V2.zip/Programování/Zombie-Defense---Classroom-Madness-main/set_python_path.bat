@echo off
setlocal

set "ROOT=%~dp0"
cd /d "%ROOT%"

echo [INFO] Configure Python interpreter path for this project.
echo [INFO] Example: \\school-server\python\python.exe
echo.

if exist "%ROOT%python_path.txt" (
  for /f "usebackq delims=" %%p in ("%ROOT%python_path.txt") do (
    if not defined CURRENT_PY if not "%%~p"=="" set "CURRENT_PY=%%~p"
  )
  if defined CURRENT_PY (
    echo [INFO] Current saved path:
    echo        %CURRENT_PY%
    echo.
  )
)

set /p "MANUAL_PY=Enter full path to python.exe: "
if "%MANUAL_PY%"=="" (
  echo [ERROR] No path entered.
  pause
  exit /b 1
)

if not exist "%MANUAL_PY%" (
  echo [ERROR] File not found:
  echo        %MANUAL_PY%
  pause
  exit /b 1
)

"%MANUAL_PY%" -c "import sys; print(sys.version)" >nul 2>nul
if errorlevel 1 (
  echo [ERROR] Selected file is not a runnable Python interpreter.
  pause
  exit /b 1
)

>"%ROOT%python_path.txt" echo %MANUAL_PY%
echo [OK] Saved to python_path.txt
echo [INFO] You can now run start_web.bat / start_game.bat / start_all.bat
pause
exit /b 0

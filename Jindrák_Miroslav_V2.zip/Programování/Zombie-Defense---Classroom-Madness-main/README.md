# Zombie Defense - Classroom Madness

Top-down zombie hra v Pythonu (Pygame) + Flask web prezentace + SQLite databaze.

## Instalace

```bash
python -m pip install -r requirements.txt
```

### Windows rychly start (funguje odkudkoliv)

- Pokud Python neni lokalne nainstalovany (typicky skolni sit), spust `set_python_path.bat` a vloz plnou cestu k `python.exe` na sitovem disku.
- Pro skolni PC je novy `setup_school_pc.bat` (vytvori `venv` pres `G:\win32app\Portable Python-3.13.3 x64\python.exe`, nastavi `ExecutionPolicy`, aktivuje `venv`).
- Dvojklik `install_requirements.bat` (jen poprve).
- Dvojklik `start_web.bat` pro web.
- Dvojklik `start_game.bat` pro hru.
- Volitelne: `start_all.bat` spusti web i hru naraz ve 2 oknech.
- `start_all.bat` pri prvnim spusteni sam zavola nastaveni interpreteru, pokud Python nenajde.
- `start_all.bat` navic pred spustenim webu/hry automaticky zavola `setup_school_pc.bat`, pokud detekuje skolni Python na `G:` nebo existujici `venv`.

Tyto skripty pouzivaji cestu ke slozce, ve ktere lezi (`%~dp0`), takze funguji i kdyz projekt presunes jinam (jiny disk, jina slozka, skolni PC).
Pokud web nenabehne, zkontroluj okno `Zombie Defense - Web` - vypise presny duvod (napr. chybejici Flask).
Skript `install_requirements.bat` automaticky detekuje verzi Pythonu a pokud existuje odpovidajici soubor `requirements_pyXY.txt`, pouzije ho (napr. `requirements_py37.txt`, `requirements_py38.txt`, `requirements_py310.txt`). Jinak pouzije vychozi `requirements.txt`.
Ulozena cesta k interpreteru je v `python_path.txt` (lokalni konfigurace, necommitovat). Jednorazove ji lze prebit i promennou `ZOMBIE_DEFENSE_PYTHON`.

## Spusteni

### Hra

```bash
python game/main.py
```

### Web

```bash
python -m web.backend_app
```

Potom otevri `http://127.0.0.1:5000`.
Webove stranky oteviraj pres Flask routy v prohlizeci. Neotevirej soubory z `web/templates` primo (jinak uvidis jen raw Jinja sablony typu `{% ... %}`).

### Testy

```bash
python -m pytest -q
```

## Web routy

- `GET /` - hlavni stranka projektu
- `GET /diagramy` - vyvojove diagramy algoritmu
- `GET /o-hre` - popis mechanik a technicke casti
- `GET /o-nas` - informace o projektu
- `GET /leaderboard` - zebricek ulozeny v DB
- `GET, POST /register` - registrace (username + heslo)
- `GET, POST /login` - prihlaseni
- `POST /logout` - odhlaseni
- `GET /profil` - historie vysledku prihlaseneho hrace

## Databazove soubory

- `database/schema.sql` - CREATE tabulky a omezeni
- `database/seed.sql` - ukazkova data
- `database/queries.sql` - SELECT/JOIN/GROUP BY/WHERE/ORDER BY + UPDATE/DELETE priklady
- `database/ER_DIAGRAM.md` - ER diagram vztahu

## Architektura a propojeni casti

- Hra (`game/main.py`) zapisuje vysledky do SQLite pres `game/database.py`.
- Web (`web/backend_app.py`) cte stejnou DB pro leaderboard i profil hrace.
- Fallback (`game/storage.py`) uklada JSON zaznam, kdyz DB neni dostupna.
- SQL vrstva je dolozena schema + seed + query skripty.

## Dulezite checklisty pro obhajobu

- `SOLO_PROJECT_CHECKLIST.md` - mapovani skolnich pozadavku na dukazy v projektu.
- `GIT_EVIDENCE_CHECKLIST.md` - kroky a dukazy pro repozitar, pristupy a historii commitu.

## Splneni pozadavku (samostatny projekt)

- Web prezentace: vice stranek s jednotnym CSS a nav listou.
- Hra: herni smycka, menu, ovladani klavesnice/mysi, uklada vysledky.
- Databaze: 1:N (`players -> matches`) i M:N (`matches <-> weapons` pres `match_weapons`).
- Login/registrace: web ucet je svazany s profilem hrace (`users.player_id`).
- Propojeni casti: hra uklada vysledky, web je ihned zobrazuje v leaderboardu/profilu.
- Automatizovane testy: herni + databazove + web testy.

## Poznamka k normalizaci (BCNF)

Schema je navrzene tak, aby netrivialni zavislosti byly urceny klici:

- `players`, `users`, `weapons`, `matches`, `skins` maji jednoznacne PK a atributy zavisi na PK.
- M:N vazby jsou rozdelene do spojovacich tabulek `match_weapons` a `player_skins`.
- Vztah web identity je oddelen do `users` (1:1 k `players`), aby se autentizace nemichala s hernimi statistikami.

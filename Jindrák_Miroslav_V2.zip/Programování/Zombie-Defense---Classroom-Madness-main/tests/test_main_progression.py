from types import SimpleNamespace

import pygame

from game.main import ARMORY_UPGRADE_DEFINITIONS, NO_HIT_STREAK_THRESHOLD, RUN_PERK_DEFINITIONS, Game, GameState
from game.enemy import BossArchetype, Zombie, ZombieType
from game.player import Player
from game.projectile import Projectile
from game.ui import (
    get_armory_button_rect,
    get_armory_row_rect,
    get_armory_tab_rects,
    get_menu_option_rects,
    get_mutation_button_rect,
    get_perk_card_rects,
    get_visual_mode_option_rects,
)
from game.weapons import ProjectileSpawn, WeaponInventory


def test_armory_purchase_success_insufficient_and_owned_paths():
    game = Game.__new__(Game)
    game.weapon_inventory = WeaponInventory()
    game.wave_manager = SimpleNamespace(current_wave=5)
    game.run_scrap = 1000
    game.owned_run_weapons = set()
    game.armory_selection = 1
    game.armory_message = ""
    game.armory_message_timer = 0.0

    assert Game.try_buy_armory_selection(game) is True
    assert game.run_scrap == 480
    assert "burst_rifle" in game.owned_run_weapons
    assert game.weapon_inventory.active_state is not None
    assert game.weapon_inventory.active_state.spec_key == "burst_rifle"

    scrap_before = game.run_scrap
    assert Game.try_buy_armory_selection(game) is True
    assert game.run_scrap == scrap_before
    assert game.armory_message == "Equipped Burst Rifle"

    game.armory_selection = 0
    game.run_scrap = 20
    game.owned_run_weapons = set()
    assert Game.try_buy_armory_selection(game) is False
    assert game.armory_message == "Not enough scrap"


def test_armory_ammo_refill_spends_scrap_and_restores_active_weapon():
    game = Game.__new__(Game)
    game.weapon_inventory = WeaponInventory()
    game.weapon_inventory.buy_weapon("burst_rifle")
    state = game.weapon_inventory.active_state
    assert state is not None
    state.ammo_in_mag = 1
    state.reserve_ammo = 5
    game.wave_manager = SimpleNamespace(current_wave=5)
    game.run_scrap = 400
    game.owned_run_weapons = {"burst_rifle"}
    game.armory_selection = 4
    game.armory_message = ""
    game.armory_message_timer = 0.0

    assert Game.try_buy_armory_selection(game) is True
    assert game.run_scrap == 114
    assert state.ammo_in_mag == 24
    assert state.reserve_ammo == 144
    assert game.armory_message == "Ammo restocked"


def test_armory_rejects_locked_weapon_before_unlock_wave():
    game = Game.__new__(Game)
    game.weapon_inventory = WeaponInventory()
    game.wave_manager = SimpleNamespace(current_wave=4)
    game.run_scrap = 999
    game.owned_run_weapons = set()
    game.armory_selection = 2
    game.armory_message = ""
    game.armory_message_timer = 0.0

    assert Game.try_buy_armory_selection(game) is False
    assert game.armory_message == "Unlocks at wave 5"


def test_perk_offer_triggers_every_two_cleared_waves():
    game = Game.__new__(Game)
    game.active_run_perks = set()
    game.pending_perk_choices = []
    game.perk_selection = 0
    game.perk_choice_open = False
    game.armory_open = True

    Game.maybe_offer_run_perk(game, 1)
    assert game.perk_choice_open is False

    Game.maybe_offer_run_perk(game, 2)
    assert game.perk_choice_open is True
    assert len(game.pending_perk_choices) == 4
    assert len(set(game.pending_perk_choices)) == 4
    assert game.armory_open is False


def test_apply_run_perks_updates_all_multipliers():
    game = Game.__new__(Game)
    game.weapon_inventory = WeaponInventory()
    game.active_run_perks = set()
    game.damage_multiplier = 1.0
    game.player_speed_multiplier = 1.0
    game.run_scrap_multiplier = 1.0
    game.powerups = SimpleNamespace(drop_chance_multiplier=1.0)

    Game.apply_run_perk(game, "sharpshooter")
    Game.apply_run_perk(game, "fast_hands")
    Game.apply_run_perk(game, "adrenaline")
    Game.apply_run_perk(game, "scavenger")

    assert game.damage_multiplier == 1.15
    assert game.weapon_inventory.reload_time_multiplier == 0.8
    assert game.player_speed_multiplier == 1.08
    assert game.run_scrap_multiplier == 1.12
    assert len(game.active_run_perks) == 4


def test_perk_descriptions_include_clarity_updates():
    assert "0.50 HP/sec" in str(RUN_PERK_DEFINITIONS["bloodlust"]["description"])
    assert "travel speed" in str(RUN_PERK_DEFINITIONS["kinetic_rounds"]["description"]).lower()
    assert "damage unchanged" in str(RUN_PERK_DEFINITIONS["kinetic_rounds"]["description"]).lower()
    assert "no ammo refill is needed" in str(RUN_PERK_DEFINITIONS["field_engineer"]["description"]).lower()
    assert str(RUN_PERK_DEFINITIONS["vampiric_rounds"]["name"]) == "Sanguine Divine"
    assert "0.75 HP/sec" in str(RUN_PERK_DEFINITIONS["vampiric_rounds"]["description"])


def test_sanguine_divine_raises_lifesteal_cap_to_point_seventy_five():
    game = Game.__new__(Game)
    game.weapon_inventory = WeaponInventory()
    game.active_run_perks = set()
    game.damage_multiplier = 1.0
    game.player_speed_multiplier = 1.0
    game.run_scrap_multiplier = 1.0
    game.lifesteal_ratio = 0.0
    game.lifesteal_cap_per_second = 0.50
    game.powerups = SimpleNamespace(drop_chance_multiplier=1.0)

    Game.apply_run_perk(game, "vampiric_rounds")

    assert abs(game.lifesteal_ratio - 0.0010) < 1e-9
    assert abs(game.lifesteal_cap_per_second - 0.75) < 1e-9


def test_phoenix_step_is_removed_from_perk_pool_and_apply_is_noop():
    assert "phoenix_step" not in RUN_PERK_DEFINITIONS

    game = Game.__new__(Game)
    game.weapon_inventory = WeaponInventory()
    game.active_run_perks = set()
    game.damage_multiplier = 1.0
    game.player_speed_multiplier = 1.0
    game.run_scrap_multiplier = 1.0
    game.powerups = SimpleNamespace(drop_chance_multiplier=1.0)

    Game.apply_run_perk(game, "phoenix_step")

    assert game.active_run_perks == set()
    assert game.player_speed_multiplier == 1.0


def test_removed_perk_never_appears_in_mutation_draft_choices():
    game = Game.__new__(Game)
    game.active_run_perks = set()
    game.pending_perk_choices = []
    game.perk_selection = 0
    game.perk_choice_open = False
    game.armory_open = False
    game.mutation_drawer_open = False
    game.mutation_drawer_scroll = 0

    for _ in range(12):
        Game.maybe_offer_run_perk(game, 2)
        assert "phoenix_step" not in list(getattr(game, "pending_perk_choices", []))


def test_armory_upgrade_purchase_increases_tier_and_applies_effects():
    game = Game.__new__(Game)
    game.weapon_inventory = WeaponInventory()
    game.player = Player(0, 0)
    game.powerups = SimpleNamespace(drop_chance_multiplier=1.0)
    game.run_scrap = 400
    game.armory_tab = "upgrades"
    game.armory_selection = 2
    game.armory_message = ""
    game.armory_message_timer = 0.0
    game.run_upgrade_levels = {key: 0 for key in ARMORY_UPGRADE_DEFINITIONS}
    game.damage_multiplier = 1.0
    game.player_speed_multiplier = 1.0
    game.run_scrap_multiplier = 1.0
    game.weapon_cooldown_multiplier = 1.0
    game.crit_chance = 0.0
    game.crit_damage_bonus = 0.0
    game.lifesteal_ratio = 0.0
    game.incoming_damage_multiplier = 1.0
    game.ammo_preserve_chance = 0.0
    game.projectile_speed_multiplier = 1.0
    game.powerup_drop_multiplier = 1.0
    game.low_hp_damage_multiplier = 1.0
    game.last_stand_enabled = False
    game.last_stand_available = False

    assert Game.try_buy_armory_selection(game) is True
    assert game.run_scrap == 160
    assert game.run_upgrade_levels["targeting_rig"] == 1
    assert game.damage_multiplier == 1.1
    assert "Targeting Rig" in game.armory_message


def test_fortune_extractor_upgrade_uses_8_percent_scrap_gain_per_tier():
    upgrade = ARMORY_UPGRADE_DEFINITIONS["fortune_extractor"]
    assert upgrade["detail"] == "+8% Scrap Gain / tier"
    assert abs(float(upgrade["effects"]["scrap_mult"]) - 1.08) < 1e-9


def test_effect_caps_are_enforced():
    game = Game.__new__(Game)
    game.weapon_inventory = WeaponInventory()
    game.player = Player(0, 0)
    game.powerups = SimpleNamespace(drop_chance_multiplier=1.0)
    game.damage_multiplier = 1.0
    game.player_speed_multiplier = 1.0
    game.run_scrap_multiplier = 1.0
    game.weapon_cooldown_multiplier = 1.0
    game.crit_chance = 0.0
    game.crit_damage_bonus = 0.0
    game.lifesteal_ratio = 0.0
    game.incoming_damage_multiplier = 1.0
    game.ammo_preserve_chance = 0.0
    game.projectile_speed_multiplier = 1.0
    game.powerup_drop_multiplier = 1.0
    game.low_hp_damage_multiplier = 1.0
    game.last_stand_enabled = False
    game.last_stand_available = False

    Game.apply_effect_bundle(
        game,
        {
            "reload_mult": 0.1,
            "cooldown_mult": 0.1,
            "crit_chance_add": 2.0,
            "ammo_preserve_add": 2.0,
            "move_mult": 2.0,
        },
    )

    assert game.weapon_inventory.reload_time_multiplier == 0.35
    assert game.weapon_cooldown_multiplier == 0.45
    assert game.crit_chance == 0.55
    assert game.ammo_preserve_chance == 0.60
    assert game.player_speed_multiplier == 1.35


def test_spawn_projectiles_applies_damage_multiplier():
    game = Game.__new__(Game)
    game.player = Player(0, 0)
    game.projectiles = []
    game.damage_multiplier = 1.15

    Game.spawn_projectiles(
        game,
        [ProjectileSpawn(direction=pygame.Vector2(1, 0), speed=500.0, radius=4, damage=20)],
    )

    assert len(game.projectiles) == 1
    assert game.projectiles[0].damage == 23


def test_reset_game_resets_run_progression_state():
    game = Game.__new__(Game)
    game.player = Player(0, 0)
    game.world_spawn = pygame.Vector2(0, 0)
    game.zombies = [object()]
    game.projectiles = [object()]
    game.powerups = SimpleNamespace(reset=lambda: None)

    class FakeWaveManager:
        def __init__(self):
            self.current_wave = 9

        def start_first_wave(self) -> None:
            self.current_wave = 1

    game.wave_manager = FakeWaveManager()
    game.kills = 12
    game.score = 99
    game.coins_earned_run = 33
    game.pending_coin_delta = 22
    game.coin_flush_timer = 0.9
    game.survival_time = 44.0
    game.weapon_inventory = WeaponInventory()
    game.weapon_inventory.reload_time_multiplier = 0.5
    game.fire_button_prev = True
    game.player_hit_timer = 0.4
    game.last_aim_direction = pygame.Vector2(0, 1)
    game.camera = SimpleNamespace(update=lambda _pos: None)
    game.start_wave_banner = lambda _wave: None
    game.score_saved = True

    game.run_scrap = 250
    game.run_scrap_multiplier = 1.25
    game.damage_multiplier = 1.15
    game.player_speed_multiplier = 1.12
    game.active_run_perks = {"sharpshooter"}
    game.pending_perk_choices = ["scavenger", "adrenaline", "fast_hands"]
    game.perk_selection = 2
    game.perk_choice_open = True
    game.armory_open = True
    game.armory_selection = 1
    game.armory_message = "test"
    game.armory_message_timer = 1.2
    game.owned_run_weapons = {"burst_rifle"}
    game.extra_weapon_slot_unlocked = True

    Game.reset_game(game)

    assert game.run_scrap == 0
    assert game.run_scrap_multiplier == 1.0
    assert game.damage_multiplier == 1.0
    assert game.player_speed_multiplier == 1.0
    assert game.active_run_perks == set()
    assert game.pending_perk_choices == []
    assert game.perk_choice_open is False
    assert game.armory_open is False
    assert game.owned_run_weapons == set()
    assert game.extra_weapon_slot_unlocked is False


def test_handle_playing_event_escape_closes_armory_overlay():
    game = Game.__new__(Game)
    game.state = GameState.PLAYING
    game.perk_choice_open = False
    game.armory_open = True
    game.armory_message = "x"
    game.armory_message_timer = 1.0

    event = pygame.event.Event(pygame.KEYDOWN, {"key": pygame.K_ESCAPE})
    Game.handle_playing_event(game, event)

    assert game.state == GameState.PLAYING
    assert game.armory_open is False
    assert game.armory_message == ""


def test_play_menu_option_opens_visual_mode_select():
    game = Game.__new__(Game)
    game.menu_selection = 0
    game.state = GameState.MENU
    game.visual_mode_selection = 2
    game.open_visual_mode_select = Game.open_visual_mode_select.__get__(game, Game)

    Game.activate_menu_selection(game)

    assert game.state == GameState.VISUAL_MODE_SELECT
    assert game.visual_mode_selection == 0


def test_howto_menu_option_opens_standalone_guide():
    game = Game.__new__(Game)
    game.menu_selection = 3
    game.state = GameState.MENU
    game.guide_origin = "menu"
    game.guide_section_index = 0
    game.guide_scroll_offset = 0
    game.open_guide = Game.open_guide.__get__(game, Game)

    Game.activate_menu_selection(game)

    assert game.state == GameState.GUIDE
    assert game.guide_origin == "menu"
    assert game.guide_section_index == 0


def test_escape_in_guide_returns_to_menu_when_opened_from_menu():
    game = Game.__new__(Game)
    game.state = GameState.GUIDE
    game.guide_origin = "menu"
    game.guide_scroll_offset = 10
    game.close_guide = Game.close_guide.__get__(game, Game)
    game.handle_guide_event = Game.handle_guide_event.__get__(game, Game)

    event = pygame.event.Event(pygame.KEYDOWN, {"key": pygame.K_ESCAPE})
    Game.handle_guide_event(game, event)

    assert game.state == GameState.MENU
    assert game.guide_scroll_offset == 0


def test_visual_mode_select_enter_starts_run_with_selected_mode():
    game = Game.__new__(Game)
    game.state = GameState.VISUAL_MODE_SELECT
    game.visual_mode_selection = 1
    game.visual_mode = "night"
    game.reset_game = lambda: None

    event = pygame.event.Event(pygame.KEYDOWN, {"key": pygame.K_RETURN})
    Game.handle_visual_mode_select_event(game, event)

    assert game.visual_mode == "day"
    assert game.state == GameState.PLAYING


def test_visual_mode_select_escape_returns_to_menu():
    game = Game.__new__(Game)
    game.state = GameState.VISUAL_MODE_SELECT
    game.visual_mode_selection = 2

    event = pygame.event.Event(pygame.KEYDOWN, {"key": pygame.K_ESCAPE})
    Game.handle_visual_mode_select_event(game, event)

    assert game.state == GameState.MENU
    assert game.visual_mode_selection == 2


def test_escape_opens_pause_menu_during_playing():
    game = Game.__new__(Game)
    game.state = GameState.PLAYING
    game.perk_choice_open = False
    game.armory_open = False
    game.pause_open = False
    game.pause_settings_open = False
    game.pause_selection = 0
    game.pause_settings_selection = 0
    game.mutation_drawer_open = True

    event = pygame.event.Event(pygame.KEYDOWN, {"key": pygame.K_ESCAPE})
    Game.handle_playing_event(game, event)

    assert game.pause_open is True
    assert game.pause_settings_open is False
    assert game.mutation_drawer_open is False
    assert game.state == GameState.PLAYING


def test_h_key_opens_standalone_guide_from_playing():
    game = Game.__new__(Game)
    game.state = GameState.PLAYING
    game.perk_choice_open = False
    game.armory_open = False
    game.pause_open = False
    game.pause_settings_open = False
    game.guide_origin = "menu"
    game.guide_section_index = 0
    game.guide_scroll_offset = 0
    game.pause_selection = 0
    game.pause_settings_selection = 0
    game.mutation_drawer_open = True
    game.open_guide = Game.open_guide.__get__(game, Game)

    event = pygame.event.Event(pygame.KEYDOWN, {"key": pygame.K_h})
    Game.handle_playing_event(game, event)

    assert game.state == GameState.GUIDE
    assert game.guide_origin == "playing_hotkey"
    assert game.guide_section_index == 2


def test_escape_in_guide_returns_to_playing_when_opened_by_hotkey():
    game = Game.__new__(Game)
    game.state = GameState.GUIDE
    game.guide_origin = "playing_hotkey"
    game.guide_scroll_offset = 8
    game.close_guide = Game.close_guide.__get__(game, Game)
    game.handle_guide_event = Game.handle_guide_event.__get__(game, Game)

    event = pygame.event.Event(pygame.KEYDOWN, {"key": pygame.K_ESCAPE})
    Game.handle_guide_event(game, event)

    assert game.state == GameState.PLAYING
    assert game.guide_scroll_offset == 0


def test_escape_in_guide_returns_to_pause_when_opened_from_pause():
    game = Game.__new__(Game)
    game.state = GameState.GUIDE
    game.guide_origin = "pause"
    game.guide_scroll_offset = 4
    game.pause_open = False
    game.pause_settings_open = False
    game.pause_selection = 2
    game.pause_settings_selection = 1
    game.close_guide = Game.close_guide.__get__(game, Game)
    game.open_pause_menu = Game.open_pause_menu.__get__(game, Game)
    game.handle_guide_event = Game.handle_guide_event.__get__(game, Game)

    event = pygame.event.Event(pygame.KEYDOWN, {"key": pygame.K_ESCAPE})
    Game.handle_guide_event(game, event)

    assert game.state == GameState.PLAYING
    assert game.pause_open is True
    assert game.pause_settings_open is False


def test_escape_in_pause_settings_returns_to_pause_main():
    game = Game.__new__(Game)
    game.state = GameState.PLAYING
    game.perk_choice_open = False
    game.armory_open = False
    game.pause_open = True
    game.pause_settings_open = True
    game.pause_selection = 0
    game.pause_settings_selection = 1

    event = pygame.event.Event(pygame.KEYDOWN, {"key": pygame.K_ESCAPE})
    Game.handle_playing_event(game, event)

    assert game.pause_open is True
    assert game.pause_settings_open is False


def test_escape_in_pause_main_resumes_game():
    game = Game.__new__(Game)
    game.state = GameState.PLAYING
    game.perk_choice_open = False
    game.armory_open = False
    game.pause_open = True
    game.pause_settings_open = False
    game.pause_selection = 1
    game.pause_settings_selection = 0

    event = pygame.event.Event(pygame.KEYDOWN, {"key": pygame.K_ESCAPE})
    Game.handle_playing_event(game, event)

    assert game.pause_open is False
    assert game.pause_settings_open is False


def test_pause_main_selection_opens_standalone_guide():
    game = Game.__new__(Game)
    game.state = GameState.PLAYING
    game.perk_choice_open = False
    game.armory_open = False
    game.pause_open = True
    game.pause_settings_open = False
    game.pause_selection = 1
    game.pause_settings_selection = 0
    game.guide_origin = "menu"
    game.guide_section_index = 0
    game.guide_scroll_offset = 0
    game.open_guide = Game.open_guide.__get__(game, Game)

    event = pygame.event.Event(pygame.KEYDOWN, {"key": pygame.K_RETURN})
    Game.handle_playing_event(game, event)

    assert game.state == GameState.GUIDE
    assert game.guide_origin == "pause"
    assert game.pause_open is False


def test_pause_quit_to_menu_flushes_coins():
    game = Game.__new__(Game)
    game.state = GameState.PLAYING
    game.perk_choice_open = False
    game.armory_open = False
    game.armory_message = "x"
    game.armory_message_timer = 1.0
    game.pause_open = True
    game.pause_settings_open = False
    game.pause_selection = 3
    game.pause_settings_selection = 0
    game.mutation_drawer_open = True

    flush_calls: list[bool] = []
    game.flush_pending_coins = lambda force=False: flush_calls.append(bool(force))

    event = pygame.event.Event(pygame.KEYDOWN, {"key": pygame.K_RETURN})
    Game.handle_playing_event(game, event)

    assert flush_calls == [True]
    assert game.state == GameState.MENU
    assert game.pause_open is False
    assert game.mutation_drawer_open is False


def test_pause_settings_can_toggle_fullscreen():
    game = Game.__new__(Game)
    game.state = GameState.PLAYING
    game.perk_choice_open = False
    game.armory_open = False
    game.pause_open = True
    game.pause_settings_open = True
    game.pause_selection = 0
    game.pause_settings_selection = 0

    calls: list[str] = []
    game.toggle_fullscreen = lambda: calls.append("fullscreen")

    event = pygame.event.Event(pygame.KEYDOWN, {"key": pygame.K_RETURN})
    Game.handle_playing_event(game, event)

    assert calls == ["fullscreen"]
    assert game.pause_open is True
    assert game.pause_settings_open is True


def test_guide_category_keyboard_navigation_and_scroll():
    game = Game.__new__(Game)
    game.state = GameState.GUIDE
    game.width = 1000
    game.height = 700
    game.guide_section_index = 0
    game.guide_scroll_offset = 0
    game.guide_origin = "menu"
    game.window_to_logical = lambda _pos, clamp=False: pygame.Vector2(0, 0)

    Game.handle_guide_event(game, pygame.event.Event(pygame.KEYDOWN, {"key": pygame.K_DOWN}))
    assert game.guide_section_index == 1

    Game.handle_guide_event(game, pygame.event.Event(pygame.KEYDOWN, {"key": pygame.K_PAGEUP}))
    assert game.guide_scroll_offset == 0

    Game.handle_guide_event(game, pygame.event.Event(pygame.KEYDOWN, {"key": pygame.K_PAGEDOWN}))
    assert game.guide_scroll_offset > 0


def test_update_loop_is_paused_when_in_guide_state():
    game = Game.__new__(Game)
    game.state = GameState.GUIDE
    game.survival_time = 13.0

    Game.update(game, 1.0)

    assert game.survival_time == 13.0


def test_overlay_pause_freezes_survival_and_intermission_progression():
    class FakeWaveManager:
        def __init__(self):
            self.current_wave = 3
            self.intermission_remaining = 4.0
            self.called = False

        def is_intermission(self) -> bool:
            return True

        def update(self, _dt: float, _alive_count: int):
            self.called = True
            self.intermission_remaining -= 1.0
            return SimpleNamespace(spawn_types=[], wave_started=False, wave_cleared=False)

    game = Game.__new__(Game)
    game.state = GameState.PLAYING
    game.wave_manager = FakeWaveManager()
    game.armory_open = True
    game.perk_choice_open = False
    game.survival_time = 22.0
    game.player_hit_timer = 0.4
    game.coin_flush_timer = 0.7
    game.wave_banner_timer = 1.1
    game.armory_message = "msg"
    game.armory_message_timer = 1.2
    game.fire_button_prev = True
    game.player_speed_multiplier = 1.0
    game.last_aim_direction = pygame.Vector2(1, 0)
    game.world_rect = pygame.Rect(0, 0, 800, 600)
    game.player = SimpleNamespace(
        position=pygame.Vector2(100, 100),
        is_alive=True,
        update=lambda *_args, **_kwargs: None,
    )
    game.camera = SimpleNamespace(update=lambda _position: None)
    game.weapon_inventory = SimpleNamespace()
    game.powerups = SimpleNamespace()
    game.zombies = []
    game.projectiles = []

    game.get_movement_input = lambda: pygame.Vector2(0, 0)
    game.get_aim_direction = lambda: pygame.Vector2(1, 0)
    game.flush_pending_coins = lambda force=False: None
    game.process_wave_clear = lambda: None
    game.spawn_projectiles = lambda _spawns: None
    game.handle_collisions = lambda: None

    Game.update(game, 1.0)

    assert game.survival_time == 22.0
    assert game.wave_manager.intermission_remaining == 4.0
    assert game.wave_manager.called is False
    assert game.wave_banner_timer == 1.1
    assert game.armory_message_timer == 1.2
    assert game.fire_button_prev is False


def test_overlay_pause_freezes_when_pause_menu_open():
    class FakeWaveManager:
        def __init__(self):
            self.current_wave = 3
            self.intermission_remaining = 2.0
            self.called = False

        def is_intermission(self) -> bool:
            return False

        def update(self, _dt: float, _alive_count: int):
            self.called = True
            return SimpleNamespace(spawn_types=[], wave_started=False, wave_cleared=False)

    game = Game.__new__(Game)
    game.state = GameState.PLAYING
    game.wave_manager = FakeWaveManager()
    game.pause_open = True
    game.pause_settings_open = False
    game.armory_open = False
    game.perk_choice_open = False
    game.survival_time = 11.0
    game.player_hit_timer = 0.3
    game.coin_flush_timer = 0.4
    game.wave_banner_timer = 0.9
    game.armory_message = "msg"
    game.armory_message_timer = 1.1
    game.fire_button_prev = True
    game.player_speed_multiplier = 1.0
    game.last_aim_direction = pygame.Vector2(1, 0)
    game.world_rect = pygame.Rect(0, 0, 800, 600)
    game.player = SimpleNamespace(position=pygame.Vector2(100, 100), is_alive=True, update=lambda *_args, **_kwargs: None)
    game.camera = SimpleNamespace(update=lambda _position: None, view_rect=pygame.Rect(0, 0, 800, 600))
    game.weapon_inventory = SimpleNamespace(update_timers=lambda _dt: None, step_fire=lambda **_kwargs: [])
    game.powerups = SimpleNamespace(update=lambda _dt: None, collect_at_player=lambda _player: [], shoot_cooldown_multiplier=1.0, zombie_speed_multiplier=1.0)
    game.zombies = []
    game.projectiles = []
    game.get_movement_input = lambda: pygame.Vector2(0, 0)
    game.get_aim_direction = lambda: pygame.Vector2(1, 0)
    game.flush_pending_coins = lambda force=False: None
    game.process_wave_clear = lambda: None
    game.spawn_projectiles = lambda _spawns: None
    game.handle_collisions = lambda: None

    Game.update(game, 1.0)

    assert game.survival_time == 11.0
    assert game.wave_manager.called is False
    assert game.armory_message_timer == 1.1


def test_clicking_armory_button_toggles_overlay():
    game = Game.__new__(Game)
    game.state = GameState.PLAYING
    game.width = 1000
    game.perk_choice_open = False
    game.armory_open = False
    game.armory_selection = 4
    game.armory_message = "old"
    game.armory_message_timer = 0.9
    game.wave_manager = SimpleNamespace(is_intermission=lambda: True)
    game.window_to_logical = lambda _pos, clamp=False: pygame.Vector2(get_armory_button_rect(game.width).center)

    click_event = pygame.event.Event(pygame.MOUSEBUTTONDOWN, {"button": 1, "pos": (0, 0)})
    Game.handle_playing_event(game, click_event)
    assert game.armory_open is True

    Game.handle_playing_event(game, click_event)
    assert game.armory_open is False


def test_p_key_toggles_mutation_drawer():
    game = Game.__new__(Game)
    game.state = GameState.PLAYING
    game.perk_choice_open = False
    game.armory_open = False
    game.pause_open = False
    game.pause_settings_open = False
    game.mutation_drawer_open = False

    event = pygame.event.Event(pygame.KEYDOWN, {"key": pygame.K_p})
    Game.handle_playing_event(game, event)
    assert game.mutation_drawer_open is True

    Game.handle_playing_event(game, event)
    assert game.mutation_drawer_open is False


def test_clicking_mutation_button_toggles_drawer():
    game = Game.__new__(Game)
    game.state = GameState.PLAYING
    game.width = 1000
    game.perk_choice_open = False
    game.armory_open = False
    game.pause_open = False
    game.pause_settings_open = False
    game.mutation_drawer_open = False
    game.wave_manager = SimpleNamespace(is_intermission=lambda: False)
    game.window_to_logical = lambda _pos, clamp=False: pygame.Vector2(get_mutation_button_rect(game.width).center)

    click_event = pygame.event.Event(pygame.MOUSEBUTTONDOWN, {"button": 1, "pos": (0, 0)})
    Game.handle_playing_event(game, click_event)
    assert game.mutation_drawer_open is True

    Game.handle_playing_event(game, click_event)
    assert game.mutation_drawer_open is False


def test_mouse_wheel_scrolls_mutation_drawer_content():
    game = Game.__new__(Game)
    game.state = GameState.PLAYING
    game.perk_choice_open = False
    game.armory_open = False
    game.pause_open = False
    game.pause_settings_open = False
    game.mutation_drawer_open = True
    game.mutation_drawer_scroll = 2

    down_event = pygame.event.Event(pygame.MOUSEWHEEL, {"y": -1})
    Game.handle_playing_event(game, down_event)
    assert game.mutation_drawer_scroll == 3

    up_event = pygame.event.Event(pygame.MOUSEWHEEL, {"y": 1})
    Game.handle_playing_event(game, up_event)
    assert game.mutation_drawer_scroll == 2


def test_clicking_armory_tab_switches_overlay_tab():
    game = Game.__new__(Game)
    game.width = 1000
    game.armory_tab = "weapons"
    game.armory_selection = 0
    game.armory_open = True
    game.armory_message = ""
    game.armory_message_timer = 0.0
    game.armory_specs = lambda: [{"kind": "weapon", "weapon_key": "shotgun"}]
    game.try_buy_armory_selection = lambda: None
    game.window_to_logical = lambda _pos, clamp=False: pygame.Vector2(get_armory_tab_rects(game.width)["upgrades"].center)

    click_event = pygame.event.Event(pygame.MOUSEBUTTONDOWN, {"button": 1, "pos": (0, 0)})
    Game.handle_armory_event(game, click_event)
    assert game.armory_tab == "upgrades"


def test_armory_mouse_click_respects_scroll_offset():
    game = Game.__new__(Game)
    game.width = 1000
    game.armory_tab = "upgrades"
    game.armory_selection = 3
    game.armory_scroll_offset = 3
    game.armory_open = True
    game.armory_message = ""
    game.armory_message_timer = 0.0
    game.armory_specs = lambda: [{"kind": "weapon", "weapon_key": "pistol", "enabled": True, "status": "Owned"} for _ in range(12)]
    chosen: list[int] = []
    game.try_buy_armory_selection = lambda: chosen.append(game.armory_selection)
    target_row = get_armory_row_rect(game.width, 2)
    game.window_to_logical = lambda _pos, clamp=False: pygame.Vector2(target_row.center)

    click_event = pygame.event.Event(pygame.MOUSEBUTTONDOWN, {"button": 1, "pos": (0, 0)})
    Game.handle_armory_event(game, click_event)

    assert game.armory_selection == 5
    assert chosen == [5]


def test_clicking_perk_card_applies_selected_mutation():
    game = Game.__new__(Game)
    game.state = GameState.PLAYING
    game.width = 1000
    game.height = 700
    game.perk_choice_open = True
    game.armory_open = False
    game.perk_selection = 0
    game.pending_perk_choices = ["sharpshooter", "fast_hands", "adrenaline"]
    chosen: list[str] = []
    game.apply_run_perk = lambda perk_key: chosen.append(perk_key)

    second_card = get_perk_card_rects(game.width, game.height, 3)[1]
    game.window_to_logical = lambda _pos, clamp=False: pygame.Vector2(second_card.center)

    click_event = pygame.event.Event(pygame.MOUSEBUTTONDOWN, {"button": 1, "pos": (0, 0)})
    Game.handle_playing_event(game, click_event)

    assert chosen == ["fast_hands"]
    assert game.perk_choice_open is False
    assert game.pending_perk_choices == []


def test_last_stand_prevents_first_fatal_hit_only():
    game = Game.__new__(Game)
    game.projectiles = []
    game.player = Player(0, 0)
    game.player.health = 10
    game.last_stand_enabled = True
    game.last_stand_available = True
    game.player_hit_timer = 0.0
    game.player_hit_cooldown = 0.45
    game.incoming_damage_multiplier = 1.0
    game.zombies = [Zombie(0, 0)]

    Game.handle_collisions(game)
    assert game.player.health == 20
    assert game.last_stand_available is False

    game.player.health = 10
    game.player_hit_timer = 0.0
    Game.handle_collisions(game)
    assert game.player.health == 0


def test_lifesteal_at_point_one_percent_does_not_force_minimum_heal():
    game = Game.__new__(Game)
    zombie = Zombie(0, 0)
    projectile = Projectile(pygame.Vector2(0, 0), pygame.Vector2(1, 0), speed=0, damage=50)
    projectile.position = pygame.Vector2(zombie.position)

    game.projectiles = [projectile]
    game.zombies = [zombie]
    game.player = Player(500, 500)
    game.player.health = 70
    game.player_hit_timer = 0.0
    game.player_hit_cooldown = 0.45
    game.incoming_damage_multiplier = 1.0
    game.powerups = SimpleNamespace(maybe_spawn_drop=lambda position, ammo_pressure=0.0: None, incoming_damage_multiplier=1.0)
    game.wave_manager = SimpleNamespace(notify_zombie_killed=lambda: None)
    game.award_coins = lambda amount: None
    game.award_run_scrap = lambda amount: None
    game.lifesteal_ratio = 0.001
    game.lifesteal_cap_per_second = 6
    game.lifesteal_healed_this_window = 0
    game.lifesteal_window_elapsed = 0.2
    game.kills = 0
    game.score = 0

    Game.handle_collisions(game)
    assert game.player.health == 70


def test_lifesteal_is_capped_per_second():
    game = Game.__new__(Game)
    boss_a = Zombie(0, 0, ZombieType.BOSS)
    boss_b = Zombie(60, 0, ZombieType.BOSS)
    boss_a.max_health = 10_000
    boss_a.health = 10_000
    boss_b.max_health = 10_000
    boss_b.health = 10_000
    projectile_a = Projectile(pygame.Vector2(0, 0), pygame.Vector2(1, 0), speed=0, damage=9_000)
    projectile_b = Projectile(pygame.Vector2(60, 0), pygame.Vector2(1, 0), speed=0, damage=9_000)
    projectile_a.position = pygame.Vector2(0, 0)
    projectile_b.position = pygame.Vector2(60, 0)

    game.projectiles = [projectile_a, projectile_b]
    game.zombies = [boss_a, boss_b]
    game.player = Player(500, 500)
    game.player.health = 50
    game.player_hit_timer = 0.0
    game.player_hit_cooldown = 0.45
    game.incoming_damage_multiplier = 1.0
    game.powerups = SimpleNamespace(maybe_spawn_drop=lambda position, ammo_pressure=0.0: None, incoming_damage_multiplier=1.0)
    game.wave_manager = SimpleNamespace(notify_zombie_killed=lambda: None)
    game.award_coins = lambda amount: None
    game.award_run_scrap = lambda amount: None
    game.lifesteal_ratio = 0.001
    game.lifesteal_cap_per_second = 6
    game.lifesteal_healed_this_window = 0
    game.lifesteal_window_elapsed = 0.6
    game.kills = 0
    game.score = 0

    Game.handle_collisions(game)
    assert game.player.health == 56


def test_menu_mouse_click_mapping_matches_visual_rows():
    pygame.init()
    game = Game.__new__(Game)
    game.width = 1000
    game.height = 700
    game.menu_message = ""
    game.leaderboard_lines = []
    game.menu_selection = -1

    activated: list[int] = []
    game.activate_menu_selection = lambda: activated.append(game.menu_selection)

    rects = get_menu_option_rects(game.width, game.height, has_message=False, leaderboard_count=0)
    click_positions = [pygame.Vector2(rect.center) for rect in rects]
    click_iter = iter(click_positions)
    game.window_to_logical = lambda _pos, clamp=False: next(click_iter)

    for _ in range(5):
        click_event = pygame.event.Event(pygame.MOUSEBUTTONDOWN, {"button": 1, "pos": (0, 0)})
        Game.handle_menu_event(game, click_event)

    assert activated == [0, 1, 2, 3, 4]


def test_visual_mode_label_has_no_hotkey_suffix():
    game = Game.__new__(Game)
    game.visual_mode = "day"

    assert Game.visual_mode_label(game) == "Visual Mode: Day"


def test_visual_mode_select_click_starts_selected_mode():
    game = Game.__new__(Game)
    game.state = GameState.VISUAL_MODE_SELECT
    game.width = 1000
    game.height = 700
    game.visual_mode_selection = 0
    game.visual_mode = "night"
    game.reset_game = lambda: None
    game.window_to_logical = lambda _pos, clamp=False: pygame.Vector2(get_visual_mode_option_rects(game.width, game.height)[2].center)

    click_event = pygame.event.Event(pygame.MOUSEBUTTONDOWN, {"button": 1, "pos": (0, 0)})
    Game.handle_visual_mode_select_event(game, click_event)

    assert game.visual_mode_selection == 2
    assert game.visual_mode == "blackout"
    assert game.state == GameState.PLAYING


def test_render_lighting_overlay_only_in_night_mode(monkeypatch):
    game = Game.__new__(Game)
    game.screen = pygame.Surface((120, 90), pygame.SRCALPHA)
    game.visual_mode = "day"
    game.active_wave_mutator = None

    calls: list[dict[str, object]] = []
    monkeypatch.setattr("game.main.render_darkness_overlay", lambda *_args, **kwargs: calls.append(kwargs))

    Game.render_lighting_overlay(game, pygame.Vector2(20, 20), pygame.Vector2(1, 0))
    assert calls == []

    game.visual_mode = "night"
    Game.render_lighting_overlay(game, pygame.Vector2(20, 20), pygame.Vector2(1, 0))
    assert calls[0]["darkness_alpha"] == 190

    game.visual_mode = "blackout"
    Game.render_lighting_overlay(game, pygame.Vector2(20, 20), pygame.Vector2(1, 0))
    assert calls[1]["darkness_alpha"] == 228


def test_nightmare_fog_forces_blackout_overlay_even_in_day_mode(monkeypatch):
    game = Game.__new__(Game)
    game.screen = pygame.Surface((120, 90), pygame.SRCALPHA)
    game.visual_mode = "day"
    game.active_wave_mutator = "nightmare_fog"

    calls: list[dict[str, object]] = []
    monkeypatch.setattr("game.main.render_darkness_overlay", lambda *_args, **kwargs: calls.append(kwargs))

    Game.render_lighting_overlay(game, pygame.Vector2(20, 20), pygame.Vector2(1, 0))

    assert len(calls) == 1
    assert calls[0]["cone_angle_deg"] == 46
    assert calls[0]["darkness_alpha"] == 244


def test_render_world_entities_uses_cone_visibility_when_nightmare_fog_active(monkeypatch):
    game = Game.__new__(Game)
    game.width = 120
    game.height = 90
    game.screen = pygame.Surface((120, 90), pygame.SRCALPHA)
    game.visual_mode = "day"
    game.active_wave_mutator = "nightmare_fog"
    game.powerups = SimpleNamespace(pickups=[], pickup_color=lambda _kind: (255, 255, 255))
    game.projectiles = []
    game.player = Player(20, 20)
    game.zombies = [Zombie(40, 40)]
    game.last_aim_direction = pygame.Vector2(1, 0)
    game.get_mouse_logical_pos = lambda clamp=True: pygame.Vector2(80, 45)
    game.camera = SimpleNamespace(
        world_to_screen=lambda value: pygame.Vector2(value),
        screen_to_world=lambda value: pygame.Vector2(value),
    )

    calls: list[bool] = []
    monkeypatch.setattr(
        "game.main.apply_cone_visibility_mask",
        lambda zombie_layer, cone_points: calls.append(bool(cone_points)) or zombie_layer,
    )

    player_screen = Game.render_world_entities(game, draw_barrel=False)

    assert isinstance(player_screen, pygame.Vector2)
    assert calls == [True]


def test_field_repair_spends_scrap_and_restores_missing_hp():
    game = Game.__new__(Game)
    game.weapon_inventory = WeaponInventory()
    game.player = Player(0, 0)
    game.player.take_damage(35)
    game.run_upgrade_levels = {key: 0 for key in ARMORY_UPGRADE_DEFINITIONS}
    game.armory_tab = "upgrades"
    game.run_scrap = 600
    game.armory_message = ""
    game.armory_message_timer = 0.0

    rows = Game.armory_upgrade_rows(game)
    repair_index = next(i for i, row in enumerate(rows) if row.get("kind") == "field_repair")
    game.armory_selection = repair_index

    before_scrap = game.run_scrap
    assert Game.try_buy_armory_selection(game) is True
    assert game.player.health == game.player.max_health
    assert game.run_scrap < before_scrap


def test_combat_calibration_is_repeatable_and_cost_scales():
    game = Game.__new__(Game)
    game.weapon_inventory = WeaponInventory()
    game.player = Player(0, 0)
    game.powerups = SimpleNamespace(drop_chance_multiplier=1.0)
    game.run_upgrade_levels = {key: 0 for key in ARMORY_UPGRADE_DEFINITIONS}
    game.armory_tab = "upgrades"
    game.armory_message = ""
    game.armory_message_timer = 0.0
    game.run_scrap = 2000
    game.combat_calibration_level = 0
    game.damage_multiplier = 1.0
    game.player_speed_multiplier = 1.0
    game.run_scrap_multiplier = 1.0
    game.weapon_cooldown_multiplier = 1.0
    game.crit_chance = 0.0
    game.crit_damage_bonus = 0.0
    game.lifesteal_ratio = 0.0
    game.incoming_damage_multiplier = 1.0
    game.ammo_preserve_chance = 0.0
    game.projectile_speed_multiplier = 1.0
    game.powerup_drop_multiplier = 1.0
    game.low_hp_damage_multiplier = 1.0
    game.last_stand_enabled = False
    game.last_stand_available = False

    rows = Game.armory_upgrade_rows(game)
    calibration_index = next(i for i, row in enumerate(rows) if row.get("kind") == "combat_calibration")
    first_cost = int(rows[calibration_index]["cost"])
    game.armory_selection = calibration_index

    assert Game.try_buy_armory_selection(game) is True
    assert game.combat_calibration_level == 1
    assert game.damage_multiplier > 1.0
    assert game.run_scrap == 2000 - first_cost

    second_rows = Game.armory_upgrade_rows(game)
    second_cost = int(next(row["cost"] for row in second_rows if row.get("kind") == "combat_calibration"))
    assert second_cost > first_cost


def test_ammo_cache_falls_back_to_scrap_when_no_weapon_needs_ammo():
    game = Game.__new__(Game)
    game.weapon_inventory = WeaponInventory()
    game.run_scrap = 0
    game.run_scrap_multiplier = 1.0
    game.active_wave_twist = None

    Game.apply_ammo_cache_pickup(game)

    assert game.run_scrap == 8


def test_ammo_cache_registers_feedback_message_when_scrap_fallback_triggers():
    game = Game.__new__(Game)
    game.weapon_inventory = WeaponInventory()
    game.run_scrap = 0
    game.run_scrap_multiplier = 1.0
    game.active_wave_twist = None
    feedback: list[str] = []
    game.powerups = SimpleNamespace(register_ammo_cache_feedback=lambda text: feedback.append(str(text)))

    Game.apply_ammo_cache_pickup(game)
    assert feedback == ["Ammo Cache: +8 scrap"]


def test_ammo_cache_denial_twist_converts_pickup_into_scrap_only():
    game = Game.__new__(Game)
    game.active_wave_twist = "ammo_cache_denial"
    awarded: list[int] = []
    game.award_run_scrap = lambda amount: awarded.append(int(amount))
    game.weapon_inventory = SimpleNamespace(apply_ammo_pickup=lambda: (_ for _ in ()).throw(AssertionError("should not be called")))

    Game.apply_ammo_cache_pickup(game)
    assert awarded == [10]


def test_no_hit_streak_awards_scrap_burst_after_threshold():
    game = Game.__new__(Game)
    game.wave_manager = SimpleNamespace(is_intermission=lambda: False, current_wave=9)
    game.player_took_damage_this_frame = False
    game.no_hit_streak_seconds = 0.0
    rewards: list[int] = []
    game.award_run_scrap = lambda amount: rewards.append(int(amount))

    Game.update_no_hit_streak(game, NO_HIT_STREAK_THRESHOLD + 0.2)
    assert rewards == [34]
    assert 0.0 <= game.no_hit_streak_seconds < NO_HIT_STREAK_THRESHOLD


def test_armory_upgrade_rows_include_non_purchasable_wave_intel_row():
    game = Game.__new__(Game)
    game.weapon_inventory = WeaponInventory()
    game.wave_manager = SimpleNamespace(current_wave=8, is_boss_wave=lambda wave=None: True, preview_next_boss_archetype=lambda wave=None: "warden")
    game.run_upgrade_levels = {key: 0 for key in ARMORY_UPGRADE_DEFINITIONS}
    game.player = Player(0, 0)
    game.extra_weapon_slot_unlocked = False
    game.combat_calibration_level = 0

    rows = Game.armory_upgrade_rows(game)
    intel_row = next(row for row in rows if row.get("kind") == "wave_intel")
    assert intel_row["enabled"] is False
    assert intel_row["status"] == "Preview"
    assert "Boss archetype:" in str(intel_row["detail"])


def test_render_play_scene_prioritizes_temporary_effects_in_hud(monkeypatch):
    game = Game.__new__(Game)
    game.width = 1000
    game.height = 700
    game.screen = pygame.Surface((1000, 700))
    game.player = SimpleNamespace(position=pygame.Vector2(100, 100), health=100, max_health=100)
    game.camera = SimpleNamespace(screen_to_world=lambda _pos: pygame.Vector2(200, 200))
    game.last_aim_direction = pygame.Vector2(1, 0)
    game.wave_manager = SimpleNamespace(is_intermission=lambda: False, intermission_remaining=0.0, current_wave=4)
    game.powerups = SimpleNamespace(active_effect_labels=lambda: ["Freeze 2.0s (zombies slowed)", "Rapid Fire 1.5s"])
    game.run_perk_labels = lambda: ["Perk: Sharpshooter", "Perk: Adrenaline"]
    game.weapon_hud_data = lambda: ("pistol", "Pistol", "12/INF", "", ["*1: Pistol", " 2: Empty"])
    game.visual_mode_label = lambda: "Visual Mode: Day"
    game.draw_world_background = lambda: None
    game.render_world_entities = lambda draw_barrel: pygame.Vector2(120, 100)
    game.get_mouse_logical_pos = lambda clamp=True: pygame.Vector2(400, 300)
    game.render_lighting_overlay = lambda *_args, **_kwargs: None
    game.wave_banner_timer = 0.0
    game.perk_choice_open = False
    game.armory_open = False
    game.player_coins = 15
    game.run_scrap = 40
    game.score = 120
    game.kills = 7
    game.survival_time = 18.5

    captured_effects: list[str] = []

    def fake_draw_hud(*args, **kwargs):
        nonlocal captured_effects
        captured_effects = list(args[15])

    monkeypatch.setattr("game.main.draw_hud", fake_draw_hud)

    Game.render_play_scene(game)

    assert captured_effects[:2] == ["Freeze 2.0s (zombies slowed)", "Rapid Fire 1.5s"]


def test_update_passes_steering_context_to_zombie_update():
    class FakeZombie:
        def __init__(self):
            self.position = pygame.Vector2(170, 120)
            self.radius = 16
            self.called_kwargs: dict[str, object] = {}

        def update(self, _dt, _player_pos, _speed_mult, **kwargs):
            self.called_kwargs = dict(kwargs)

    game = Game.__new__(Game)
    game.state = GameState.PLAYING
    game.survival_time = 5.0
    game.player_hit_timer = 0.2
    game.coin_flush_timer = 0.3
    game.wave_banner_timer = 0.4
    game.armory_message = ""
    game.armory_message_timer = 0.0
    game.fire_button_prev = False
    game.player_speed_multiplier = 1.0
    game.last_aim_direction = pygame.Vector2(1, 0)
    game.world_rect = pygame.Rect(0, 0, 1200, 900)
    game.player = Player(100, 100)
    game.camera = SimpleNamespace(update=lambda _position: None, view_rect=pygame.Rect(0, 0, 800, 600))
    game.weapon_inventory = SimpleNamespace(update_timers=lambda _dt: None, step_fire=lambda **_kwargs: [])
    game.powerups = SimpleNamespace(
        update=lambda _dt: None,
        collect_at_player=lambda _player: [],
        shoot_cooldown_multiplier=1.0,
        zombie_speed_multiplier=1.0,
    )
    game.wave_manager = SimpleNamespace(
        is_intermission=lambda: False,
        update=lambda _dt, alive_count: SimpleNamespace(spawn_types=[], wave_started=False, wave_cleared=False),
    )
    fake_zombie = FakeZombie()
    game.zombies = [fake_zombie]
    game.projectiles = []
    game.get_movement_input = lambda: pygame.Vector2(0, 0)
    game.get_aim_direction = lambda: pygame.Vector2(1, 0)
    game.should_fire = lambda: False
    game.flush_pending_coins = lambda force=False: None
    game.process_wave_clear = lambda: None
    game.spawn_projectiles = lambda _spawns: None
    game.handle_collisions = lambda: None
    game.armory_open = False
    game.perk_choice_open = False
    game.pause_open = False

    Game.update(game, 0.1)

    assert "player_velocity" in fake_zombie.called_kwargs
    assert "nearby_zombies" in fake_zombie.called_kwargs
    assert "surround_strength" in fake_zombie.called_kwargs
    assert "role" in fake_zombie.called_kwargs
    assert "pack_pressure" in fake_zombie.called_kwargs


def test_assign_pack_roles_marks_minor_subset_as_cutters_or_flankers():
    game = Game.__new__(Game)
    game.player = Player(100, 100)
    game.zombies = [Zombie(100 + idx * 10, 100 + idx * 5) for idx in range(12)]

    roles = Game.assign_pack_roles(game, pygame.Vector2(180, 0), 0.9)

    assert len(roles) == 12
    pressure_roles = [role for role in roles.values() if role != "chase"]
    assert 2 <= len(pressure_roles) <= 5


def test_configure_wave_runtime_sets_mutator_and_objective_state():
    game = Game.__new__(Game)
    game.kills = 30
    game.total_shots_fired = 80
    game.powerup_drop_multiplier = 1.25
    game.powerups = SimpleNamespace(drop_chance_multiplier=1.0)
    game.wave_manager = SimpleNamespace(current_wave=10)

    Game.configure_wave_runtime(game, "objective", "ammo_discipline", "scarcity_protocol")

    assert game.active_wave_kind == "objective"
    assert game.active_wave_objective == "ammo_discipline"
    assert game.active_wave_mutator == "scarcity_protocol"
    assert game.wave_mutator_enemy_speed_mult > 1.0
    assert game.wave_powerup_drop_multiplier < 1.0
    assert game.objective_state["objective_key"] == "ammo_discipline"
    assert game.objective_state["shot_budget"] > 0
    assert game.powerups.drop_chance_multiplier < 1.25


def test_configure_wave_runtime_uses_harder_survive_and_quota_targets():
    game = Game.__new__(Game)
    game.kills = 0
    game.total_shots_fired = 0
    game.powerup_drop_multiplier = 1.0
    game.powerups = SimpleNamespace(drop_chance_multiplier=1.0)
    game.wave_manager = SimpleNamespace(current_wave=10)

    Game.configure_wave_runtime(game, "objective", "survive_timer", None)
    assert game.objective_state["target_seconds"] == 38.0

    Game.configure_wave_runtime(game, "objective", "kill_quota", None)
    assert game.objective_state["target_kills"] == 43


def test_wave_rule_label_hides_standard_and_intermission_labels():
    game = Game.__new__(Game)
    game.active_wave_kind = "standard"
    game.active_wave_objective = None
    game.active_wave_mutator = None
    game.active_wave_twist = None
    game.active_boss_archetype = None
    game.wave_manager = SimpleNamespace(is_intermission=lambda: False)

    assert Game.wave_rule_label(game) == ""

    game.active_wave_mutator = "swarm_protocol"
    assert "Mutator:" in Game.wave_rule_label(game)

    game.wave_manager = SimpleNamespace(is_intermission=lambda: True)
    assert Game.wave_rule_label(game) == ""


def test_wave_rule_label_prefers_boss_hint_and_can_append_wave_twist():
    game = Game.__new__(Game)
    game.active_wave_kind = "standard"
    game.active_wave_objective = None
    game.active_wave_mutator = "swarm_protocol"
    game.active_wave_twist = "elite_surge"
    game.active_boss_archetype = "ravager"
    game.wave_manager = SimpleNamespace(is_intermission=lambda: False)

    boss_label = Game.wave_rule_label(game)
    assert "Boss Tip:" in boss_label

    game.active_boss_archetype = None
    label = Game.wave_rule_label(game)
    assert "Mutator:" in label
    assert "Event:" in label


def test_objective_failure_transitions_to_game_over():
    game = Game.__new__(Game)
    game.state = GameState.PLAYING
    game.active_wave_kind = "objective"
    game.active_wave_objective = "no_hit_window"
    game.objective_state = {"objective_key": "no_hit_window", "elapsed_seconds": 0.0, "target_seconds": 8.0}
    game.player_took_damage_this_frame = True
    game.kills = 0
    game.total_shots_fired = 0
    game.objective_wave_start_kills = 0
    game.objective_wave_start_shots = 0
    game.objective_failed = False
    game.armory_open = True
    game.mutation_drawer_open = True
    game.perk_choice_open = True
    game.pause_open = True
    game.wave_manager = SimpleNamespace(is_intermission=lambda: False)

    flushed: list[bool] = []
    persisted: list[bool] = []
    game.flush_pending_coins = lambda force=False: flushed.append(bool(force))
    game.persist_result = lambda: persisted.append(True)

    Game.update_objective_wave(game, 0.1)

    assert game.objective_failed is True
    assert game.state == GameState.GAME_OVER
    assert flushed == [True]
    assert persisted == [True]


def test_objective_completion_calls_wave_manager_hook():
    game = Game.__new__(Game)
    game.active_wave_kind = "objective"
    game.active_wave_objective = "survive_timer"
    game.objective_state = {"objective_key": "survive_timer", "elapsed_seconds": 3.9, "target_seconds": 4.0}
    game.player_took_damage_this_frame = False
    game.kills = 12
    game.total_shots_fired = 20
    game.objective_wave_start_kills = 0
    game.objective_wave_start_shots = 0
    completed: list[bool] = []
    game.wave_manager = SimpleNamespace(is_intermission=lambda: False, complete_objective_wave=lambda: completed.append(True))

    Game.update_objective_wave(game, 0.2)

    assert completed == [True]


def test_armory_rows_include_explanation_text():
    game = Game.__new__(Game)
    game.weapon_inventory = WeaponInventory()
    game.wave_manager = SimpleNamespace(current_wave=8)
    game.owned_run_weapons = set()
    game.run_upgrade_levels = {key: 0 for key in ARMORY_UPGRADE_DEFINITIONS}
    game.player = Player(0, 0)

    weapon_rows = Game.armory_weapon_rows(game)
    upgrade_rows = Game.armory_upgrade_rows(game)

    assert all(str(row.get("explain", "")).strip() for row in weapon_rows)
    assert all(str(row.get("explain", "")).strip() for row in upgrade_rows)


def test_process_wave_clear_despawns_remaining_enemies_after_objective_wave():
    game = Game.__new__(Game)
    game.active_wave_kind = "objective"
    game.zombies = [Zombie(0, 0)]
    game.projectiles = [Projectile(pygame.Vector2(0, 0), pygame.Vector2(1, 0), speed=0, damage=1)]
    game.wave_manager = SimpleNamespace(current_wave=7, is_boss_wave=lambda wave: False)
    game.score = 0
    game.audio = SimpleNamespace(play_wave_complete=lambda: None)
    game.award_coins = lambda _amount: None
    game.award_run_scrap = lambda _amount: None
    game.maybe_offer_run_perk = lambda _wave: None
    game.wave_banner_duration = 3.5
    game.wave_banner_timer = 0.0
    game.wave_banner_wave = 1

    Game.process_wave_clear(game)

    assert game.zombies == []
    assert game.projectiles == []


def test_update_applies_wave_metadata_from_wave_events():
    game = Game.__new__(Game)
    game.state = GameState.PLAYING
    game.survival_time = 0.0
    game.player_hit_timer = 0.0
    game.coin_flush_timer = 0.0
    game.wave_banner_timer = 0.0
    game.wave_banner_duration = 3.5
    game.armory_message = ""
    game.armory_message_timer = 0.0
    game.fire_button_prev = False
    game.player_speed_multiplier = 1.0
    game.last_aim_direction = pygame.Vector2(1, 0)
    game.world_rect = pygame.Rect(0, 0, 1200, 900)
    game.player = Player(100, 100)
    game.camera = SimpleNamespace(update=lambda _position: None, view_rect=pygame.Rect(0, 0, 800, 600))
    game.weapon_inventory = SimpleNamespace(update_timers=lambda _dt: None, step_fire=lambda **_kwargs: [])
    game.powerups = SimpleNamespace(
        update=lambda _dt: None,
        collect_at_player=lambda _player: [],
        shoot_cooldown_multiplier=1.0,
        zombie_speed_multiplier=1.0,
        drop_chance_multiplier=1.0,
    )
    game.wave_manager = SimpleNamespace(
        current_wave=6,
        is_intermission=lambda: False,
        update=lambda _dt, alive_count: SimpleNamespace(
            spawn_types=[],
            wave_started=True,
            wave_cleared=False,
            wave_kind="objective",
            objective_type="survive_timer",
            mutator_key=None,
        ),
        complete_objective_wave=lambda: None,
    )
    game.zombies = []
    game.projectiles = []
    game.kills = 0
    game.total_shots_fired = 0
    game.run_scrap = 0
    game.wave_powerup_drop_multiplier = 1.0
    game.powerup_drop_multiplier = 1.0
    game.get_movement_input = lambda: pygame.Vector2(0, 0)
    game.get_aim_direction = lambda: pygame.Vector2(1, 0)
    game.should_fire = lambda: False
    game.flush_pending_coins = lambda force=False: None
    game.process_wave_clear = lambda: None
    game.spawn_projectiles = lambda _spawns: None
    game.handle_collisions = lambda: None
    game.armory_open = False
    game.perk_choice_open = False
    game.pause_open = False

    Game.update(game, 0.1)

    assert game.active_wave_kind == "objective"
    assert game.active_wave_objective == "survive_timer"
    assert game.active_wave_mutator is None
    assert game.objective_state["objective_key"] == "survive_timer"


def test_update_applies_boss_archetype_and_wave_twist_on_wave_start():
    game = Game.__new__(Game)
    game.state = GameState.PLAYING
    game.survival_time = 0.0
    game.player_hit_timer = 0.0
    game.coin_flush_timer = 0.0
    game.wave_banner_timer = 0.0
    game.wave_banner_duration = 3.5
    game.wave_banner_wave = 1
    game.wave_banner_is_boss = False
    game.wave_banner_subtitle = ""
    game.armory_message = ""
    game.armory_message_timer = 0.0
    game.fire_button_prev = False
    game.player_speed_multiplier = 1.0
    game.last_aim_direction = pygame.Vector2(1, 0)
    game.world_rect = pygame.Rect(0, 0, 1200, 900)
    game.player = Player(100, 100)
    game.camera = SimpleNamespace(update=lambda _position: None, view_rect=pygame.Rect(0, 0, 800, 600))
    game.weapon_inventory = SimpleNamespace(update_timers=lambda _dt: None, step_fire=lambda **_kwargs: [])
    game.powerups = SimpleNamespace(
        update=lambda _dt: None,
        collect_at_player=lambda _player: [],
        shoot_cooldown_multiplier=1.0,
        zombie_speed_multiplier=1.0,
        drop_chance_multiplier=1.0,
    )
    game.wave_manager = SimpleNamespace(
        current_wave=8,
        is_intermission=lambda: False,
        is_boss_wave=lambda wave=None: True,
        update=lambda _dt, alive_count: SimpleNamespace(
            spawn_types=[],
            wave_started=True,
            wave_cleared=False,
            wave_kind="standard",
            objective_type=None,
            mutator_key="hunter_pack",
            boss_archetype="broodlord",
        ),
        complete_objective_wave=lambda: None,
    )
    game.zombies = []
    game.projectiles = []
    game.kills = 0
    game.total_shots_fired = 0
    game.run_scrap = 0
    game.wave_powerup_drop_multiplier = 1.0
    game.powerup_drop_multiplier = 1.0
    game.get_movement_input = lambda: pygame.Vector2(0, 0)
    game.get_aim_direction = lambda: pygame.Vector2(1, 0)
    game.should_fire = lambda: False
    game.flush_pending_coins = lambda force=False: None
    game.process_wave_clear = lambda: None
    game.spawn_projectiles = lambda _spawns: None
    game.handle_collisions = lambda: None
    game.armory_open = False
    game.perk_choice_open = False
    game.pause_open = False
    game.last_wave_twist = None
    game.choose_wave_twist = lambda wave, kind, is_boss_wave=False: "safe_zone_pulse"

    Game.update(game, 0.1)

    assert game.active_boss_archetype == "broodlord"
    assert game.active_wave_twist == "safe_zone_pulse"
    assert game.wave_banner_is_boss is True
    assert "BOSS:" in game.wave_banner_subtitle
    assert "Broodlord" in game.wave_banner_subtitle


def test_tactical_sling_purchase_unlocks_third_main_slot():
    game = Game.__new__(Game)
    game.weapon_inventory = WeaponInventory()
    game.wave_manager = SimpleNamespace(current_wave=8)
    game.player = Player(0, 0)
    game.run_upgrade_levels = {key: 0 for key in ARMORY_UPGRADE_DEFINITIONS}
    game.extra_weapon_slot_unlocked = False
    game.armory_tab = "upgrades"
    game.run_scrap = 1200
    game.armory_message = ""
    game.armory_message_timer = 0.0

    rows = Game.armory_upgrade_rows(game)
    sling_index = next(i for i, row in enumerate(rows) if row.get("kind") == "extra_slot_unlock")
    game.armory_selection = sling_index

    assert Game.try_buy_armory_selection(game) is True
    assert game.extra_weapon_slot_unlocked is True
    assert game.weapon_inventory.has_extra_slot() is True


def test_handle_weapon_switch_input_supports_slot_three_and_fallback():
    game = Game.__new__(Game)
    game.weapon_inventory = WeaponInventory()
    game.weapon_inventory.unlock_extra_slot()
    game.weapon_inventory.buy_weapon("shotgun")
    game.weapon_inventory.buy_weapon("burst_rifle")
    game.weapon_inventory.buy_weapon("sniper")

    Game.handle_weapon_switch_input(game, pygame.K_3)
    assert game.weapon_inventory.active_state is not None
    assert game.weapon_inventory.active_state.spec_key == "sniper"

    Game.handle_weapon_switch_input(game, pygame.K_0)
    assert game.weapon_inventory.active_state is not None
    assert game.weapon_inventory.active_state.spec_key == "pistol"

    Game.handle_weapon_switch_input(game, pygame.K_2)
    assert game.weapon_inventory.active_state is not None
    assert game.weapon_inventory.active_state.spec_key == "burst_rifle"

    Game.handle_weapon_switch_input(game, pygame.K_4)
    assert game.weapon_inventory.active_state is not None
    assert game.weapon_inventory.active_state.spec_key == "pistol"


def test_armory_refill_rows_allow_refill_of_non_active_owned_weapon():
    game = Game.__new__(Game)
    game.weapon_inventory = WeaponInventory()
    game.wave_manager = SimpleNamespace(current_wave=9)
    game.owned_run_weapons = {"shotgun", "auto_rifle"}

    game.weapon_inventory.buy_weapon("shotgun")
    shotgun_state = game.weapon_inventory.get_owned_weapon_state("shotgun")
    assert shotgun_state is not None
    shotgun_state.ammo_in_mag = 0
    shotgun_state.reserve_ammo = 0

    game.weapon_inventory.buy_weapon("auto_rifle")
    auto_state = game.weapon_inventory.active_state
    assert auto_state is not None
    assert auto_state.spec_key == "auto_rifle"

    rows = Game.armory_weapon_rows(game)
    shotgun_refill = next(row for row in rows if row.get("weapon_key") == "shotgun" and row.get("kind") == "ammo_refill_weapon")
    assert shotgun_refill["enabled"] is True


def test_process_boss_special_attacks_spawns_escort_pack():
    game = Game.__new__(Game)
    game.world_rect = pygame.Rect(0, 0, 2000, 1400)
    game.player = Player(500, 500)
    game.player_hit_timer = 0.0
    game.player_hit_cooldown = 0.45
    game.last_stand_enabled = False
    game.last_stand_available = False
    game.incoming_damage_multiplier = 1.0
    game.wave_mutator_enemy_speed_mult = 1.0
    game.wave_mutator_enemy_health_mult = 1.0
    game.wave_mutator_enemy_damage_mult = 1.0
    game.wave_mutator_elite_bonus = 0.0
    game.active_wave_objective = None
    game.active_wave_mutator = None
    game.elite_spawn_share_for_wave = lambda wave_number=None: 0.0

    boss = Zombie(600, 500, ZombieType.BOSS)
    boss.commander_call_pending = True
    game.zombies = [boss]

    Game.process_boss_special_attacks(game)

    assert len(game.zombies) >= 2
    assert any(zombie.kind in {ZombieType.RUNNER, ZombieType.TANK} for zombie in game.zombies[1:])


def test_process_boss_special_attacks_applies_slam_damage_to_player():
    game = Game.__new__(Game)
    game.world_rect = pygame.Rect(0, 0, 2000, 1400)
    game.player = Player(500, 500)
    game.player_hit_timer = 0.0
    game.player_hit_cooldown = 0.45
    game.last_stand_enabled = False
    game.last_stand_available = False
    game.incoming_damage_multiplier = 1.0
    game.player_took_damage_this_frame = False

    boss = Zombie(500, 500, ZombieType.BOSS)
    boss.slam_pulse_pending = True
    boss.slam_radius = 220.0
    boss.slam_damage = 40
    game.zombies = [boss]

    health_before = game.player.health
    Game.process_boss_special_attacks(game)

    assert game.player.health < health_before
    assert game.player_took_damage_this_frame is True


def test_process_boss_special_attacks_dodges_outer_ring_with_skill_requirements():
    game = Game.__new__(Game)
    game.world_rect = pygame.Rect(0, 0, 2000, 1400)
    game.player = Player(640, 560)
    game.player_velocity = pygame.Vector2(150, 24)
    game.player_hit_timer = 0.0
    game.player_hit_cooldown = 0.45
    game.last_stand_enabled = False
    game.last_stand_available = False
    game.incoming_damage_multiplier = 1.0
    game.player_took_damage_this_frame = False

    boss = Zombie(500, 500, ZombieType.BOSS)
    boss.slam_pulse_pending = True
    boss.slam_radius = 220.0
    boss.slam_damage = 40
    boss.boss_leap_core_radius = 121.0
    boss.boss_leap_commit_player_pos = pygame.Vector2(560, 500)
    boss.boss_leap_axis = pygame.Vector2(1, 0)
    game.zombies = [boss]

    health_before = game.player.health
    Game.process_boss_special_attacks(game)

    assert game.player.health == health_before
    assert game.player_took_damage_this_frame is False
    assert game.player_hit_timer == 0.0


def test_process_boss_special_attacks_outer_ring_still_hits_without_enough_movement():
    game = Game.__new__(Game)
    game.world_rect = pygame.Rect(0, 0, 2000, 1400)
    game.player = Player(640, 560)
    game.player_velocity = pygame.Vector2(170, 18)
    game.player_hit_timer = 0.0
    game.player_hit_cooldown = 0.45
    game.last_stand_enabled = False
    game.last_stand_available = False
    game.incoming_damage_multiplier = 1.0
    game.player_took_damage_this_frame = False

    boss = Zombie(500, 500, ZombieType.BOSS)
    boss.slam_pulse_pending = True
    boss.slam_radius = 220.0
    boss.slam_damage = 40
    boss.boss_leap_core_radius = 121.0
    boss.boss_leap_commit_player_pos = pygame.Vector2(620, 560)
    boss.boss_leap_axis = pygame.Vector2(1, 0)
    game.zombies = [boss]

    health_before = game.player.health
    Game.process_boss_special_attacks(game)

    assert game.player.health < health_before
    assert game.player_took_damage_this_frame is True


def test_process_boss_special_attacks_core_zone_remains_undodgeable():
    game = Game.__new__(Game)
    game.world_rect = pygame.Rect(0, 0, 2000, 1400)
    game.player = Player(550, 500)
    game.player_velocity = pygame.Vector2(220, 0)
    game.player_hit_timer = 0.0
    game.player_hit_cooldown = 0.45
    game.last_stand_enabled = False
    game.last_stand_available = False
    game.incoming_damage_multiplier = 1.0
    game.player_took_damage_this_frame = False

    boss = Zombie(500, 500, ZombieType.BOSS)
    boss.slam_pulse_pending = True
    boss.slam_radius = 220.0
    boss.slam_damage = 40
    boss.boss_leap_core_radius = 121.0
    boss.boss_leap_commit_player_pos = pygame.Vector2(300, 300)
    boss.boss_leap_axis = pygame.Vector2(1, 0)
    game.zombies = [boss]

    health_before = game.player.health
    Game.process_boss_special_attacks(game)

    assert game.player.health < health_before
    assert game.player_took_damage_this_frame is True


def test_process_boss_special_attacks_outside_slam_radius_takes_no_damage():
    game = Game.__new__(Game)
    game.world_rect = pygame.Rect(0, 0, 2000, 1400)
    game.player = Player(760, 500)
    game.player_velocity = pygame.Vector2(180, 0)
    game.player_hit_timer = 0.0
    game.player_hit_cooldown = 0.45
    game.last_stand_enabled = False
    game.last_stand_available = False
    game.incoming_damage_multiplier = 1.0
    game.player_took_damage_this_frame = False

    boss = Zombie(500, 500, ZombieType.BOSS)
    boss.slam_pulse_pending = True
    boss.slam_radius = 220.0
    boss.slam_damage = 40
    boss.boss_leap_core_radius = 121.0
    boss.boss_leap_commit_player_pos = pygame.Vector2(660, 500)
    boss.boss_leap_axis = pygame.Vector2(1, 0)
    game.zombies = [boss]

    health_before = game.player.health
    Game.process_boss_special_attacks(game)

    assert game.player.health == health_before
    assert game.player_took_damage_this_frame is False


def test_process_boss_special_attacks_zone_cast_spawns_hazards_without_prearm_damage():
    game = Game.__new__(Game)
    game.world_rect = pygame.Rect(0, 0, 2000, 1400)
    game.player = Player(500, 500)
    game.player_hit_timer = 0.0
    game.player_hit_cooldown = 0.45
    game.last_stand_enabled = False
    game.last_stand_available = False
    game.incoming_damage_multiplier = 1.0
    game.player_took_damage_this_frame = False
    game.active_boss_hazards = []

    boss = Zombie(500, 500, ZombieType.BOSS)
    boss.set_boss_archetype(BossArchetype.ZONE_CASTER)
    boss.zone_cast_pending = True
    boss.zone_cast_centers = [pygame.Vector2(500, 500), pygame.Vector2(620, 500), pygame.Vector2(380, 500)]
    boss.zone_cast_radius = 104.0
    boss.zone_cast_damage = 22
    boss.zone_cast_arm_time = 0.65
    boss.zone_cast_active_time = 1.25
    boss.zone_cast_tick_interval = 0.30
    game.zombies = [boss]

    Game.process_boss_special_attacks(game)
    assert len(game.active_boss_hazards) == 3
    health_before = game.player.health
    Game.update_boss_hazards(game, 0.30)
    assert game.player.health == health_before


def test_zone_hazard_applies_damage_inside_radius_only_after_arm():
    game = Game.__new__(Game)
    game.world_rect = pygame.Rect(0, 0, 2000, 1400)
    game.player = Player(500, 500)
    game.player_hit_timer = 0.0
    game.player_hit_cooldown = 0.45
    game.last_stand_enabled = False
    game.last_stand_available = False
    game.incoming_damage_multiplier = 1.0
    game.player_took_damage_this_frame = False
    game.active_boss_hazards = [
        {
            "center": pygame.Vector2(500, 500),
            "radius": 104.0,
            "damage": 22,
            "arm_time": 0.0,
            "active_time": 1.25,
            "tick_interval": 0.30,
            "tick_timer": 0.0,
        }
    ]
    health_before = game.player.health
    Game.update_boss_hazards(game, 0.31)
    assert game.player.health < health_before

    game.player = Player(700, 700)
    game.player_hit_timer = 0.0
    game.player_took_damage_this_frame = False
    game.active_boss_hazards = [
        {
            "center": pygame.Vector2(500, 500),
            "radius": 104.0,
            "damage": 22,
            "arm_time": 0.0,
            "active_time": 1.25,
            "tick_interval": 0.30,
            "tick_timer": 0.0,
        }
    ]
    outside_health = game.player.health
    Game.update_boss_hazards(game, 0.31)
    assert game.player.health == outside_health


def test_process_boss_special_attacks_ambush_hits_inside_corridor_and_sets_lockout():
    game = Game.__new__(Game)
    game.world_rect = pygame.Rect(0, 0, 2000, 1400)
    game.player = Player(560, 500)
    game.player_hit_timer = 0.0
    game.player_hit_cooldown = 0.45
    game.last_stand_enabled = False
    game.last_stand_available = False
    game.incoming_damage_multiplier = 1.0
    game.player_took_damage_this_frame = False
    game.boss_contact_damage_lockout_timer = 0.0

    boss = Zombie(500, 500, ZombieType.BOSS)
    boss.ambush_pulse_pending = True
    boss.ambush_origin = pygame.Vector2(500, 500)
    boss.ambush_direction = pygame.Vector2(1, 0)
    boss.ambush_length = 210.0
    boss.ambush_half_width = 38.0
    boss.ambush_damage = 40
    boss.ambush_contact_lockout = 0.25
    game.zombies = [boss]

    health_before = game.player.health
    Game.process_boss_special_attacks(game)
    assert game.player.health < health_before
    assert game.boss_contact_damage_lockout_timer >= 0.25


def test_process_boss_special_attacks_ambush_misses_outside_corridor():
    game = Game.__new__(Game)
    game.world_rect = pygame.Rect(0, 0, 2000, 1400)
    game.player = Player(560, 560)
    game.player_hit_timer = 0.0
    game.player_hit_cooldown = 0.45
    game.last_stand_enabled = False
    game.last_stand_available = False
    game.incoming_damage_multiplier = 1.0
    game.player_took_damage_this_frame = False
    game.boss_contact_damage_lockout_timer = 0.0

    boss = Zombie(500, 500, ZombieType.BOSS)
    boss.ambush_pulse_pending = True
    boss.ambush_origin = pygame.Vector2(500, 500)
    boss.ambush_direction = pygame.Vector2(1, 0)
    boss.ambush_length = 210.0
    boss.ambush_half_width = 38.0
    boss.ambush_damage = 40
    boss.ambush_contact_lockout = 0.25
    game.zombies = [boss]

    health_before = game.player.health
    Game.process_boss_special_attacks(game)
    assert game.player.health == health_before
    assert game.boss_contact_damage_lockout_timer >= 0.25


def test_contact_lockout_blocks_immediate_overlap_damage():
    game = Game.__new__(Game)
    game.player = Player(500, 500)
    game.player_hit_timer = 0.0
    game.player_hit_cooldown = 0.45
    game.last_stand_enabled = False
    game.last_stand_available = False
    game.incoming_damage_multiplier = 1.0
    game.player_took_damage_this_frame = False
    game.projectiles = []
    game.zombies = [Zombie(500, 500, ZombieType.BOSS)]
    game.boss_contact_damage_lockout_timer = 0.25

    health_before = game.player.health
    Game.handle_collisions(game)
    assert game.player.health == health_before

from types import SimpleNamespace

import pygame

from game.main import Game, GameState


def test_initialize_player_from_settings_prefills_username_and_stays_guest(monkeypatch):
    game = Game.__new__(Game)
    game.player_name = "Old"
    game.player_profile_id = 5
    game.player_coins = 120
    game.shop_items = [{"x": 1}]
    game.menu_message = "x"

    monkeypatch.setattr("game.main.settings.load_last_player_name", lambda: "Alice")

    Game.initialize_player_from_settings(game)

    assert game.login_username_input == "Alice"
    assert game.login_password_input == ""
    assert game.login_active_field == "username"
    assert game.login_error == ""
    assert game.player_name == ""
    assert game.player_profile_id is None
    assert game.player_coins == 0
    assert game.shop_items == []
    assert game.menu_message == ""


def test_play_menu_item_opens_visual_mode_selector_for_guest():
    game = Game.__new__(Game)
    game.menu_selection = 0
    game.state = GameState.MENU
    game.visual_mode_selection = 2

    Game.activate_menu_selection(game)

    assert game.state == GameState.VISUAL_MODE_SELECT
    assert game.visual_mode_selection == 0


def test_login_menu_item_opens_login_screen_for_guest():
    game = Game.__new__(Game)
    game.menu_selection = 1
    game.player_name = ""
    game.player_profile_id = None

    called = {"value": False}
    game.open_login_screen = lambda: called.__setitem__("value", True)

    Game.activate_menu_selection(game)

    assert called["value"] is True


def test_login_menu_item_logs_out_for_authenticated_user():
    game = Game.__new__(Game)
    game.menu_selection = 1
    game.player_name = "Bob"
    game.player_profile_id = 17
    game.menu_message = ""

    called = {"value": False}
    game.logout_profile = lambda: called.__setitem__("value", True)

    Game.activate_menu_selection(game)

    assert called["value"] is True
    assert "Logged out" in game.menu_message


def test_guest_shop_menu_item_stays_on_menu_with_feedback():
    game = Game.__new__(Game)
    game.menu_selection = 2
    game.player_name = ""
    game.player_profile_id = None
    game.state = GameState.MENU
    game.menu_message = ""

    Game.activate_menu_selection(game)

    assert game.state == GameState.MENU
    assert "Login required" in game.menu_message


def test_authenticated_shop_menu_item_opens_shop():
    game = Game.__new__(Game)
    game.menu_selection = 2
    game.player_name = "ShopUser"
    game.player_profile_id = 12
    game.state = GameState.MENU
    game.menu_message = ""
    game.shop_selection = 9

    refreshed = {"value": False}
    game.refresh_shop_items = lambda: refreshed.__setitem__("value", True)

    Game.activate_menu_selection(game)

    assert refreshed["value"] is True
    assert game.shop_selection == 0
    assert game.state == GameState.SHOP


def test_handle_login_event_escape_returns_to_menu():
    game = Game.__new__(Game)
    game.state = GameState.LOGIN
    game.login_username_input = "Alice"
    game.login_password_input = "secret"
    game.login_active_field = "password"
    game.login_error = "x"

    event = SimpleNamespace(type=pygame.KEYDOWN, key=pygame.K_ESCAPE, unicode="")
    Game.handle_login_event(game, event)

    assert game.state == GameState.MENU
    assert game.login_password_input == ""
    assert game.login_error == ""
    assert game.login_active_field == "username"


def test_handle_login_event_field_switch_and_backspace():
    game = Game.__new__(Game)
    game.state = GameState.LOGIN
    game.login_username_input = "Alice"
    game.login_password_input = "secret"
    game.login_active_field = "username"
    game.login_error = ""

    tab_event = SimpleNamespace(type=pygame.KEYDOWN, key=pygame.K_TAB, unicode="")
    Game.handle_login_event(game, tab_event)
    assert game.login_active_field == "password"

    backspace_event = SimpleNamespace(type=pygame.KEYDOWN, key=pygame.K_BACKSPACE, unicode="")
    Game.handle_login_event(game, backspace_event)
    assert game.login_password_input == "secre"


def test_attempt_login_success(monkeypatch):
    game = Game.__new__(Game)
    game.state = GameState.LOGIN
    game.login_username_input = "alice"
    game.login_password_input = "good-pass"
    game.login_active_field = "password"
    game.login_error = "old"
    game.menu_message = ""
    game.player_name = ""
    game.player_profile_id = None

    loaded_names: list[str] = []
    saved_usernames: list[str] = []

    def fake_auth(_username: str, _password: str):
        return {"username": "alice", "player_name": "Alice", "player_id": 3, "user_id": 4}

    def fake_load_profile(name: str) -> None:
        loaded_names.append(name)
        game.player_name = name
        game.player_profile_id = 3
        game.player_coins = 15

    monkeypatch.setattr("game.main.database.authenticate_web_user", fake_auth)
    monkeypatch.setattr("game.main.settings.save_last_player_name", lambda name: saved_usernames.append(name))
    game.load_player_profile = fake_load_profile

    assert Game.attempt_login(game) is True
    assert game.state == GameState.MENU
    assert loaded_names == ["Alice"]
    assert saved_usernames == ["alice"]
    assert game.login_password_input == ""
    assert game.login_error == ""
    assert "Logged in as Alice" in game.menu_message


def test_attempt_login_invalid_credentials(monkeypatch):
    game = Game.__new__(Game)
    game.state = GameState.LOGIN
    game.login_username_input = "alice"
    game.login_password_input = "bad-pass"
    game.login_error = ""

    monkeypatch.setattr("game.main.database.authenticate_web_user", lambda _u, _p: None)

    assert Game.attempt_login(game) is False
    assert game.state == GameState.LOGIN
    assert game.login_error == "Invalid username or password."


def test_persist_result_saves_guest_when_not_authenticated(monkeypatch):
    game = Game.__new__(Game)
    game.score_saved = False
    game.score = 42
    game.survival_time = 12.3
    game.player_name = ""
    game.player_profile_id = None
    game.leaderboard_lines = []
    game.flush_pending_coins = lambda force=False: None
    game.get_leaderboard_lines = lambda: ["Guest | 42 | now"]

    saved_storage_names: list[str] = []
    saved_db_names: list[str] = []
    monkeypatch.setattr("game.main.storage.save_score", lambda name, *_args, **_kwargs: saved_storage_names.append(name))
    monkeypatch.setattr(
        "game.main.database.save_match_result",
        lambda name, *_args, **_kwargs: saved_db_names.append(name),
    )

    Game.persist_result(game)

    assert saved_storage_names == ["Guest"]
    assert saved_db_names == ["Guest"]


def test_persist_result_saves_authenticated_name(monkeypatch):
    game = Game.__new__(Game)
    game.score_saved = False
    game.score = 99
    game.survival_time = 33.1
    game.player_name = "Alice"
    game.player_profile_id = 7
    game.leaderboard_lines = []
    game.flush_pending_coins = lambda force=False: None
    game.get_leaderboard_lines = lambda: ["Alice | 99 | now"]

    saved_names: list[str] = []
    monkeypatch.setattr("game.main.storage.save_score", lambda name, *_args, **_kwargs: saved_names.append(name))
    monkeypatch.setattr("game.main.database.save_match_result", lambda name, *_args, **_kwargs: None)

    Game.persist_result(game)

    assert saved_names == ["Alice"]

import pygame

from game.ui import draw_wave_banner, get_wave_banner_animation


def test_wave_banner_alpha_curve():
    duration = 3.5

    _, start_alpha = get_wave_banner_animation(remaining=duration, duration=duration)
    _, mid_alpha = get_wave_banner_animation(remaining=duration * 0.5, duration=duration)
    _, end_alpha = get_wave_banner_animation(remaining=0.0, duration=duration)

    assert start_alpha == 0
    assert mid_alpha == 255
    assert end_alpha == 0


def test_wave_banner_scale_increases_over_time():
    duration = 3.5

    start_scale, _ = get_wave_banner_animation(remaining=duration, duration=duration)
    mid_scale, _ = get_wave_banner_animation(remaining=duration * 0.5, duration=duration)
    end_scale, _ = get_wave_banner_animation(remaining=0.0, duration=duration)

    assert start_scale < mid_scale < end_scale


def test_draw_wave_banner_supports_boss_subtitle_without_error():
    pygame.init()
    screen = pygame.Surface((1000, 700))
    draw_wave_banner(
        screen=screen,
        wave=12,
        remaining=2.2,
        duration=3.5,
        is_boss=True,
        subtitle="BOSS: Broodlord",
    )
    assert screen.get_at((500, 340)) != pygame.Color(0, 0, 0, 255)

﻿from game.enemy import ZombieType
from game.waves import WaveManager, WavePhase


def test_intermission_transitions_to_active_wave():
    manager = WaveManager(intermission_duration=0.5)
    manager.start_first_wave()

    events = manager.update(0.6, alive_count=0)

    assert events.wave_started is True
    assert manager.phase == WavePhase.ACTIVE
    assert manager.to_spawn == manager._spawn_budget_for_wave(1)


def test_wave_clear_starts_next_intermission():
    manager = WaveManager(intermission_duration=0.1)
    manager.start_first_wave()
    manager.update(0.2, alive_count=0)

    manager.to_spawn = 0
    events = manager.update(0.1, alive_count=0)

    assert events.wave_cleared is True
    assert manager.current_wave == 2
    assert manager.phase == WavePhase.INTERMISSION


def test_spawn_budget_scales_with_wave():
    assert WaveManager._spawn_budget_for_wave(1) == 15
    assert WaveManager._spawn_budget_for_wave(4) == 26
    assert WaveManager._spawn_budget_for_wave(7) == 36


def test_spawn_interval_scales_with_wave():
    assert abs(WaveManager._spawn_interval_for_wave(1) - 0.682) < 1e-6
    assert abs(WaveManager._spawn_interval_for_wave(4) - 0.568) < 1e-6
    assert WaveManager._spawn_interval_for_wave(30) == 0.18


def test_spawn_type_unlock_curve():
    manager = WaveManager(intermission_duration=0.0)

    manager.current_wave = 1
    for _ in range(30):
        assert manager._pick_spawn_type() in {ZombieType.WALKER, ZombieType.RUNNER}
    assert any(manager._pick_spawn_type() == ZombieType.RUNNER for _ in range(80))

    manager.current_wave = 3
    for _ in range(30):
        assert manager._pick_spawn_type() in {ZombieType.WALKER, ZombieType.RUNNER, ZombieType.TANK}

    manager.current_wave = 6
    for _ in range(30):
        assert manager._pick_spawn_type() in {ZombieType.WALKER, ZombieType.RUNNER, ZombieType.TANK}


def test_boss_wave_detection():
    manager = WaveManager(intermission_duration=0.0)
    assert manager.is_boss_wave(3) is False
    assert manager.is_boss_wave(4) is True
    assert manager.is_boss_wave(8) is True


def test_boss_wave_spawns_boss_type():
    manager = WaveManager(intermission_duration=0.0)
    manager.current_wave = 4
    manager.phase = WavePhase.INTERMISSION
    manager.intermission_remaining = 0.0

    start = manager.update(0.0, alive_count=0)
    assert start.wave_started is True
    assert manager.boss_spawn_pending == 1

    active = manager.update(0.1, alive_count=1)
    assert ZombieType.BOSS in active.spawn_types


def test_boss_archetype_emitted_only_when_boss_wave_starts():
    manager = WaveManager(intermission_duration=0.0)
    manager.current_wave = 4
    manager.phase = WavePhase.INTERMISSION
    manager.intermission_remaining = 0.0

    start = manager.update(0.0, alive_count=0)
    assert start.wave_started is True
    assert start.boss_archetype in {"warden", "ravager", "broodlord", "phantom", "zone_caster", "stealth_assassin"}

    tick = manager.update(0.1, alive_count=1)
    assert tick.boss_archetype is None

    manager.current_wave = 5
    manager.phase = WavePhase.INTERMISSION
    manager.intermission_remaining = 0.0
    non_boss = manager.update(0.0, alive_count=0)
    assert non_boss.wave_started is True
    assert non_boss.boss_archetype is None


def test_boss_archetype_weights_penalize_repeat_and_favor_unseen():
    manager = WaveManager(intermission_duration=0.0)
    manager.last_boss_archetype = "warden"
    manager.boss_archetype_counts = {
        "warden": 2,
        "ravager": 0,
        "broodlord": 1,
        "phantom": 1,
        "zone_caster": 1,
        "stealth_assassin": 1,
    }
    weights = manager._boss_archetype_weight_table()
    assert weights["warden"] == 0.2
    assert weights["ravager"] == 1.8
    assert weights["broodlord"] == 1.0
    assert weights["phantom"] == 1.0
    assert weights["zone_caster"] == 1.0
    assert weights["stealth_assassin"] == 1.0


def test_pick_boss_archetype_forces_unseen_pool_before_repeats(monkeypatch):
    manager = WaveManager(intermission_duration=0.0)
    manager.last_boss_archetype = "warden"
    manager.boss_archetype_counts = {
        "warden": 1,
        "ravager": 0,
        "broodlord": 0,
        "phantom": 1,
        "zone_caster": 0,
        "stealth_assassin": 1,
    }
    captured: dict[str, list[float]] = {}

    def fake_choices(population, weights, k):
        captured["population"] = list(population)
        captured["weights"] = list(weights)
        return [population[0]]

    monkeypatch.setattr("game.waves.random.choices", fake_choices)

    picked = manager._pick_boss_archetype()
    assert picked in {"ravager", "broodlord", "zone_caster"}
    assert captured["population"] == ["ravager", "broodlord", "zone_caster"]


def test_preview_next_boss_archetype_prefers_best_weight_candidate():
    manager = WaveManager(intermission_duration=0.0)
    manager.current_wave = 8
    manager.last_boss_archetype = "ravager"
    manager.boss_archetype_counts = {
        "warden": 3,
        "ravager": 1,
        "broodlord": 0,
        "phantom": 1,
        "zone_caster": 1,
        "stealth_assassin": 1,
    }

    preview = manager.preview_next_boss_archetype()
    assert preview == "broodlord"


def test_objective_wave_cadence_from_wave_six():
    assert WaveManager.is_objective_wave(5) is False
    assert WaveManager.is_objective_wave(6) is True
    assert WaveManager.is_objective_wave(7) is False
    assert WaveManager.is_objective_wave(10) is True
    assert WaveManager.is_objective_wave(14) is True


def test_wave_start_events_include_objective_and_mutator_metadata():
    manager = WaveManager(intermission_duration=0.0)
    manager.current_wave = 6
    manager.phase = WavePhase.INTERMISSION
    manager.intermission_remaining = 0.0

    wave6 = manager.update(0.0, alive_count=0)
    assert wave6.wave_started is True
    assert wave6.wave_kind == "objective"
    assert wave6.objective_type == "survive_timer"
    assert wave6.mutator_key is None

    manager.current_wave = 7
    manager.phase = WavePhase.INTERMISSION
    manager.intermission_remaining = 0.0
    wave7 = manager.update(0.0, alive_count=0)
    assert wave7.wave_started is True
    assert wave7.wave_kind == "standard"
    assert wave7.objective_type is None
    assert wave7.mutator_key == "swarm_protocol"


def test_mutator_rotation_skips_objective_slots():
    manager = WaveManager(intermission_duration=0.0)
    assert manager._mutator_for_wave(7, "standard") == "swarm_protocol"
    assert manager._mutator_for_wave(8, "standard") == "fortified_horde"
    assert manager._mutator_for_wave(9, "standard") == "hunter_pack"
    assert manager._mutator_for_wave(11, "standard") == "nightmare_fog"
    assert manager._mutator_for_wave(12, "standard") == "scarcity_protocol"
    assert manager._mutator_for_wave(13, "standard") == "swarm_protocol"


def test_objective_wave_does_not_clear_until_completed():
    manager = WaveManager(intermission_duration=0.0)
    manager.current_wave = 6
    manager.phase = WavePhase.INTERMISSION
    manager.intermission_remaining = 0.0
    manager.update(0.0, alive_count=0)

    manager.to_spawn = 0
    manager.boss_spawn_pending = 0
    manager.objective_completed = False

    still_active = manager.update(0.1, alive_count=0)
    assert still_active.wave_cleared is False
    assert manager.phase == WavePhase.ACTIVE

    manager.complete_objective_wave()
    cleared = manager.update(0.1, alive_count=0)
    assert cleared.wave_cleared is True
    assert manager.current_wave == 7
    assert manager.phase == WavePhase.INTERMISSION


def test_objective_spawn_modifiers_match_rebalance_targets():
    manager = WaveManager(intermission_duration=0.0)

    manager.active_objective_type = "survive_timer"
    budget_mult, interval_mult = manager._spawn_modifiers_for_current_wave()
    assert abs(budget_mult - 1.45) < 1e-6
    assert abs(interval_mult - 0.72) < 1e-6

    manager.active_objective_type = "kill_quota"
    budget_mult, interval_mult = manager._spawn_modifiers_for_current_wave()
    assert abs(budget_mult - 1.24) < 1e-6
    assert abs(interval_mult - 0.84) < 1e-6


def test_late_wave_spawn_weights_favor_runner_over_slow_cleanup(monkeypatch):
    manager = WaveManager(intermission_duration=0.0)
    manager.current_wave = 26
    captured: dict[str, list[float]] = {}

    def fake_choices(population, weights, k):
        captured["weights"] = list(weights)
        return [population[1]]

    monkeypatch.setattr("game.waves.random.choices", fake_choices)

    picked = manager._pick_spawn_type()
    assert picked == ZombieType.RUNNER

    walker_weight, runner_weight, tank_weight = captured["weights"]
    assert runner_weight > walker_weight
    assert runner_weight > tank_weight
    assert walker_weight >= 0.18
    assert tank_weight <= 0.24

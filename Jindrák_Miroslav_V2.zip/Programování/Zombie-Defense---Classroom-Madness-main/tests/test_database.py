﻿from pathlib import Path

from game import database


def test_register_and_save_result(tmp_path: Path):
    db_path = tmp_path / "game.db"
    schema_path = Path("database/schema.sql")

    database.init_db(db_path=db_path, schema_path=schema_path)

    original = database.DB_PATH
    database.DB_PATH = db_path
    try:
        player_id = database.register_player("TestPlayer", "test@example.com")
        assert player_id > 0

        profile = database.get_player_profile("TestPlayer")
        assert profile["coins"] == 0

        balance = database.add_player_coins(player_id, 75)
        assert balance == 75

        database.save_match_result("TestPlayer", 42, 12.3)
        leaderboard = database.get_leaderboard(5)
        assert leaderboard
        assert leaderboard[0]["jmeno"] == "TestPlayer"
        assert leaderboard[0]["skore"] == 42
    finally:
        database.DB_PATH = original


def test_skin_unlock_and_selection_workflow(tmp_path: Path):
    db_path = tmp_path / "game.db"
    schema_path = Path("database/schema.sql")

    database.init_db(db_path=db_path, schema_path=schema_path)

    original = database.DB_PATH
    database.DB_PATH = db_path
    try:
        player_id = database.register_player("SkinUser")
        shop = database.get_shop_skins(player_id)
        assert shop

        default_skin = next(item for item in shop if item["is_default"])
        assert default_skin["owned"] is True
        assert default_skin["selected"] is True

        locked_skin = next(item for item in shop if not item["owned"])
        success, status = database.unlock_skin(player_id, locked_skin["skin_key"])
        assert success is False
        assert status == "insufficient_coins"

        database.add_player_coins(player_id, 1000)
        success, status = database.unlock_skin(player_id, locked_skin["skin_key"])
        assert success is True
        assert status in {"unlocked", "already_owned"}

        selected_skin = database.get_selected_skin(player_id)
        assert selected_skin["skin_key"] == locked_skin["skin_key"]

        assert database.select_skin(player_id, "classic") is True
        selected_skin = database.get_selected_skin(player_id)
        assert selected_skin["skin_key"] == "classic"
    finally:
        database.DB_PATH = original

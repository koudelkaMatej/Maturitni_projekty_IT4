import pygame

from game.enemy import BOSS_LEAP_DODGE_CORE_RATIO, BOSS_LEAP_WINDUP, BossArchetype, ZOMBIE_STATS, Zombie, ZombieType


def test_zombie_stats_table_values():
    assert ZOMBIE_STATS[ZombieType.WALKER].max_health == 40
    assert ZOMBIE_STATS[ZombieType.RUNNER].speed == 185
    assert ZOMBIE_STATS[ZombieType.TANK].damage == 18
    assert ZOMBIE_STATS[ZombieType.BOSS].max_health > ZOMBIE_STATS[ZombieType.TANK].max_health


def test_take_damage_returns_death_state():
    zombie = Zombie(10, 10, ZombieType.WALKER)
    assert zombie.take_damage(10) is False
    assert zombie.health == 30

    assert zombie.take_damage(30) is True
    assert zombie.health == 0


def test_spawn_near_view_respects_world_bounds():
    world = pygame.Rect(0, 0, 2000, 1400)
    view = pygame.Rect(600, 300, 900, 700)

    for _ in range(30):
        zombie = Zombie.spawn_near_view(world, view, ZombieType.RUNNER)
        assert world.collidepoint(zombie.position.x, zombie.position.y)
        assert zombie.kind == ZombieType.RUNNER


def test_micro_overlap_fix_prevents_exact_stacking():
    z1 = Zombie(120, 120, ZombieType.WALKER)
    z2 = Zombie(120, 120, ZombieType.WALKER)

    player_pos = pygame.Vector2(120, 260)
    for _ in range(4):
        z1.update(0.05, player_pos, nearby_zombies=[z2], player_velocity=pygame.Vector2(0, 0), pack_pressure=0.6)
        z2.update(0.05, player_pos, nearby_zombies=[z1], player_velocity=pygame.Vector2(0, 0), pack_pressure=0.6)

    after = z1.position.distance_to(z2.position)
    assert after > 0.0


def test_normal_close_clumping_is_still_allowed():
    z1 = Zombie(120, 120, ZombieType.WALKER)
    z2 = Zombie(147, 120, ZombieType.WALKER)

    player_pos = pygame.Vector2(200, 220)
    for _ in range(6):
        z1.update(0.05, player_pos, nearby_zombies=[z2], player_velocity=pygame.Vector2(0, 0), pack_pressure=0.9)
        z2.update(0.05, player_pos, nearby_zombies=[z1], player_velocity=pygame.Vector2(0, 0), pack_pressure=0.9)

    assert z1.position.distance_to(z2.position) < 48.0


def test_predictive_intercept_tracks_moving_player_better_than_static_chase():
    moving_player_pos = pygame.Vector2(220, 0)
    moving_player_velocity = pygame.Vector2(0, 220)

    static_chase = Zombie(0, 0, ZombieType.WALKER)
    intercept_chase = Zombie(0, 0, ZombieType.WALKER)

    static_chase.update(0.35, moving_player_pos, nearby_zombies=[], player_velocity=pygame.Vector2(0, 0), pack_pressure=0.0)
    intercept_chase.update(0.35, moving_player_pos, nearby_zombies=[], player_velocity=moving_player_velocity, pack_pressure=0.8)

    assert intercept_chase.position.y > static_chase.position.y + 3.0


def test_opposite_flank_biases_move_to_opposite_lateral_sides():
    left_role = Zombie(0, 0, ZombieType.WALKER)
    right_role = Zombie(0, 0, ZombieType.WALKER)

    target = pygame.Vector2(180, 0)
    vel = pygame.Vector2(160, 0)
    left_role.update(0.28, target, nearby_zombies=[], player_velocity=vel, role="flank_left", pack_pressure=0.8)
    right_role.update(0.28, target, nearby_zombies=[], player_velocity=vel, role="flank_right", pack_pressure=0.8)

    assert left_role.position.y < 0.0
    assert right_role.position.y > 0.0


def test_role_burst_activates_then_cools_down():
    zombie = Zombie(0, 0, ZombieType.WALKER)
    zombie.burst_cooldown = 0.0

    target = pygame.Vector2(180, 0)
    vel = pygame.Vector2(180, 0)
    zombie.update(0.10, target, player_velocity=vel, role="cutter_left", pack_pressure=1.0, nearby_zombies=[])

    assert zombie.burst_timer > 0.0
    speed_during_burst = zombie.speed
    assert speed_during_burst > zombie.base_speed

    for _ in range(30):
        zombie.update(0.10, target, player_velocity=vel, role="chase", pack_pressure=0.0, nearby_zombies=[])

    assert zombie.burst_timer == 0.0
    assert zombie.burst_cooldown >= 0.0


def test_boss_phase_thresholds_update_by_health():
    boss = Zombie(0, 0, ZombieType.BOSS)
    assert boss.boss_phase == 1

    boss.take_damage(int(boss.max_health * 0.35))
    assert boss.boss_phase == 2

    boss.take_damage(int(boss.max_health * 0.40))
    assert boss.boss_phase == 3


def test_boss_charge_and_leap_trigger_speed_spikes():
    boss = Zombie(0, 0, ZombieType.BOSS)
    boss.boss_charge_cooldown = 0.0
    boss.boss_leap_cooldown = 0.0
    boss.boss_commander_cooldown = 999.0

    player_pos = pygame.Vector2(220, 0)
    player_vel = pygame.Vector2(140, 0)
    boss.update(0.1, player_pos, player_velocity=player_vel, nearby_zombies=[], pack_pressure=0.8)
    boss.update(0.30, player_pos, player_velocity=player_vel, nearby_zombies=[], pack_pressure=0.8)

    assert boss.speed > boss.base_speed
    assert boss.boss_charge_timer > 0.0 or boss.boss_leap_timer > 0.0


def test_boss_commander_call_emits_once_per_ready_window():
    boss = Zombie(0, 0, ZombieType.BOSS)
    boss.boss_commander_cooldown = 0.0
    boss.boss_charge_cooldown = 999.0
    boss.boss_leap_cooldown = 999.0
    boss.update(0.1, pygame.Vector2(300, 0), player_velocity=pygame.Vector2(0, 0), nearby_zombies=[], pack_pressure=0.0)
    assert boss.boss_commander_cast_timer > 0.0

    boss.update(1.0, pygame.Vector2(300, 0), player_velocity=pygame.Vector2(0, 0), nearby_zombies=[], pack_pressure=0.0)
    assert boss.consume_commander_call() is True
    assert boss.consume_commander_call() is False


def test_boss_leap_finishes_with_slam_pulse():
    boss = Zombie(0, 0, ZombieType.BOSS)
    boss.boss_leap_cooldown = 0.0
    boss.boss_charge_cooldown = 999.0
    boss.boss_commander_cooldown = 999.0

    boss.update(0.05, pygame.Vector2(180, 0), player_velocity=pygame.Vector2(0, 0), nearby_zombies=[], pack_pressure=0.6)
    boss.update(0.40, pygame.Vector2(180, 0), player_velocity=pygame.Vector2(0, 0), nearby_zombies=[], pack_pressure=0.6)
    boss.update(0.60, pygame.Vector2(180, 0), player_velocity=pygame.Vector2(0, 0), nearby_zombies=[], pack_pressure=0.6)
    boss.update(0.40, pygame.Vector2(180, 0), player_velocity=pygame.Vector2(0, 0), nearby_zombies=[], pack_pressure=0.6)

    slam = boss.consume_slam_pulse()
    assert slam is not None
    radius, damage = slam
    assert radius > 0.0
    assert damage > 0


def test_boss_leap_telegraph_radius_matches_impact_radius_and_core_ratio():
    boss = Zombie(0, 0, ZombieType.BOSS)
    boss.boss_leap_cooldown = 0.0
    boss.boss_charge_cooldown = 999.0
    boss.boss_commander_cooldown = 999.0

    target = pygame.Vector2(220, 0)
    boss.update(0.05, target, player_velocity=pygame.Vector2(), nearby_zombies=[], pack_pressure=0.6)
    assert boss.boss_leap_windup_timer > 0.0
    preview_radius = boss.boss_leap_preview_radius
    core_radius = boss.boss_leap_core_radius
    assert preview_radius > 0.0
    assert abs(core_radius - preview_radius * BOSS_LEAP_DODGE_CORE_RATIO) < 1e-6

    boss.update(0.60, target, player_velocity=pygame.Vector2(), nearby_zombies=[], pack_pressure=0.6)
    boss.update(0.40, target, player_velocity=pygame.Vector2(), nearby_zombies=[], pack_pressure=0.6)
    slam = boss.consume_slam_pulse()
    assert slam is not None
    impact_radius, _ = slam
    assert abs(impact_radius - preview_radius) < 1e-6


def test_boss_archetype_profiles_apply_expected_runtime_multipliers():
    warden = Zombie(0, 0, ZombieType.BOSS)
    ravager = Zombie(0, 0, ZombieType.BOSS)
    broodlord = Zombie(0, 0, ZombieType.BOSS)
    phantom = Zombie(0, 0, ZombieType.BOSS)
    zone_caster = Zombie(0, 0, ZombieType.BOSS)
    stealth_assassin = Zombie(0, 0, ZombieType.BOSS)

    warden.set_boss_archetype(BossArchetype.WARDEN)
    ravager.set_boss_archetype(BossArchetype.RAVAGER)
    broodlord.set_boss_archetype(BossArchetype.BROODLORD)
    phantom.set_boss_archetype(BossArchetype.PHANTOM)
    zone_caster.set_boss_archetype(BossArchetype.ZONE_CASTER)
    stealth_assassin.set_boss_archetype(BossArchetype.STEALTH_ASSASSIN)

    assert warden.max_health > ZOMBIE_STATS[ZombieType.BOSS].max_health
    assert warden.boss_slam_radius_mult > 1.0
    assert warden.boss_slam_damage_mult > 1.0
    assert ravager.max_health < ZOMBIE_STATS[ZombieType.BOSS].max_health
    assert ravager.base_speed > ZOMBIE_STATS[ZombieType.BOSS].speed
    assert ravager.boss_charge_cooldown_mult == 0.75
    assert broodlord.damage < ZOMBIE_STATS[ZombieType.BOSS].damage
    assert broodlord.boss_commander_cooldown_mult == 0.65
    assert phantom.max_health < ZOMBIE_STATS[ZombieType.BOSS].max_health
    assert phantom.base_speed > ZOMBIE_STATS[ZombieType.BOSS].speed
    assert phantom.boss_leap_cooldown_mult < 1.0
    assert phantom.boss_slam_damage_mult < 1.0
    assert zone_caster.max_health > ZOMBIE_STATS[ZombieType.BOSS].max_health
    assert zone_caster.base_speed < ZOMBIE_STATS[ZombieType.BOSS].speed
    assert zone_caster.boss_commander_cooldown_mult < 1.0
    assert stealth_assassin.max_health < ZOMBIE_STATS[ZombieType.BOSS].max_health
    assert stealth_assassin.base_speed > ZOMBIE_STATS[ZombieType.BOSS].speed
    assert stealth_assassin.boss_charge_cooldown_mult > 1.0


def test_boss_leap_windup_matches_original_tuning():
    assert abs(BOSS_LEAP_WINDUP - 0.44) < 1e-9


def test_boss_charge_windup_telegraph_precedes_charge_commit():
    boss = Zombie(0, 0, ZombieType.BOSS)
    boss.boss_charge_cooldown = 0.0
    boss.boss_leap_cooldown = 999.0
    boss.boss_commander_cooldown = 999.0

    boss.update(0.05, pygame.Vector2(260, 0), player_velocity=pygame.Vector2(), nearby_zombies=[], pack_pressure=0.0)
    assert boss.boss_charge_windup_timer > 0.0
    assert boss.boss_charge_timer == 0.0

    boss.update(0.40, pygame.Vector2(260, 0), player_velocity=pygame.Vector2(), nearby_zombies=[], pack_pressure=0.0)
    assert boss.boss_charge_timer > 0.0
    assert boss.boss_charge_windup_timer == 0.0


def test_charge_side_step_during_windup_triggers_recovery_instead_of_commit():
    boss = Zombie(0, 0, ZombieType.BOSS)
    boss.boss_charge_cooldown = 0.0
    boss.boss_leap_cooldown = 999.0
    boss.boss_commander_cooldown = 999.0

    boss.update(0.05, pygame.Vector2(260, 0), player_velocity=pygame.Vector2(), nearby_zombies=[], pack_pressure=0.0)
    assert boss.boss_charge_windup_timer > 0.0

    boss.update(0.40, pygame.Vector2(0, 260), player_velocity=pygame.Vector2(), nearby_zombies=[], pack_pressure=0.0)
    assert boss.boss_charge_timer == 0.0
    assert boss.boss_charge_recovery_timer > 0.0


def test_commander_cast_channel_can_be_interrupted_once_with_stagger():
    boss = Zombie(0, 0, ZombieType.BOSS)
    boss.boss_commander_cooldown = 0.0
    boss.boss_charge_cooldown = 999.0
    boss.boss_leap_cooldown = 999.0

    boss.update(0.05, pygame.Vector2(300, 0), player_velocity=pygame.Vector2(), nearby_zombies=[], pack_pressure=0.0)
    assert boss.boss_commander_cast_timer > 0.0

    interrupted = boss.register_channel_damage(boss.boss_commander_interrupt_threshold + 1)
    assert interrupted is True
    assert boss.boss_commander_cast_timer == 0.0
    assert boss.boss_stagger_timer > 0.0
    assert boss.consume_commander_call() is False


def test_leap_target_retargets_on_commit_with_latest_player_position():
    boss = Zombie(0, 0, ZombieType.BOSS)
    boss.boss_leap_cooldown = 0.0
    boss.boss_charge_cooldown = 999.0
    boss.boss_commander_cooldown = 999.0

    initial_target = pygame.Vector2(180, 0)
    moved_target = pygame.Vector2(320, 260)
    boss.update(0.05, initial_target, player_velocity=pygame.Vector2(), nearby_zombies=[], pack_pressure=0.0)
    locked_target = pygame.Vector2(boss.boss_leap_target)
    assert locked_target.distance_to(initial_target) < 1e-6
    assert boss.boss_leap_windup_timer > 0.0

    boss.update(1.0, moved_target, player_velocity=pygame.Vector2(), nearby_zombies=[], pack_pressure=0.0)
    assert boss.boss_leap_timer > 0.0
    assert boss.boss_leap_target.distance_to(locked_target) > 1.0
    assert boss.boss_leap_target.distance_to(moved_target) < 1e-6


def test_zone_caster_cast_emits_zone_payload_once():
    boss = Zombie(0, 0, ZombieType.BOSS)
    boss.set_boss_archetype(BossArchetype.ZONE_CASTER)
    boss.boss_commander_cooldown = 0.0
    boss.boss_charge_cooldown = 999.0
    boss.boss_leap_cooldown = 999.0

    boss.update(0.05, pygame.Vector2(280, 0), player_velocity=pygame.Vector2(180, 0), nearby_zombies=[], pack_pressure=0.0)
    assert boss.boss_commander_cast_timer > 0.0

    boss.update(1.0, pygame.Vector2(320, 0), player_velocity=pygame.Vector2(180, 0), nearby_zombies=[], pack_pressure=0.0)
    payload = boss.consume_zone_cast()
    assert payload is not None
    centers, radius, damage, arm_time, active_time, tick_interval = payload
    assert len(centers) == 3
    assert radius > 0.0
    assert damage > 0
    assert arm_time > 0.0
    assert active_time > 0.0
    assert tick_interval > 0.0
    assert boss.consume_zone_cast() is None


def test_stealth_assassin_ambush_emits_corridor_payload():
    boss = Zombie(0, 0, ZombieType.BOSS)
    boss.set_boss_archetype(BossArchetype.STEALTH_ASSASSIN)
    boss.boss_ambush_cooldown = 0.0
    boss.boss_charge_cooldown = 999.0
    boss.boss_leap_cooldown = 999.0
    boss.boss_commander_cooldown = 999.0

    target = pygame.Vector2(220, 0)
    boss.update(0.05, target, player_velocity=pygame.Vector2(140, 0), nearby_zombies=[], pack_pressure=0.0)
    assert boss.boss_ambush_windup_timer > 0.0

    boss.update(0.40, target, player_velocity=pygame.Vector2(140, 0), nearby_zombies=[], pack_pressure=0.0)
    payload = boss.consume_ambush_pulse()
    assert payload is not None
    origin, direction, length, half_width, damage, lockout = payload
    assert isinstance(origin, pygame.Vector2)
    assert direction.length_squared() > 0.0
    assert length > 0.0
    assert half_width > 0.0
    assert damage > 0
    assert lockout > 0.0
    assert boss.consume_ambush_pulse() is None

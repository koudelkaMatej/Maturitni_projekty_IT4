import pygame

from game.lighting import apply_cone_visibility_mask, get_flashlight_cone_points, render_darkness_overlay


def test_flashlight_cone_is_directional_without_ambient_halo():
    screen = pygame.Surface((240, 180), pygame.SRCALPHA)
    player_pos = pygame.Vector2(80, 90)
    aim_direction = pygame.Vector2(1, 0)

    render_darkness_overlay(
        screen,
        player_pos,
        aim_direction,
        cone_length=90,
        cone_angle_deg=40,
        darkness_alpha=210,
    )

    forward_alpha = screen.get_at((140, 90)).a
    side_alpha = screen.get_at((80, 130)).a
    behind_alpha = screen.get_at((45, 90)).a

    assert side_alpha >= 190
    assert behind_alpha >= 190
    assert forward_alpha < side_alpha


def test_cone_mask_keeps_pixels_inside_cone_and_hides_outside():
    source = pygame.Surface((200, 140), pygame.SRCALPHA)
    source.fill((255, 0, 0, 255))
    player = pygame.Vector2(50, 70)
    cone_points = get_flashlight_cone_points(player, pygame.Vector2(1, 0), cone_length=80, cone_angle_deg=40)

    masked = apply_cone_visibility_mask(source, cone_points)

    inside = masked.get_at((110, 70)).a
    outside = masked.get_at((40, 20)).a
    assert inside > 0
    assert outside == 0

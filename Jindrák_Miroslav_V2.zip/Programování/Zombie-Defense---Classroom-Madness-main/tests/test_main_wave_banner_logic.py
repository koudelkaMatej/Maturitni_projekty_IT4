from types import SimpleNamespace

from game.main import Game


def test_start_wave_banner_sets_wave_and_timer():
    game = Game.__new__(Game)
    game.wave_banner_duration = 3.5
    game.wave_banner_timer = 0.0
    game.wave_banner_wave = 1

    Game.start_wave_banner(game, 4)

    assert game.wave_banner_wave == 4
    assert game.wave_banner_timer == 3.5


def test_start_wave_banner_stores_optional_subtitle():
    game = Game.__new__(Game)
    game.wave_banner_duration = 3.5
    game.wave_banner_timer = 0.0
    game.wave_banner_wave = 1

    Game.start_wave_banner(game, 8, is_boss=True, subtitle="BOSS: Ravager")
    assert game.wave_banner_subtitle == "BOSS: Ravager"
    assert game.wave_banner_is_boss is True


def test_wave_banner_timer_expires():
    game = Game.__new__(Game)
    game.wave_banner_timer = 1.0

    Game.update_wave_banner_timer(game, 0.3)
    assert abs(game.wave_banner_timer - 0.7) < 1e-6

    Game.update_wave_banner_timer(game, 1.0)
    assert game.wave_banner_timer == 0.0


def test_process_wave_clear_triggers_next_wave_banner():
    game = Game.__new__(Game)
    game.wave_manager = SimpleNamespace(current_wave=5, is_boss_wave=lambda _wave=None: False)
    game.wave_banner_duration = 3.5
    game.wave_banner_timer = 0.0
    game.wave_banner_wave = 1
    game.score = 0
    game.audio = SimpleNamespace(play_wave_complete=lambda: None)

    awarded: list[int] = []

    def fake_award_coins(amount: int) -> None:
        awarded.append(amount)

    game.award_coins = fake_award_coins

    Game.process_wave_clear(game)

    assert game.wave_banner_wave == 5
    assert game.wave_banner_timer == 3.5
    assert game.score == 30 + 4 * 12
    assert awarded == [8 + 4 * 3]


def test_boss_wave_banner_is_not_replayed_when_wave_starts_after_intermission():
    game = Game.__new__(Game)
    game.wave_manager = SimpleNamespace(current_wave=8, is_boss_wave=lambda _wave=None: True)
    game.wave_banner_duration = 3.5
    game.wave_banner_timer = 0.0
    game.wave_banner_wave = 1
    game.wave_banner_is_boss = False
    game.wave_banner_subtitle = ""
    game.score = 0
    game.audio = SimpleNamespace(play_wave_complete=lambda: None)
    game.award_coins = lambda _amount: None
    game.award_run_scrap = lambda _amount: None
    game.maybe_offer_run_perk = lambda _wave: None

    Game.process_wave_clear(game)
    assert game.wave_banner_wave == 8
    assert game.wave_banner_is_boss is True

    game.wave_banner_timer = 0.0
    Game.start_wave_banner(game, 8, is_boss=True, subtitle="BOSS: Ravager")
    assert game.wave_banner_timer == 0.0

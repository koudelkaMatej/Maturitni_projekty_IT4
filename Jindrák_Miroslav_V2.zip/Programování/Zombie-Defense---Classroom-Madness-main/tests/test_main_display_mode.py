from types import SimpleNamespace

import pygame

from game.main import Game, GameState


def _build_game() -> Game:
    game = Game.__new__(Game)
    game.width = 1000
    game.height = 700
    game.min_window_size = (640, 448)
    game.windowed_size = (1000, 700)
    game.is_fullscreen = False
    game.viewport_rect = pygame.Rect(0, 0, 1000, 700)
    game.viewport_scale = 1.0
    game.display_surface = pygame.Surface((1000, 700))
    game.state = GameState.MENU
    return game


def test_window_to_logical_maps_inside_viewport():
    game = _build_game()
    game.viewport_rect = pygame.Rect(200, 100, 1600, 1120)
    game.viewport_scale = 1.6

    mapped = Game.window_to_logical(game, (1000, 660), clamp=False)

    assert mapped is not None
    assert abs(mapped.x - 500.0) < 1e-6
    assert abs(mapped.y - 350.0) < 1e-6


def test_window_to_logical_returns_none_outside_viewport_when_unclamped():
    game = _build_game()
    game.viewport_rect = pygame.Rect(200, 100, 1600, 1120)
    game.viewport_scale = 1.6

    mapped = Game.window_to_logical(game, (120, 40), clamp=False)

    assert mapped is None


def test_window_to_logical_clamps_outside_point_to_logical_edges():
    game = _build_game()
    game.viewport_rect = pygame.Rect(200, 100, 1600, 1120)
    game.viewport_scale = 1.6

    mapped = Game.window_to_logical(game, (20, 3000), clamp=True)

    assert mapped is not None
    assert mapped.x == 0.0
    assert mapped.y == 699.0


def test_recalculate_viewport_letterboxes_wide_window():
    game = _build_game()
    game.display_surface = pygame.Surface((1600, 800))

    Game.recalculate_viewport(game)

    assert game.viewport_rect.height == 800
    assert game.viewport_rect.y == 0
    assert game.viewport_rect.x > 0
    assert game.viewport_rect.centerx == 800
    assert abs(game.viewport_scale - (800 / 700)) < 1e-6


def test_recalculate_viewport_letterboxes_tall_window():
    game = _build_game()
    game.display_surface = pygame.Surface((1000, 1200))

    Game.recalculate_viewport(game)

    assert game.viewport_rect.width == 1000
    assert game.viewport_rect.x == 0
    assert game.viewport_rect.y > 0
    assert game.viewport_rect.centery == 600
    assert game.viewport_scale == 1.0


def test_toggle_fullscreen_enters_and_restores_windowed_size(monkeypatch):
    game = _build_game()
    game.display_surface = pygame.Surface((1280, 720))

    calls: list[tuple[tuple[int, int], int]] = []

    def fake_set_mode(size: tuple[int, int], flags: int = 0) -> pygame.Surface:
        calls.append((size, flags))
        if flags & pygame.FULLSCREEN:
            return pygame.Surface((1920, 1080))
        return pygame.Surface(size)

    monkeypatch.setattr("game.main.pygame.display.set_mode", fake_set_mode)

    Game.toggle_fullscreen(game)

    assert game.is_fullscreen is True
    assert game.windowed_size == (1280, 720)
    assert calls[0][0] == (0, 0)
    assert calls[0][1] & pygame.FULLSCREEN

    Game.toggle_fullscreen(game)

    assert game.is_fullscreen is False
    assert calls[1][0] == (1280, 720)
    assert calls[1][1] & pygame.RESIZABLE


def test_videoresize_event_clamps_window_size_before_apply(monkeypatch):
    game = _build_game()
    game.is_fullscreen = False

    calls: list[tuple[bool, tuple[int, int] | None]] = []

    def fake_apply_display_mode(*, fullscreen: bool, size: tuple[int, int] | None = None) -> None:
        calls.append((fullscreen, size))

    game.apply_display_mode = fake_apply_display_mode
    game.toggle_fullscreen = lambda: None
    game.quit_game = lambda: None

    resize_event = SimpleNamespace(type=pygame.VIDEORESIZE, w=200, h=180)
    monkeypatch.setattr("game.main.pygame.event.get", lambda: [resize_event])

    Game.handle_events(game)

    assert calls == [(False, (640, 448))]


def test_videoresize_event_is_ignored_in_fullscreen(monkeypatch):
    game = _build_game()
    game.is_fullscreen = True

    calls: list[tuple[bool, tuple[int, int] | None]] = []

    def fake_apply_display_mode(*, fullscreen: bool, size: tuple[int, int] | None = None) -> None:
        calls.append((fullscreen, size))

    game.apply_display_mode = fake_apply_display_mode
    game.toggle_fullscreen = lambda: None
    game.quit_game = lambda: None

    resize_event = SimpleNamespace(type=pygame.VIDEORESIZE, w=1200, h=900)
    monkeypatch.setattr("game.main.pygame.event.get", lambda: [resize_event])

    Game.handle_events(game)

    assert calls == []

import pygame

from game.weapons import WeaponInventory


def test_inventory_starts_with_fallback_pistol_and_two_main_slots():
    inventory = WeaponInventory()

    assert inventory.active_slot == 0
    assert inventory.slots[0] is not None
    assert inventory.slots[0].spec_key == "pistol"
    assert inventory.slots[1] is None
    assert inventory.slots[2] is None
    assert inventory.main_slot_capacity == 2


def test_buying_weapons_fills_unlocked_main_slots_before_replace():
    inventory = WeaponInventory()
    inventory.buy_weapon("shotgun")
    inventory.buy_weapon("burst_rifle")

    assert inventory.slots[1] is not None
    assert inventory.slots[1].spec_key == "shotgun"
    assert inventory.slots[2] is not None
    assert inventory.slots[2].spec_key == "burst_rifle"

    inventory.buy_weapon("sniper")
    assert inventory.slots[2] is not None
    assert inventory.slots[2].spec_key == "sniper"


def test_unlock_extra_slot_adds_third_main_slot():
    inventory = WeaponInventory()
    assert inventory.has_extra_slot() is False
    assert inventory.unlock_extra_slot() is True
    assert inventory.has_extra_slot() is True
    assert inventory.unlock_extra_slot() is False


def test_main_slot_controls_and_force_fallback():
    inventory = WeaponInventory()
    inventory.buy_weapon("shotgun")
    inventory.buy_weapon("auto_rifle")

    assert inventory.switch_to_slot(1) is True
    assert inventory.active_state is not None
    assert inventory.active_state.spec_key == "shotgun"

    assert inventory.switch_to_slot(2) is True
    assert inventory.active_state is not None
    assert inventory.active_state.spec_key == "auto_rifle"

    assert inventory.cycle_slot() is True
    assert inventory.active_state is not None
    assert inventory.active_state.spec_key == "shotgun"

    assert inventory.switch_to_slot(0) is True
    assert inventory.active_state is not None
    assert inventory.active_state.spec_key == "pistol"


def test_finite_reload_moves_ammo_from_reserve():
    inventory = WeaponInventory()
    inventory.buy_weapon("auto_rifle")
    state = inventory.active_state
    assert state is not None

    state.ammo_in_mag = 5
    state.reserve_ammo = 10

    assert inventory.start_reload_active() is True
    inventory.update_timers(2.2)

    assert state.ammo_in_mag == 15
    assert state.reserve_ammo == 0
    assert state.is_reloading is False


def test_pistol_reload_works_with_infinite_reserve():
    inventory = WeaponInventory()
    state = inventory.active_state
    assert state is not None
    assert state.spec_key == "pistol"

    state.ammo_in_mag = 2
    assert inventory.start_reload_active() is True
    inventory.update_timers(1.1)

    assert state.ammo_in_mag == 12
    assert state.reserve_ammo is None
    assert state.is_reloading is False


def test_burst_rifle_uses_three_rounds_per_tap():
    inventory = WeaponInventory()
    inventory.buy_weapon("burst_rifle")
    state = inventory.active_state
    assert state is not None

    aim = pygame.Vector2(1, 0)
    shots_1 = inventory.step_fire(trigger_down=True, trigger_pressed=True, aim_direction=aim)
    inventory.update_timers(0.08)
    shots_2 = inventory.step_fire(trigger_down=False, trigger_pressed=False, aim_direction=aim)
    inventory.update_timers(0.08)
    shots_3 = inventory.step_fire(trigger_down=False, trigger_pressed=False, aim_direction=aim)

    assert len(shots_1) == 1
    assert len(shots_2) == 1
    assert len(shots_3) == 1
    assert state.ammo_in_mag == 21
    assert state.pending_burst_shots == 0


def test_weapon_prices_reflect_hard_nerf_tuning():
    inventory = WeaponInventory()
    assert inventory.catalog["shotgun"].price_points == 280
    assert inventory.catalog["burst_rifle"].price_points == 520
    assert inventory.catalog["auto_rifle"].price_points == 620
    assert inventory.catalog["sniper"].price_points == 1180


def test_ammo_refill_cost_and_restore_for_finite_weapon():
    inventory = WeaponInventory()
    inventory.buy_weapon("auto_rifle")
    state = inventory.active_state
    assert state is not None
    assert state.spec_key == "auto_rifle"

    state.ammo_in_mag = 3
    state.reserve_ammo = 7

    assert inventory.ammo_refill_cost("auto_rifle") == 341
    assert inventory.is_ammo_full(state) is False
    assert inventory.refill_weapon_ammo(state) is True
    assert state.ammo_in_mag == 26
    assert state.reserve_ammo == 156
    assert inventory.is_ammo_full(state) is True


def test_weapon_specs_reflect_moderate_rebalance_values():
    inventory = WeaponInventory()

    shotgun = inventory.catalog["shotgun"]
    assert shotgun.damage == 13
    assert abs(shotgun.cooldown - 0.78) < 1e-6
    assert abs(shotgun.reload_time - 2.00) < 1e-6
    assert abs(shotgun.pellet_spread_degrees - 16.0) < 1e-6

    auto_rifle = inventory.catalog["auto_rifle"]
    assert auto_rifle.damage == 12
    assert abs(auto_rifle.cooldown - 0.125) < 1e-6
    assert auto_rifle.magazine_size == 26
    assert auto_rifle.reserve_ammo == 156
    assert abs(auto_rifle.reload_time - 2.10) < 1e-6

    sniper = inventory.catalog["sniper"]
    assert sniper.damage == 125
    assert abs(sniper.cooldown - 0.88) < 1e-6
    assert sniper.magazine_size == 6
    assert sniper.reserve_ammo == 36
    assert abs(sniper.reload_time - 2.25) < 1e-6
    assert abs(sniper.projectile_speed - 920.0) < 1e-6


def test_firing_empty_main_slot_auto_switches_to_fallback_pistol():
    inventory = WeaponInventory()
    inventory.buy_weapon("shotgun")
    state = inventory.active_state
    assert state is not None

    state.ammo_in_mag = 0
    state.reserve_ammo = 0
    shots = inventory.step_fire(
        trigger_down=True,
        trigger_pressed=True,
        aim_direction=pygame.Vector2(1, 0),
    )

    assert shots == []
    assert inventory.active_slot == 0
    assert inventory.active_state is not None
    assert inventory.active_state.spec_key == "pistol"


def test_owned_finite_weapon_states_lists_all_owned_non_pistol():
    inventory = WeaponInventory()
    inventory.buy_weapon("sniper")
    inventory.buy_weapon("shotgun")

    keys = [state.spec_key for state in inventory.owned_finite_weapon_states()]
    assert keys == ["shotgun", "sniper"]


def test_apply_ammo_pickup_restores_finite_weapon():
    inventory = WeaponInventory()
    inventory.buy_weapon("auto_rifle")
    state = inventory.active_state
    assert state is not None
    state.ammo_in_mag = 1
    state.reserve_ammo = 0

    assert inventory.apply_ammo_pickup() is True
    assert state.ammo_in_mag > 1
    assert state.reserve_ammo is not None
    assert state.reserve_ammo > 0


def test_apply_ammo_pickup_returns_false_when_no_finite_weapon_needs_ammo():
    inventory = WeaponInventory()
    assert inventory.apply_ammo_pickup() is False


def test_burst_rifle_starts_reload_immediately_when_last_followup_shot_empties_mag():
    inventory = WeaponInventory()
    inventory.buy_weapon("burst_rifle")
    state = inventory.active_state
    assert state is not None
    state.ammo_in_mag = 2
    state.reserve_ammo = 40

    aim = pygame.Vector2(1, 0)
    inventory.step_fire(trigger_down=True, trigger_pressed=True, aim_direction=aim)
    inventory.update_timers(0.08)
    inventory.step_fire(trigger_down=False, trigger_pressed=False, aim_direction=aim)

    assert state.ammo_in_mag == 0
    assert state.pending_burst_shots == 0
    assert state.is_reloading is True


def test_empty_mag_starts_reload_for_auto_and_single_weapons():
    inventory = WeaponInventory()
    for weapon_key in ("auto_rifle", "shotgun", "sniper"):
        inventory.buy_weapon(weapon_key)
        state = inventory.active_state
        assert state is not None
        state.ammo_in_mag = 1
        state.reserve_ammo = 30

        inventory.step_fire(
            trigger_down=True,
            trigger_pressed=True,
            aim_direction=pygame.Vector2(1, 0),
        )

        assert state.ammo_in_mag == 0
        assert state.is_reloading is True

﻿import pygame

from game.player import Player
from game.powerups import PowerUpManager, PowerUpPickup, PowerUpType


def test_powerup_drop_spawns_pickup_when_roll_hits(monkeypatch):
    manager = PowerUpManager(drop_chance=1.0)
    monkeypatch.setattr("game.powerups.random.random", lambda: 0.0)
    manager.maybe_spawn_drop(pygame.Vector2(50, 60))

    assert len(manager.pickups) == 1


def test_collect_heal_pickup_restores_hp():
    manager = PowerUpManager(drop_chance=0.0)
    player = Player(100, 100)
    player.take_damage(60)

    manager.pickups.append(PowerUpPickup(PowerUpType.HEAL_PACK, pygame.Vector2(100, 100)))
    collected = manager.collect_at_player(player)

    assert collected == [PowerUpType.HEAL_PACK]
    assert player.health == 65


def test_timed_effects_expire():
    manager = PowerUpManager(drop_chance=0.0)
    player = Player(0, 0)

    manager.pickups.append(PowerUpPickup(PowerUpType.RAPID_FIRE, pygame.Vector2(0, 0)))
    manager.collect_at_player(player)
    assert manager.shoot_cooldown_multiplier == 0.55

    manager.pickups.append(PowerUpPickup(PowerUpType.FREEZE_BLAST, pygame.Vector2(0, 0)))
    manager.collect_at_player(player)
    assert manager.zombie_speed_multiplier == 0.35

    manager.update(6.1)
    assert manager.shoot_cooldown_multiplier == 1.0
    assert manager.zombie_speed_multiplier == 1.0


def test_new_timed_effects_apply_and_expire():
    manager = PowerUpManager(drop_chance=0.0)
    player = Player(0, 0)

    manager.pickups.append(PowerUpPickup(PowerUpType.FORTIFY_FIELD, pygame.Vector2(0, 0)))
    manager.collect_at_player(player)
    assert manager.incoming_damage_multiplier == 0.65

    manager.pickups.append(PowerUpPickup(PowerUpType.SCRAP_MAGNET, pygame.Vector2(0, 0)))
    manager.collect_at_player(player)
    assert manager.scrap_gain_multiplier == 1.5

    manager.update(7.1)
    assert manager.incoming_damage_multiplier == 1.0
    assert manager.scrap_gain_multiplier == 1.0


def test_ammo_cache_pickup_is_collectable_without_side_effects_on_player_hp():
    manager = PowerUpManager(drop_chance=0.0)
    player = Player(10, 10)
    player.take_damage(10)

    manager.pickups.append(PowerUpPickup(PowerUpType.AMMO_CACHE, pygame.Vector2(10, 10)))
    collected = manager.collect_at_player(player)

    assert collected == [PowerUpType.AMMO_CACHE]
    assert player.health == 90


def test_active_effect_labels_include_new_effects_and_ammo_feedback():
    manager = PowerUpManager(drop_chance=0.0)
    player = Player(0, 0)

    manager.pickups.append(PowerUpPickup(PowerUpType.FORTIFY_FIELD, pygame.Vector2(0, 0)))
    manager.pickups.append(PowerUpPickup(PowerUpType.SCRAP_MAGNET, pygame.Vector2(0, 0)))
    manager.collect_at_player(player)
    manager.register_ammo_cache_feedback("Ammo Cache: +8 scrap")

    labels = manager.active_effect_labels()
    assert any(label.startswith("Fortify") for label in labels)
    assert any(label.startswith("Scrap Magnet") for label in labels)
    assert any("Ammo Cache: +8 scrap" in label for label in labels)

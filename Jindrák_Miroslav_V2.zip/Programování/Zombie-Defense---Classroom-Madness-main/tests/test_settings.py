from game import settings


def test_load_last_player_name_missing_file_returns_none(tmp_path):
    file_path = tmp_path / "settings.json"
    assert settings.load_last_player_name(file_path=file_path) is None


def test_save_and_load_last_player_name(tmp_path):
    file_path = tmp_path / "settings.json"
    settings.save_last_player_name("Alice", file_path=file_path)

    assert settings.load_last_player_name(file_path=file_path) == "Alice"


def test_load_last_player_name_corrupt_json_returns_none(tmp_path):
    file_path = tmp_path / "settings.json"
    file_path.write_text("{ this is invalid json", encoding="utf-8")

    assert settings.load_last_player_name(file_path=file_path) is None


def test_load_last_player_name_reads_legacy_key(tmp_path):
    file_path = tmp_path / "settings.json"
    file_path.write_text('{"last_player_name": "LegacyUser"}', encoding="utf-8")

    assert settings.load_last_player_name(file_path=file_path) == "LegacyUser"


def test_load_visual_mode_defaults_to_night(tmp_path):
    file_path = tmp_path / "settings.json"
    assert settings.load_visual_mode(file_path=file_path) == "night"


def test_save_and_load_visual_mode(tmp_path):
    file_path = tmp_path / "settings.json"
    settings.save_visual_mode("day", file_path=file_path)
    assert settings.load_visual_mode(file_path=file_path) == "day"

    settings.save_visual_mode("blackout", file_path=file_path)
    assert settings.load_visual_mode(file_path=file_path) == "blackout"


def test_load_visual_mode_invalid_value_falls_back_to_night(tmp_path):
    file_path = tmp_path / "settings.json"
    file_path.write_text('{"visual_mode": "sunset"}', encoding="utf-8")
    assert settings.load_visual_mode(file_path=file_path) == "night"

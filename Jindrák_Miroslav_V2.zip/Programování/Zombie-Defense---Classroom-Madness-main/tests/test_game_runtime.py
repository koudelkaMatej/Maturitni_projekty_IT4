from game.main import Game


def test_award_coins_updates_in_memory_only():
    game = Game.__new__(Game)
    game.player_profile_id = 7
    game.player_coins = 20
    game.coins_earned_run = 0
    game.pending_coin_delta = 0

    Game.award_coins(game, 15)

    assert game.player_coins == 35
    assert game.coins_earned_run == 15
    assert game.pending_coin_delta == 15


def test_flush_pending_coins_writes_single_batched_delta(monkeypatch):
    game = Game.__new__(Game)
    game.player_profile_id = 3
    game.player_coins = 55
    game.pending_coin_delta = 42
    game.coin_flush_timer = 1.2
    game.coin_flush_interval = 1.0

    calls: list[tuple[int, int]] = []

    def fake_add_player_coins(player_id: int, amount: int) -> int:
        calls.append((player_id, amount))
        return 999

    monkeypatch.setattr("game.main.database.add_player_coins", fake_add_player_coins)

    Game.flush_pending_coins(game, force=False)

    assert calls == [(3, 42)]
    assert game.player_coins == 999
    assert game.pending_coin_delta == 0
    assert game.coin_flush_timer == 0.0


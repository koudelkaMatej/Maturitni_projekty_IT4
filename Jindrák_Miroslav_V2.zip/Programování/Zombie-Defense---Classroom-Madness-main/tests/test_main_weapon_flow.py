from types import SimpleNamespace

import pygame

from game.enemy import Zombie
from game.main import Game, GameState
from game.player import Player
from game.projectile import Projectile


def test_process_wave_clear_increases_score_and_coin_reward():
    game = Game.__new__(Game)
    game.wave_manager = SimpleNamespace(current_wave=5, is_boss_wave=lambda wave: wave == 5)
    game.wave_banner_duration = 3.5
    game.wave_banner_timer = 0.0
    game.wave_banner_wave = 1
    game.wave_banner_is_boss = False
    game.score = 0
    game.audio = SimpleNamespace(play_wave_complete=lambda: None)

    awarded: list[int] = []

    def fake_award_coins(amount: int) -> None:
        awarded.append(amount)

    game.award_coins = fake_award_coins

    Game.process_wave_clear(game)

    assert game.score == 30 + 4 * 12
    assert awarded == [8 + 4 * 3]
    assert game.wave_banner_wave == 5
    assert game.wave_banner_is_boss is True


def test_zombie_kill_increases_score_and_kills():
    game = Game.__new__(Game)
    zombie = Zombie(0, 0)
    projectile = Projectile(pygame.Vector2(0, 0), pygame.Vector2(1, 0), speed=0, damage=999)
    projectile.position = pygame.Vector2(zombie.position)

    game.projectiles = [projectile]
    game.zombies = [zombie]
    game.player = Player(500, 500)
    game.player_hit_timer = 0.0
    game.player_hit_cooldown = 0.45
    game.kills = 0
    game.score = 0
    game.award_coins = lambda amount: None
    game.wave_manager = SimpleNamespace(notify_zombie_killed=lambda: None)
    game.powerups = SimpleNamespace(maybe_spawn_drop=lambda position: None)

    Game.handle_collisions(game)

    assert game.kills == 1
    assert game.score == zombie.score_value


def test_b_key_no_longer_opens_weapon_kiosk():
    game = Game.__new__(Game)
    game.state = GameState.PLAYING
    game.try_reload_active_weapon = lambda: None
    received_keys: list[int] = []
    game.handle_weapon_switch_input = lambda key: received_keys.append(key)

    event = pygame.event.Event(pygame.KEYDOWN, {"key": pygame.K_b})
    Game.handle_playing_event(game, event)

    assert game.state == GameState.PLAYING
    assert received_keys == [pygame.K_b]


def test_non_playing_state_pauses_update_loop():
    game = Game.__new__(Game)
    game.state = GameState.MENU
    game.survival_time = 14.5

    Game.update(game, 1.0)

    assert game.survival_time == 14.5

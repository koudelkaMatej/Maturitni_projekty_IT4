import pygame

from game.ui import compute_menu_layout, format_player_label, get_menu_option_rects, get_menu_options


def test_menu_options_switch_login_logout_label():
    guest_options = get_menu_options(authenticated=False)
    user_options = get_menu_options(authenticated=True)
    assert guest_options == ["Play", "Login", "Skins Shop", "How To Play", "Quit"]
    assert user_options == ["Play", "Logout", "Skins Shop", "How To Play", "Quit"]


def test_format_player_label_for_blank_name():
    assert format_player_label("", authenticated=False) == "Player: Guest"
    assert format_player_label("   ", authenticated=False) == "Player: Guest"
    assert format_player_label("Alice", authenticated=True) == "Player: Alice (logged in)"


def test_menu_layout_blocks_do_not_overlap():
    pygame.init()
    title_h = pygame.font.SysFont("arial", 56, bold=True).get_height()
    option_h = pygame.font.SysFont("arial", 36).get_height()
    body_h = pygame.font.SysFont("consolas", 22).get_height()
    row_h = pygame.font.SysFont("consolas", 18).get_height()

    layout = compute_menu_layout(
        width=1000,
        height=700,
        option_count=5,
        leaderboard_count=5,
        has_message=True,
        title_height=title_h,
        option_height=option_h,
        body_height=body_h,
        leaderboard_row_height=row_h,
    )

    option_rects = list(layout["option_rects"])
    hint_rect = layout["hint_rect"]
    title_rect = layout["leaderboard_title_rect"]
    message_rect = layout["message_rect"]
    assert isinstance(hint_rect, pygame.Rect)
    assert isinstance(title_rect, pygame.Rect)
    assert isinstance(message_rect, pygame.Rect)

    assert option_rects[-1].bottom < message_rect.top
    assert message_rect.bottom < hint_rect.top
    assert hint_rect.bottom < title_rect.top


def test_menu_option_rects_are_stable_count_and_order():
    pygame.init()
    rects = get_menu_option_rects(1000, 700, has_message=False, leaderboard_count=5)
    assert len(rects) == 5
    assert rects[0].centery < rects[1].centery < rects[2].centery < rects[3].centery < rects[4].centery

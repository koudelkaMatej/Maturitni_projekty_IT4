import pygame

from game.ui import (
    compute_perk_name_layout,
    draw_armory_overlay,
    draw_howto_screen,
    draw_hud,
    draw_mutation_drawer,
    draw_pause_overlay,
    draw_perk_draft_overlay,
    draw_visual_mode_select,
    get_armory_button_rect,
    get_armory_panel_rect,
    get_armory_row_rect,
    get_howto_category_rects,
    get_howto_panel_rect,
    get_mutation_button_rect,
    get_pause_main_option_rects,
)


def test_draw_hud_shows_progression_layers_without_error():
    pygame.init()
    screen = pygame.Surface((1000, 700))

    draw_hud(
        screen=screen,
        score=120,
        kills=15,
        survival_time=42.5,
        health=80,
        max_health=100,
        wave=5,
        intermission_remaining=3.2,
        coins=240,
        run_scrap=135,
        active_weapon_key="burst_rifle",
        active_weapon_name="Burst Rifle",
        active_weapon_ammo="21/144",
        active_weapon_reload="",
        slot_labels=["*1: Burst Rifle", " 2: Pistol"],
        active_effects=["Perk: Sharpshooter", "Rapid Fire 2.1s"],
        intermission_hint="Intermission: TAB open armory",
    )

    assert screen.get_at((20, 88)) != pygame.Color(0, 0, 0, 255)


def test_draw_hud_weapon_sprite_fallback_without_asset():
    pygame.init()
    screen = pygame.Surface((1000, 700))

    draw_hud(
        screen=screen,
        score=5,
        kills=1,
        survival_time=8.2,
        health=90,
        max_health=100,
        wave=1,
        intermission_remaining=0.0,
        coins=10,
        run_scrap=15,
        active_weapon_key="does_not_exist",
        active_weapon_name="Unknown",
        active_weapon_ammo="0/0",
        active_weapon_reload="",
        slot_labels=["*1: Pistol", " 2: Empty"],
        active_effects=[],
    )

    assert screen.get_at((915, 620)) != pygame.Color(0, 0, 0, 255)


def test_draw_armory_overlay_renders_rows_and_message():
    pygame.init()
    screen = pygame.Surface((1000, 700))
    rows = [
        {"name": "Shotgun", "detail": "DMG 11", "status": "120 scrap", "enabled": True},
        {"name": "Burst Rifle", "detail": "DMG 18", "status": "Unlocks wave 4", "enabled": False},
    ]

    draw_armory_overlay(
        screen=screen,
        width=1000,
        height=700,
        current_wave=3,
        run_scrap=95,
        armory_tab="weapons",
        armory_rows=rows,
        selected_index=0,
        message="Not enough scrap",
    )

    assert screen.get_at((500, 350)) != pygame.Color(0, 0, 0, 255)


def test_draw_perk_draft_overlay_renders_cards():
    pygame.init()
    screen = pygame.Surface((1000, 700))
    choices = [
        {"name": "Sharpshooter", "description": "+15% projectile damage", "is_active": False},
        {"name": "Fast Hands", "description": "-20% reload time", "is_active": False},
        {"name": "Adrenaline", "description": "+12% movement speed", "is_active": True},
    ]

    draw_perk_draft_overlay(
        screen=screen,
        width=1000,
        height=700,
        choices=choices,
        selected_index=1,
    )

    assert screen.get_at((500, 350)) != pygame.Color(0, 0, 0, 255)


def test_draw_overlays_handle_long_text_without_errors():
    pygame.init()
    screen = pygame.Surface((1000, 700))

    long_rows = [
        {
            "name": "Ultra Experimental Weapon Platform Delta",
            "detail": "Critical Damage and Magazine Capacity",
            "status": "Unlocks at wave 999 and requires absurd scrap amount",
            "enabled": False,
        }
    ]
    long_choices = [
        {
            "name": "Extremely Long Mutation Name Prototype",
            "description": (
                "Massively increases accuracy and critical damage while also boosting movement speed "
                "during intermission transitions and keeping bonus effects active for extended periods."
            ),
            "is_active": False,
        },
        {
            "name": "Backup",
            "description": "Short line",
            "is_active": True,
        },
    ]

    draw_armory_overlay(
        screen=screen,
        width=1000,
        height=700,
        current_wave=9,
        run_scrap=200,
        armory_tab="weapons",
        armory_rows=long_rows,
        selected_index=0,
        message="Not enough scrap for this very long test message that should be clamped safely.",
    )
    draw_perk_draft_overlay(
        screen=screen,
        width=1000,
        height=700,
        choices=long_choices,
        selected_index=0,
    )

    assert screen.get_at((500, 350)) != pygame.Color(0, 0, 0, 255)


def test_perk_name_layout_keeps_standard_names_visible_without_truncation():
    pygame.init()
    for perk_name in ["Kinetic Rounds", "Hollow Points", "Quick Recovery", "Critical Lens"]:
        lines, _font_token, truncated = compute_perk_name_layout(perk_name, max_width=148)
        assert truncated is False
        assert "..." not in " ".join(lines)


def test_draw_pause_overlay_main_and_settings_without_error():
    pygame.init()
    screen = pygame.Surface((1000, 700))

    draw_pause_overlay(
        screen=screen,
        width=1000,
        height=700,
        selected_index=1,
    )
    draw_pause_overlay(
        screen=screen,
        width=1000,
        height=700,
        selected_index=0,
        settings_open=True,
        settings_selected_index=0,
        is_fullscreen=True,
    )

    assert screen.get_at((500, 350)) != pygame.Color(0, 0, 0, 255)


def test_pause_main_menu_has_four_clickable_options():
    rects = get_pause_main_option_rects(1000, 700)
    assert len(rects) == 4


def test_pause_main_controls_hint_stays_below_last_option_row():
    pygame.init()
    panel = pygame.Rect(1000 // 2 - 230, 700 // 2 - 190, 460, 380)
    rects = get_pause_main_option_rects(1000, 700)
    last_row = rects[-1]
    controls_center_y = panel.bottom - 28
    controls_top = controls_center_y - pygame.font.SysFont("consolas", 18).get_height() // 2
    assert controls_top > last_row.bottom


def test_draw_howto_screen_renders_all_sections_without_error():
    pygame.init()
    sections = [
        {
            "title": "Basics & Goal",
            "intro": "Intro line",
            "cards": [{"title": "Core", "icon": "goal", "accent": (120, 196, 255), "bullets": ["Line one", "Line two"]}],
        },
        {
            "title": "Controls & HUD",
            "intro": "Intro line",
            "cards": [{"title": "Controls", "icon": "keys", "accent": (255, 210, 140), "bullets": ["WASD", "Mouse"]}],
        },
        {
            "title": "Enemies & Bosses",
            "intro": "Intro line",
            "cards": [{"title": "Warden", "icon": "boss_warden", "accent": (230, 120, 120), "bullets": ["Slam ring"]}],
        },
        {
            "title": "Weapons & Ammo",
            "intro": "Intro line",
            "cards": [{"title": "Pistol", "icon": "weapon:pistol", "accent": (190, 206, 226), "bullets": ["Fallback"]}],
        },
        {
            "title": "Power-Ups",
            "intro": "Intro line",
            "cards": [{"title": "Freeze", "icon": "power_temp", "accent": (130, 204, 255), "bullets": ["Slow enemies"]}],
        },
        {
            "title": "Progression & Economy",
            "intro": "Intro line",
            "cards": [{"title": "Perks", "icon": "perk", "accent": (180, 214, 255), "bullets": ["Scale run"]}],
        },
    ]
    screen = pygame.Surface((1000, 700))

    for idx in range(len(sections)):
        clamped = draw_howto_screen(screen, 1000, 700, sections, selected_section_index=idx, scroll_offset=0)
        assert clamped == 0

    assert screen.get_at((500, 350)) != pygame.Color(0, 0, 0, 255)


def test_howto_layout_and_sidebar_fit_minimum_viewport():
    panel = get_howto_panel_rect(640, 448)
    rects = get_howto_category_rects(640, 448, 6)
    assert panel.width <= 640
    assert panel.height <= 448
    assert rects[0].top >= panel.top
    assert rects[-1].bottom <= panel.bottom


def test_draw_mutation_drawer_renders_sections():
    pygame.init()
    screen = pygame.Surface((1000, 700))

    draw_mutation_drawer(
        screen=screen,
        width=1000,
        height=700,
        temporary_effects=["Rapid Fire 1.2s", "Freeze 2.0s (zombies slowed)"],
        perk_effects=["Sharpshooter: +15% projectile damage"],
    )

    assert screen.get_at((20, 160)) != pygame.Color(0, 0, 0, 255)


def test_draw_mutation_drawer_handles_long_lines_with_scroll_offset():
    pygame.init()
    screen = pygame.Surface((1000, 700))

    long_perks = [
        "Last Stand: One fatal hit per wave leaves you at 20 HP and resets availability at wave start.",
        "Fortune Extractor: Scrap gains are increased each tier and stack with run modifiers.",
        "Combat Calibration: Repeated upgrades keep scaling damage and pressure pacing.",
    ]
    draw_mutation_drawer(
        screen=screen,
        width=1000,
        height=700,
        temporary_effects=["Rapid Fire 1.2s"],
        perk_effects=long_perks,
        scroll_offset=3,
    )

    assert screen.get_at((24, 220)) != pygame.Color(0, 0, 0, 255)


def test_draw_visual_mode_select_renders_without_error():
    pygame.init()
    screen = pygame.Surface((1000, 700))

    draw_visual_mode_select(
        screen=screen,
        width=1000,
        height=700,
        selected_index=1,
        option_labels=["Night", "Day", "Blackout"],
    )

    assert screen.get_at((500, 350)) != pygame.Color(0, 0, 0, 255)


def test_draw_hud_renders_close_mutations_button_text_inside_button():
    pygame.init()
    screen = pygame.Surface((1000, 700))

    draw_hud(
        screen=screen,
        score=5,
        kills=1,
        survival_time=8.2,
        health=90,
        max_health=100,
        wave=1,
        intermission_remaining=0.0,
        coins=10,
        run_scrap=15,
        active_weapon_key="pistol",
        active_weapon_name="Pistol",
        active_weapon_ammo="8/INF",
        active_weapon_reload="",
        slot_labels=["*1: Pistol", " 2: Empty"],
        active_effects=[],
        mutation_button_text="Close Mutations [P]",
        mutation_button_active=True,
    )

    button = get_mutation_button_rect(1000)
    assert screen.get_at(button.center) != pygame.Color(0, 0, 0, 255)


def test_draw_hud_renders_wave_rule_line():
    pygame.init()
    screen = pygame.Surface((1000, 700))

    draw_hud(
        screen=screen,
        score=14,
        kills=3,
        survival_time=12.0,
        health=92,
        max_health=100,
        wave=6,
        intermission_remaining=0.0,
        coins=20,
        run_scrap=45,
        active_weapon_key="pistol",
        active_weapon_name="Pistol",
        active_weapon_ammo="8/INF",
        active_weapon_reload="",
        slot_labels=["*1: Pistol", " 2: Empty"],
        active_effects=[],
        wave_rule_label="Objective: Kill Quota 4/18",
    )

    assert screen.get_at((500, 72)) != pygame.Color(0, 0, 0, 255)


def test_draw_armory_overlay_renders_selected_explanation_bar():
    pygame.init()
    screen = pygame.Surface((1000, 700))
    rows = [
        {
            "name": "Trigger Tuning",
            "detail": "T0/3",
            "status": "120 scrap",
            "enabled": True,
            "explain": "Trigger Tuning: each tier reduces weapon cooldown by 8% for this run.",
        }
    ]

    draw_armory_overlay(
        screen=screen,
        width=1000,
        height=700,
        current_wave=6,
        run_scrap=200,
        armory_tab="upgrades",
        armory_rows=rows,
        selected_index=0,
    )

    panel = get_armory_panel_rect(1000, 700)
    assert screen.get_at((panel.centerx, panel.bottom - 60)) != pygame.Color(0, 0, 0, 255)


def test_draw_armory_overlay_handles_long_explanation_without_crash():
    pygame.init()
    screen = pygame.Surface((1000, 700))
    rows = [
        {
            "name": "Last Stand Prototype",
            "detail": "T0/1",
            "status": "320 scrap",
            "enabled": True,
            "explain": (
                "Last Stand prototype keeps you alive at critical health once per wave and then must be "
                "managed carefully while pressure enemies and elite bursts continue to escalate."
            ),
        }
    ]

    draw_armory_overlay(
        screen=screen,
        width=1000,
        height=700,
        current_wave=12,
        run_scrap=420,
        armory_tab="upgrades",
        armory_rows=rows,
        selected_index=0,
    )

    panel = get_armory_panel_rect(1000, 700)
    assert screen.get_at((panel.left + 40, panel.bottom - 64)) != pygame.Color(0, 0, 0, 255)


def test_armory_more_below_marker_stays_between_rows_and_explanation_bar():
    panel = get_armory_panel_rect(1000, 700)
    explain_top = panel.bottom - 84
    last_visible_row = get_armory_row_rect(1000, 6)
    marker_y = min(explain_top - 16, last_visible_row.bottom + 10)

    assert marker_y > last_visible_row.bottom
    assert marker_y < explain_top


def test_armory_button_rect_is_directly_below_mutation_button():
    width = 1000
    mutation = get_mutation_button_rect(width)
    armory = get_armory_button_rect(width)

    assert armory.left == mutation.left
    assert armory.width == mutation.width
    assert armory.top == mutation.bottom + 8


def test_draw_hud_rule_panel_does_not_overlap_mutation_button_zone():
    pygame.init()
    screen = pygame.Surface((1000, 700))

    draw_hud(
        screen=screen,
        score=14,
        kills=3,
        survival_time=12.0,
        health=92,
        max_health=100,
        wave=8,
        intermission_remaining=0.0,
        coins=20,
        run_scrap=45,
        active_weapon_key="pistol",
        active_weapon_name="Pistol",
        active_weapon_ammo="8/INF",
        active_weapon_reload="",
        slot_labels=["*1: Pistol", " 2: Empty", " 3: Empty", " Fallback [0/4]: Pistol (INF)"],
        active_effects=[],
        mutation_button_text="Mutations [P]",
        wave_rule_label="Objective: Kill Quota 4/18",
    )

    mutation_left = get_mutation_button_rect(1000).left
    assert screen.get_at((mutation_left - 2, 72)) == pygame.Color(0, 0, 0, 255)


def test_draw_hud_three_slots_and_fallback_use_extra_module_space():
    pygame.init()
    short_surface = pygame.Surface((1000, 700))
    long_surface = pygame.Surface((1000, 700))

    draw_hud(
        screen=short_surface,
        score=10,
        kills=2,
        survival_time=9.0,
        health=94,
        max_health=100,
        wave=5,
        intermission_remaining=0.0,
        coins=10,
        run_scrap=30,
        active_weapon_key="sniper",
        active_weapon_name="Sniper Rifle",
        active_weapon_ammo="6/36",
        active_weapon_reload="",
        slot_labels=["*1: Sniper Rifle", " 2: Empty"],
        active_effects=[],
    )
    draw_hud(
        screen=long_surface,
        score=10,
        kills=2,
        survival_time=9.0,
        health=94,
        max_health=100,
        wave=5,
        intermission_remaining=0.0,
        coins=10,
        run_scrap=30,
        active_weapon_key="sniper",
        active_weapon_name="Sniper Rifle",
        active_weapon_ammo="6/36",
        active_weapon_reload="",
        slot_labels=["*1: Sniper Rifle", " 2: Burst Rifle", " 3: Shotgun", " Fallback [0/4]: Pistol (INF)"],
        active_effects=[],
    )

    module_left = 1000 - 356 - 16
    module_top = 700 - 206 - 14
    changed = False
    for x in range(module_left + 14, module_left + 220):
        for y in range(module_top + 118, module_top + 178):
            if short_surface.get_at((x, y)) != long_surface.get_at((x, y)):
                changed = True
                break
        if changed:
            break

    assert changed is True


def test_hud_controls_and_rule_panel_fit_minimum_viewport():
    pygame.init()
    width, height = 640, 448
    screen = pygame.Surface((width, height))

    draw_hud(
        screen=screen,
        score=10,
        kills=2,
        survival_time=9.0,
        health=94,
        max_health=100,
        wave=9,
        intermission_remaining=0.0,
        coins=10,
        run_scrap=30,
        active_weapon_key="sniper",
        active_weapon_name="Sniper Rifle",
        active_weapon_ammo="6/36",
        active_weapon_reload="",
        slot_labels=["*1: Sniper Rifle", " 2: Burst Rifle", " 3: Shotgun", " Fallback [0/4]: Pistol (INF)"],
        active_effects=[],
        mutation_button_text="Mutations [P]",
        armory_button_text="Close Armory [TAB]",
        armory_button_active=True,
        wave_rule_label="Mutator: Hunter Pack (aggressive pursuit)",
    )

    mutation = get_mutation_button_rect(width)
    armory = get_armory_button_rect(width)
    assert mutation.right <= width
    assert armory.right <= width
    assert armory.top > mutation.bottom
    assert screen.get_at((mutation.centerx, mutation.centery)) != pygame.Color(0, 0, 0, 255)

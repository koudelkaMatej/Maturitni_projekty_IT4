from pathlib import Path

import pytest

from game import database
from web.backend_app import create_app


@pytest.fixture
def web_client(tmp_path: Path):
    db_path = tmp_path / "web-auth.db"
    app = create_app(
        {
            "TESTING": True,
            "SECRET_KEY": "test-secret",
            "DATABASE_PATH": str(db_path),
        }
    )
    return app.test_client(), db_path


def test_register_success_and_duplicate_username(web_client):
    client, _ = web_client

    first = client.post(
        "/register",
        data={
            "username": "tester",
            "password": "safe-pass",
        },
        follow_redirects=True,
    )
    assert first.status_code == 200
    first_html = first.get_data(as_text=True)
    assert "Registrace proběhla úspěšně." in first_html
    assert "Profil hráče" in first_html

    duplicate = client.post(
        "/register",
        data={
            "username": "tester",
            "password": "other-pass",
        },
        follow_redirects=True,
    )
    assert duplicate.status_code == 200
    duplicate_html = duplicate.get_data(as_text=True)
    assert "Username is already taken." in duplicate_html


def test_login_success_and_wrong_password(web_client):
    client, db_path = web_client
    database.create_web_user("loginuser", "good-pass", db_path=db_path)

    bad = client.post(
        "/login",
        data={"username": "loginuser", "password": "bad-pass"},
        follow_redirects=True,
    )
    assert bad.status_code == 200
    bad_html = bad.get_data(as_text=True)
    assert "Neplatné přihlašovací údaje." in bad_html

    ok = client.post(
        "/login",
        data={"username": "loginuser", "password": "good-pass"},
        follow_redirects=False,
    )
    assert ok.status_code == 302
    assert ok.headers["Location"].endswith("/profil")


def test_profil_requires_login(web_client):
    client, _ = web_client
    response = client.get("/profil", follow_redirects=False)
    assert response.status_code == 302
    assert "/login" in response.headers["Location"]

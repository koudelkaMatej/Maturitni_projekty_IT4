﻿import pygame

from game.camera import Camera


def test_camera_center_and_conversion():
    world = pygame.Rect(0, 0, 1200, 900)
    camera = Camera(width=400, height=300, world_rect=world)

    target = pygame.Vector2(600, 450)
    camera.update(target)

    assert camera.offset == pygame.Vector2(400, 300)

    world_point = pygame.Vector2(650, 470)
    screen_point = camera.world_to_screen(world_point)
    assert screen_point == pygame.Vector2(250, 170)
    assert camera.screen_to_world(screen_point) == world_point


def test_camera_clamps_at_world_edges():
    world = pygame.Rect(0, 0, 1000, 700)
    camera = Camera(width=500, height=400, world_rect=world)

    camera.update(pygame.Vector2(20, 10))
    assert camera.offset == pygame.Vector2(0, 0)

    camera.update(pygame.Vector2(980, 690))
    assert camera.offset == pygame.Vector2(500, 300)

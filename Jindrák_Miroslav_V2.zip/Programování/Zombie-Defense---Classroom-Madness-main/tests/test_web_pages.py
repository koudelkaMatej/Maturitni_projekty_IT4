from pathlib import Path

import pytest

from game import database
from web.backend_app import create_app


@pytest.fixture
def seeded_client(tmp_path: Path):
    db_path = tmp_path / "web-pages.db"
    app = create_app(
        {
            "TESTING": True,
            "SECRET_KEY": "test-secret",
            "DATABASE_PATH": str(db_path),
        }
    )
    database.save_match_result("PageUser", 77, 33.2, db_path=db_path)
    database.save_match_result("PageUser", 55, 20.1, db_path=db_path)
    return app.test_client()


def test_public_routes_return_200(seeded_client):
    client = seeded_client
    for path in ["/", "/diagramy", "/dokumentace", "/o-hre", "/o-nas", "/leaderboard", "/register", "/login"]:
        response = client.get(path)
        assert response.status_code == 200, path


def test_navigation_contains_required_links(seeded_client):
    response = seeded_client.get("/")
    html = response.get_data(as_text=True)
    assert 'href="/"' in html
    assert 'href="/diagramy"' in html
    assert 'href="/dokumentace"' in html
    assert 'href="/o-hre"' in html
    assert 'href="/o-nas"' in html
    assert 'href="/leaderboard"' in html


def test_diagramy_page_references_er_asset(seeded_client):
    response = seeded_client.get("/diagramy")
    assert response.status_code == 200
    html = response.get_data(as_text=True)
    assert "img/er-diagram.png" in html


def test_leaderboard_renders_saved_data(seeded_client):
    response = seeded_client.get("/leaderboard")
    assert response.status_code == 200
    html = response.get_data(as_text=True)
    assert "PageUser" in html
    assert "77" in html


def test_templates_render_html_not_raw_jinja_tokens(seeded_client):
    client = seeded_client
    for path in ["/o-hre", "/dokumentace", "/register", "/login"]:
        response = client.get(path)
        assert response.status_code == 200
        html = response.get_data(as_text=True)
        assert "{%" not in html, path
        assert "{{" not in html, path
        assert "styles.css" in html, path

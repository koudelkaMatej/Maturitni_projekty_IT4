# Solo Project Compliance Checklist

This checklist maps school requirements to concrete evidence in this repository.
Use it for final defense, grading checkpoints, and final submission packaging.

## A) Technical Core (Game + Web + DB)

| Requirement | Status | Evidence |
|---|---|---|
| Game is implemented in Python | DONE | `game/main.py`, `requirements.txt` |
| Game loop (update + render) exists | DONE | `Game.run()` in `game/main.py` |
| Menu with start and exit | DONE | `game/ui.py` (`get_menu_options`), `Game.activate_menu_selection()` |
| Keyboard and mouse interaction | DONE | `Game.handle_events()`, `Game.get_movement_input()`, `Game.should_fire()` |
| Save results as player + score | DONE | `Game.persist_result()`, `game/storage.py`, `game/database.py` |
| Result includes name, score, date (and time) | DONE | `game/storage.py` (`format_score_line`), DB columns in `database/schema.sql` |
| Web presentation of project | DONE | `web/templates/*.html`, `web/backend_app.py` |
| Navigation bar with at least 4 linked pages | DONE | `web/templates/base.html` |
| One shared CSS for web pages | DONE | `web/static/styles.css`, linked in `web/templates/base.html` |
| Login and registration on web | DONE | `/register`, `/login` in `web/backend_app.py` |
| Display game results on web | DONE | `/leaderboard`, `/profil` routes in `web/backend_app.py` |
| Web serves as project presentation | DONE | `web/templates/index.html`, `o-hre.html`, `diagramy.html`, `o-nas.html` |

## B) Database Requirements

| Requirement | Status | Evidence |
|---|---|---|
| ER diagram exists | DONE | `database/ER_DIAGRAM.md` |
| DB schema script (CREATE) exists | DONE | `database/schema.sql` |
| Seed data script (INSERT) exists | DONE | `database/seed.sql` |
| Query script with SELECT and JOIN exists | DONE | `database/queries.sql` |
| Filtering, sorting, grouping, searching examples | DONE | `database/queries.sql` (`WHERE`, `ORDER BY`, `GROUP BY`, `LIKE`) |
| UPDATE and DELETE examples | DONE | `database/queries.sql` |
| Uses PK/FK/UNIQUE/NOT NULL/DEFAULT/AUTOINCREMENT | DONE | `database/schema.sql` |
| Includes 1:N and M:N relations | DONE | `database/schema.sql`, `database/ER_DIAGRAM.md` |
| DB used from Python | DONE | `game/database.py`, `game/main.py` |
| DB used from web interface | DONE | `web/backend_app.py` |
| BCNF declared and explained | DONE | BCNF note in `README.md` |

## C) Documentation + Testing

| Requirement | Status | Evidence |
|---|---|---|
| Classes and functions are documented | DONE | Docstrings across `game/*.py`, `web/backend_app.py` |
| Project has automated tests (min. 2) | DONE | `tests/` (86 tests) |
| Tests pass | DONE | `python -m pytest -q` |

## D) Manual/External Evidence (must be attached at submission)

| Requirement | Status | What to Attach |
|---|---|---|
| Teacher has repository access | MANUAL-EVIDENCE | Screenshot of repository collaborators/settings |
| Commit history shows author activity | MANUAL-EVIDENCE | `git log --oneline --decorate --graph` screenshot/export |
| Public or shared repository URL submitted | MANUAL-EVIDENCE | Final URL in submission text |
| Project runs in school lab environment | MANUAL-EVIDENCE | Short run demo or teacher verification note |

## E) Smoke Test Script for Defense

1. `python -m pip install -r requirements.txt`
2. `python game/main.py` and play one run until game over.
3. `python web/backend_app.py`, open `http://127.0.0.1:5000`.
4. Verify `Leaderboard` and `Profil` show saved result.
5. Run `python -m pytest -q` and show passing output.

﻿# 00 - TEMPLATE FORMAT (spolecny standard)

Kazdy template v `resources/templates` pouzivej ve stejnem formatu.

## Povinne sekce

1. `Pouziti`
2. `Soubor(y)`
3. `Najdi kotvu v kodu`
4. `Vloz tento blok`
5. `Nahrad placeholdery`
6. `Co jeste upravit`
7. `Rychly test`
8. `Typicke chyby`
9. `Rollback`

## Placeholdery

Pouzivej jednotny tvar placeholderu:
- `{{NEW_KEY}}`
- `{{DISPLAY_NAME}}`
- `{{DAMAGE}}`
- `{{UNLOCK_WAVE}}`

Pravidla:
- Placeholder vzdy nahrad realnou hodnotou.
- Klice (`{{NEW_KEY}}`) drzet lowercase + underscore.
- Stejny nazev klice pis vsude stejne v celem projektu.

## Dve varianty v kazdem template

- `Safe varianta`:
  - menis jen cisla nebo jednoduchy text,
  - minimum rizika,
  - vhodne pod casovym tlakem.

- `Full varianta`:
  - pridani noveho typu / nove polozky do seznamu / mapovani / testu,
  - vice kroku,
  - pouzij kdyz je na to cas a testy.

## Mini sablona (copy)

```md
## Pouziti
Kdy tuto sablonu pouzit.

## Soubor(y)
- path/a.py
- path/b.py

## Najdi kotvu v kodu
- `SOME_CONST = {`

## Vloz tento blok
```python
# block with {{PLACEHOLDER}}
```

## Nahrad placeholdery
- `{{PLACEHOLDER}}` -> ...

## Co jeste upravit
- testy
- navazne mapy

## Rychly test
```powershell
python -m pytest -q tests/test_x.py
```

## Typicke chyby
- nesedi key v jinem souboru

## Rollback
- smaz pridany block
- vrat puvodni hodnotu
```

## Rezim "jen Ctrl+C / Ctrl+V" (bez premysleni)

Tohle je univerzalni postup pro kazdy template:

1. Otevri template, ktery odpovida zadani ucitele.
2. Otevri prvni soubor ze sekce `Soubor(y)`.
3. Stiskni `Ctrl+F`.
4. Zkopiruj text ze sekce `Najdi kotvu v kodu` a vloz ho do hledani.
5. Stiskni `Enter`, dokud nenajdes presne stejny text.
6. Zkopiruj blok ze sekce `Vloz tento blok`.
7. Vloz ho PRESNE na misto uvedene v template (nad/pod kotvu podle instrukce).
8. Nahrad pouze texty ve slozenych zavorkach `{{...}}`.
9. Uloz soubor (`Ctrl+S`).
10. Opakuj kroky 2-9 pro dalsi soubor ze sekce `Soubor(y)`.
11. Otevri terminal a zkopiruj prikaz ze sekce `Rychly test`.
12. Vloz ho do terminalu a stiskni `Enter`.
13. Kdyz test neprojde, zkopiruj kroky ze sekce `Rollback` a proved je.

Zakazano (v tomhle rezimu):
- Nepsat nic "po svem".
- Nemenit jine radky, nez ktere template rika.
- Nedelat "vylepseni navic".

Mini slovnik:
- `kotva` = presny text, podle ktereho to najdes (`Ctrl+F`).
- `placeholder` = text ve tvaru `{{NECO}}`, ktery jen prepises hodnotou.

﻿# 03 - Add Skin

## Pouziti
Pouzij, kdyz ucitel chce novy skin do skin shopu.

## Krok za krokem (pro uplneho zacatecnika)

1. Priprav hodnoty, napriklad:
- `{{SKIN_KEY}} = neon_shadow`
- `{{DISPLAY_NAME}} = Neon Shadow`
- `{{PRICE_COINS}} = 320`
- `{{PRIMARY_RGB}} = 120,210,255`
- `{{SECONDARY_RGB}} = 240,120,255`
2. Otevri `game/database.py`.
3. Najdi `DEFAULT_SKINS`.
4. Pridej novy radek tuple (podle `Safe varianta`) na konec seznamu.
5. Otevri `database/seed.sql`.
6. Pridej SQL insert block ze sablony.
7. Uloz oba soubory.
8. Spust test:
- `python -m pytest -q tests/test_database.py`
9. Spust hru/web a prihlas se.
10. Otevri Shop a over:
- skin je v seznamu,
- lze odemknout,
- po vyberu se zmeni barvy hrace.
11. Pokud skin nevidis v existujici `game.db`, pouzij "manual SQL" blok jednorazove.

## Rezim "bez rozhodovani" (autopilot)

Kdyz ucitel rekne "pridej skin", udelej jen tohle:

1. Zkopiruj jeden tuple radek ze `Safe varianta` do `DEFAULT_SKINS`.
2. Zkopiruj SQL insert block do `database/seed.sql`.
3. Prepis placeholdery.
4. Spust `python -m pytest -q tests/test_database.py`.
5. Hotovo.

## Soubor(y)
- `game/database.py` (`DEFAULT_SKINS`)
- `database/seed.sql`
- volitelne: live DB `database/game.db` (manual SQL)
- `tests/test_database.py`

## Najdi kotvu v kodu
- `DEFAULT_SKINS: list[tuple[str, str, int, str, str, int]] = [`

## Vloz tento blok

Safe varianta (jen app-level default seed):
```python
("{{SKIN_KEY}}", "{{DISPLAY_NAME}}", {{PRICE_COINS}}, "{{PRIMARY_RGB}}", "{{SECONDARY_RGB}}", 0),
```

Do `database/seed.sql`:
```sql
INSERT INTO skins (skin_key, display_name, price_coins, primary_color, secondary_color, is_default) VALUES
('{{SKIN_KEY}}', '{{DISPLAY_NAME}}', {{PRICE_COINS}}, '{{PRIMARY_RGB}}', '{{SECONDARY_RGB}}', 0)
ON CONFLICT(skin_key) DO NOTHING;
```

SQL pro existujici `game.db` (manual jednorazove):
```sql
INSERT INTO skins (skin_key, display_name, price_coins, primary_color, secondary_color, is_default)
VALUES ('{{SKIN_KEY}}', '{{DISPLAY_NAME}}', {{PRICE_COINS}}, '{{PRIMARY_RGB}}', '{{SECONDARY_RGB}}', 0)
ON CONFLICT(skin_key) DO NOTHING;
```

## Nahrad placeholdery
- `{{SKIN_KEY}}`: lowercase, napr. `ember_x`
- RGB format: striktne `"R,G,B"` napr. `"120,210,255"`

## Co jeste upravit
- Neni potreba menit UI kod, shop cte skiny dynamicky z DB.
- Default skin (`is_default=1`) nech jen jeden (nejbezpecneji `classic`).

## Rychly test
```powershell
python -m pytest -q tests/test_database.py
```

Manual:
- prihlas se,
- otevri Shop,
- over ze skin je v seznamu a jde odemknout/vybrat.

## Typicke chyby
- Spatny RGB format (napr. `120;210;255`).
- Duplicita `skin_key`.

## Rollback
- Odeber radek z `DEFAULT_SKINS`.
- Odeber insert ze `seed.sql`.
- V live DB proved:
```sql
DELETE FROM skins WHERE skin_key='{{SKIN_KEY}}';
```

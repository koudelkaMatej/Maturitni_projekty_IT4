﻿# 08 - Tune Wave / Mutator / Objective

## Pouziti
Pouzij, kdyz ucitel chce zmenit tempo hry (spawn pace), objective nebo mutator obtiznost.

## Krok za krokem (roboticky postup, jen Ctrl+C/Ctrl+V)

Nejcastejsi pozadavky ucitele:
- "vlny jsou moc lehke / moc tezke"
- "spawnuje se to moc rychle / pomalu"

Postup:

1. Otevri `game/waves.py`.
2. Stiskni `Ctrl+F`, vloz `_spawn_budget_for_wave`.
3. Uprav jen cisla ve `return` (kolik nepratel celkem).
4. Stiskni `Ctrl+F`, vloz `_spawn_interval_for_wave`.
5. Uprav jen cisla ve `return` (jak casto se spawnuji).
6. Uloz `Ctrl+S`.
7. Spust test:
```powershell
python -m pytest -q tests/test_waves.py
```
8. Pokud ucitel rekl konkretne mutator/objective:
- v `game/waves.py` hledej `_spawn_modifiers_for_current_wave`,
- najdi presny klic (napr. `"swarm_protocol"`),
- uprav jen cisla `budget_mult` / `interval_mult`.
9. Spust i druhy test:
```powershell
python -m pytest -q tests/test_main_progression.py -k "wave or objective or mutator"
```

Ultra-safe pravidlo:
- Pokud ucitel VYLOVENE nerekl "pridej novy mutator/objective", nepridavej nove nazvy.
- Jen prepisuj existujici cisla.

## Soubor(y)
- `game/waves.py`
- volitelne `game/main.py` (labely/hud text)
- `tests/test_waves.py`
- volitelne `tests/test_main_progression.py`

## Najdi kotvu v kodu
- `_spawn_budget_for_wave`
- `_spawn_interval_for_wave`
- `OBJECTIVE_ROTATION`
- `MUTATOR_ROTATION`
- `_spawn_modifiers_for_current_wave`

## Vloz tento blok

Safe varianta (jen pacing):
```python
@staticmethod
def _spawn_budget_for_wave(wave: int) -> int:
    return {{BASE}} + wave * {{LINEAR}} + wave // {{DIV}}

@staticmethod
def _spawn_interval_for_wave(wave: int) -> float:
    return max({{MIN_INTERVAL}}, {{START_INTERVAL}} - wave * {{STEP}})
```

Full varianta (mutator/objective multipliers):
```python
if mutator == "{{MUTATOR_KEY}}":
    budget_mult *= {{BUDGET_MULT}}
    interval_mult *= {{INTERVAL_MULT}}

if objective == "{{OBJECTIVE_KEY}}":
    budget_mult *= {{OBJ_BUDGET_MULT}}
    interval_mult *= {{OBJ_INTERVAL_MULT}}
```

## Nahrad placeholdery
- Klice mutator/objective udrz konzistentni s rotacemi.

## Co jeste upravit
- Kdyz pridas novy key, dopln i textovy label v main HUD (pokud se zobrazuje).

## Rychly test
```powershell
python -m pytest -q tests/test_waves.py
python -m pytest -q tests/test_main_progression.py -k "wave or objective or mutator"
```

## Typicke chyby
- Novy key je v rotation, ale nema multipliers vetvu.
- Prilis nizky interval = prepaleny spawn.

## Rollback
- Vrat puvodni vzorce budget/interval.
- Vrat puvodni rotace a multiplier vetve.

﻿# 09 - Add PowerUp or Tune Drop

## Pouziti
Pouzij, kdyz ucitel chce novy power-up nebo upravu drop sance/efektu.

## Krok za krokem (roboticky postup, jen Ctrl+C/Ctrl+V)

Nejcastejsi pozadavky ucitele:
- "at pada vic healu"
- "at pada min ammo cache"

Tohle je nejbezpecnejsi (jen uprava vah dropu):

1. Otevri `game/powerups.py`.
2. Stiskni `Ctrl+F`.
3. Vloz `maybe_spawn_drop`.
4. Najdi cast `weights=[...]`.
5. Prepis jen cisla ve `weights`.
6. Uloz `Ctrl+S`.
7. Spust test:
```powershell
python -m pytest -q tests/test_powerups.py
```
8. Spust hru a over, ze opravdu padaji casteji/mene caste.

Pokud ucitel VYLOVENE rekne "pridej uplne novy power-up":

1. Pouzij `Full varianta` bloky niz (kopiruj-vloz).
2. Udelej presne tyto 4 vlozeni:
- do seznamu `PowerUpType`,
- do `_apply_effect`,
- do `active_effect_labels` (kdyz ma trvani),
- do `pickup_color`.
3. Uloz.
4. Spust test znovu.

Ultra-safe pravidlo:
- Pokud ucitel nerekl "novy power-up", nepridavej novy typ.
- Upravuj jen `weights` cisla.

## Soubor(y)
- `game/powerups.py`
- volitelne `game/main.py` (pokud je potreba special handling)
- `tests/test_powerups.py`

## Najdi kotvu v kodu
- `class PowerUpType(Enum):`
- `maybe_spawn_drop`
- `_apply_effect`
- `active_effect_labels`
- `pickup_color`

## Vloz tento blok

Safe varianta (jen tuning drop rates):
```python
kind = random.choices(
    [PowerUpType.RAPID_FIRE, PowerUpType.HEAL_PACK, PowerUpType.FREEZE_BLAST, PowerUpType.AMMO_CACHE],
    weights=[{{W_RAPID}}, {{W_HEAL}}, {{W_FREEZE}}, {{W_AMMO}}],
    k=1,
)[0]
```

Full varianta (novy power-up):
```python
class PowerUpType(Enum):
    RAPID_FIRE = auto()
    HEAL_PACK = auto()
    FREEZE_BLAST = auto()
    AMMO_CACHE = auto()
    {{NEW_POWERUP_ENUM}} = auto()
```

```python
elif kind == PowerUpType.{{NEW_POWERUP_ENUM}}:
    # aplikuj efekt
    {{NEW_EFFECT_CODE}}
```

```python
if kind == PowerUpType.{{NEW_POWERUP_ENUM}}:
    return ({{R}}, {{G}}, {{B}})
```

## Nahrad placeholdery
- `{{NEW_POWERUP_ENUM}}` uppercase token.
- Efekt kod drzet jednoduchy a testovatelny.

## Co jeste upravit
- Doplneni HUD labelu, pokud ma efekt trvani.
- Doplneni testu v `tests/test_powerups.py`.

## Rychly test
```powershell
python -m pytest -q tests/test_powerups.py
```

## Typicke chyby
- Novy powerup je v enumu, ale chybi v `pickup_color`.
- Chybi handling v `_apply_effect`.

## Rollback
- Odeber novy enum token.
- Odeber novou effect branch.
- Vrat puvodni weights.

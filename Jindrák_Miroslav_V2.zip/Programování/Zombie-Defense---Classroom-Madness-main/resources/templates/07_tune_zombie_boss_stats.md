﻿# 07 - Tune Zombie/Boss Stats

## Pouziti
Pouzij, kdyz ucitel chce rychly rebalance (HP/speed/dmg/score/coin, boss multipliers) bez noveho typu.

## Krok za krokem (roboticky postup, jen Ctrl+C/Ctrl+V)

Pouzij, kdyz ucitel rekne:
- "zvys hp u walkera"
- "boss je moc silny/slaby"

Postup:

1. Otevri `game/enemy.py`.
2. Stiskni `Ctrl+F`.
3. Pokud ucitel rekl bezne zombie (walker/runner/tank):
- hledej `ZOMBIE_STATS`.
- najdi radek s danou zombie a prepis jen cislo, ktere ucitel rekl.
4. Pokud ucitel rekl boss:
- stiskni `Ctrl+F` a hledej `set_boss_archetype`.
- najdi cast pro daneho bosse (`WARDEN`, `RAVAGER`, ...).
- prepis jen cisla, ktera ucitel rekl.
5. Uloz `Ctrl+S`.
6. Otevri terminal a spust:
```powershell
python -m pytest -q tests/test_enemy.py
```
7. Kdyz test selze na ciselne hodnote:
- otevri `tests/test_enemy.py`,
- najdi stejny nazev (Ctrl+F),
- prepis testove cislo na novou hodnotu,
- spust test znovu.

Ultra-safe pravidlo:
- Men jen 1 oblast najednou (napr. jen WALKER HP), pak hned test.

## Soubor(y)
- `game/enemy.py`
- `tests/test_enemy.py`

## Najdi kotvu v kodu
- `ZOMBIE_STATS`
- `set_boss_archetype`
- boss constants (`BOSS_CHARGE_*`, `BOSS_LEAP_*`, ...)

## Vloz tento blok

Safe varianta (jen `ZOMBIE_STATS`):
```python
ZombieType.WALKER: ZombieStats(
    speed={{WALKER_SPEED}},
    radius=16,
    max_health={{WALKER_HP}},
    damage={{WALKER_DMG}},
    color=(70, 200, 110),
    score_value={{WALKER_SCORE}},
    coin_value={{WALKER_COINS}},
),
```

Full varianta (boss profil multipliers):
```python
if token == BossArchetype.WARDEN.value:
    self.max_health = max(1, int(round(self.max_health * {{WARDEN_HP_MULT}})))
    self.base_speed *= {{WARDEN_SPEED_MULT}}
    self.boss_slam_radius_mult = {{WARDEN_SLAM_RADIUS_MULT}}
    self.boss_slam_damage_mult = {{WARDEN_SLAM_DMG_MULT}}
```

## Nahrad placeholdery
- Drz realisticke hodnoty, at neudelas nehratelny build.

## Co jeste upravit
- Update test expected values v `tests/test_enemy.py`.

## Rychly test
```powershell
python -m pytest -q tests/test_enemy.py
```

## Typicke chyby
- Menis constants, ale nechecknes phase/boss ability flow.
- Extreme hodnoty (speed moc vysoko) rozbiji feeling hry.

## Rollback
- Vrat puvodni constants + puvodni test expected values.

﻿# 06 - Add Boss Archetype

## Pouziti
Pouzij, kdyz ucitel chce novou variantu boss chovani (archetyp).

## Krok za krokem (pro uplneho zacatecnika)

1. Priprav nazvy:
- `{{NEW_BOSS_ENUM}}` napr. `SENTINEL` (UPPERCASE),
- `{{NEW_BOSS_KEY}}` napr. `sentinel` (lowercase),
- `{{NEW_BOSS_LABEL}}` napr. `Sentinel`,
- kratky `{{NEW_BOSS_HINT}}`.
2. Otevri `game/enemy.py`.
3. Pridej novy archetyp do `class BossArchetype(Enum)`.
4. V `set_boss_archetype`:
- pridej token do valid-check mnoziny,
- pridej novou `elif` branch s multipliers.
5. Otevri `game/main.py`.
6. Pridej novy key do:
- `BOSS_ARCHETYPE_LABELS`
- `BOSS_COUNTER_HINTS`
7. Otevri `game/waves.py` (obvykle se nacte z enum values automaticky, ale zkontroluj).
8. Uloz soubory.
9. Spust testy:
- `python -m pytest -q tests/test_enemy.py`
- `python -m pytest -q tests/test_waves.py`
- `python -m pytest -q tests/test_main_progression.py -k "boss"`
10. Manual check ve hre:
- pockej na boss wave,
- over, ze se muze objevit novy archetyp,
- zobrazi se label/hint a boss se chova podle nastaveni.

## Rezim "bez rozhodovani" (autopilot)

Pokud ucitel nerekl "pridat novy boss typ", ale jen "uprav boss", nepouzivej tento template.
Pouzij `07_tune_zombie_boss_stats.md`.

Pokud opravdu chce novy boss typ:
1. Zkopiruj vsechny 4 bloky v poradi (enum -> valid check -> tuning branch -> labels/hints).
2. Prepis placeholdery.
3. Spust testy z `Rychly test`.

## Soubor(y)
- `game/enemy.py`
- `game/waves.py`
- `game/main.py`
- `tests/test_enemy.py`
- `tests/test_waves.py`
- volitelne `tests/test_main_progression.py`

## Najdi kotvu v kodu
- `class BossArchetype(Enum):`
- `Zombie.set_boss_archetype(...)`
- `WaveManager.BOSS_ARCHETYPES`
- `BOSS_ARCHETYPE_LABELS`
- `BOSS_COUNTER_HINTS`

## Vloz tento blok

Do enumu:
```python
class BossArchetype(Enum):
    WARDEN = "warden"
    RAVAGER = "ravager"
    BROODLORD = "broodlord"
    {{NEW_BOSS_ENUM}} = "{{NEW_BOSS_KEY}}"
```

Do `set_boss_archetype` valid token check:
```python
if token not in {
    BossArchetype.WARDEN.value,
    BossArchetype.RAVAGER.value,
    BossArchetype.BROODLORD.value,
    BossArchetype.{{NEW_BOSS_ENUM}}.value,
}:
    token = BossArchetype.WARDEN.value
```

Priklad tuning vetve:
```python
elif token == BossArchetype.{{NEW_BOSS_ENUM}}.value:
    self.max_health = max(1, int(round(self.max_health * {{HP_MULT}})))
    self.health = self.max_health
    self.base_speed *= {{SPEED_MULT}}
    self.speed = self.base_speed
    self.boss_charge_cooldown_mult = {{CHARGE_CD_MULT}}
    self.boss_leap_cooldown_mult = {{LEAP_CD_MULT}}
    self.boss_commander_cooldown_mult = {{COMMANDER_CD_MULT}}
```

Do `game/main.py` map:
```python
BOSS_ARCHETYPE_LABELS: dict[str, str] = {
    # ...
    BossArchetype.{{NEW_BOSS_ENUM}}.value: "{{NEW_BOSS_LABEL}}",
}

BOSS_COUNTER_HINTS: dict[str, str] = {
    # ...
    BossArchetype.{{NEW_BOSS_ENUM}}.value: "Boss Tip: {{NEW_BOSS_HINT}}",
}
```

## Nahrad placeholdery
- `{{NEW_BOSS_KEY}}` lowercase, napr. `sentinel`
- `{{NEW_BOSS_ENUM}}` uppercase enum, napr. `SENTINEL`

## Co jeste upravit
- Over, ze se novy archetyp vyskytne v boss wave (vyber je z enum values).
- Doplneni testu pro nový archetyp multipliers.

## Rychly test
```powershell
python -m pytest -q tests/test_enemy.py
python -m pytest -q tests/test_waves.py
python -m pytest -q tests/test_main_progression.py -k "boss"
```

## Typicke chyby
- Klic je v enumu, ale chybi v label/hint mape.
- Token mismatch (`sentinel` vs `sentry`).

## Rollback
- Odeber novy enum token.
- Odeber branch v `set_boss_archetype`.
- Odeber label/hint map entry.

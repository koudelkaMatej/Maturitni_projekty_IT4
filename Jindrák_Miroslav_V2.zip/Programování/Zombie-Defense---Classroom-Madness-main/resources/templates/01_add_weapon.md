﻿# 01 - Add Weapon

## Pouziti
Pouzij, kdyz ucitel chce pridat novou zbran do hry a armory.

## Krok za krokem (pro uplneho zacatecnika)

1. Rozhodni, jestli staci `Safe varianta`.
- Pokud ucitel rekl jen "pridej zbran", pouzij `Safe varianta`.
- `Full varianta` pouzij jen kdyz chce burst/shotgun specialitu.
2. Priprav si hodnoty do placeholderu, napriklad:
- `{{NEW_KEY}} = laser_rifle`
- `{{DISPLAY_NAME}} = Laser Rifle`
- `{{PRICE_POINTS}} = 900`
- `{{DAMAGE}} = 22`
- `{{FIRE_MODE}} = auto`
3. Otevri `game/weapons.py`.
4. Najdi kotvu `WEAPON_CATALOG: dict[str, WeaponSpec] = {`.
5. Zkopiruj blok z template a vloz ho dovnitr katalogu (za jinou zbran).
6. Nahrad vsechny `{{...}}` vlastnimi hodnotami.
7. Zkontroluj syntax:
- kazda polozka v dict konci carkou,
- `fire_mode` je jen `single`, `auto` nebo `burst`.
8. Uloz soubor.
9. (Volitelne) Pridej ikonu:
- soubor `game/assets/weapons/{{NEW_KEY}}.png`
- kdyz ikona neni, hra nespadne (pouzije placeholder).
10. Spust testy z `Rychly test`.
11. Spust hru a over:
- zbran je v armory,
- lze ji koupit a vystrelit.

## Rezim "bez rozhodovani" (autopilot)

Kdyz ucitel rekne "pridej zbran", udelej jen tohle:

1. Zkopiruj blok `Safe varianta`.
2. Vloz ho do `WEAPON_CATALOG`.
3. Prepis placeholdery presne podle zadani ucitele.
4. Nemen nic dalsiho.
5. Spust testy z `Rychly test`.

## Soubor(y)
- `game/weapons.py`
- volitelne `game/assets/weapons/{{NEW_KEY}}.png`
- `tests/test_weapons.py`
- volitelne `tests/test_main_progression.py`

## Najdi kotvu v kodu
- `WEAPON_CATALOG: dict[str, WeaponSpec] = {`

## Vloz tento blok

Safe varianta (jen nova zbran v katalogu):
```python
"{{NEW_KEY}}": WeaponSpec(
    key="{{NEW_KEY}}",
    display_name="{{DISPLAY_NAME}}",
    price_points={{PRICE_POINTS}},
    damage={{DAMAGE}},
    fire_mode="{{FIRE_MODE}}",  # single | auto | burst
    cooldown={{COOLDOWN}},
    magazine_size={{MAG_SIZE}},
    reserve_ammo={{RESERVE_AMMO}},
    reload_time={{RELOAD_TIME}},
    projectile_speed={{PROJECTILE_SPEED}},
    required_area="{{REQUIRED_AREA}}",
    unlock_wave={{UNLOCK_WAVE}},
),
```

Full varianta (kdyz je to burst/shotgun-like):
```python
"{{NEW_KEY}}": WeaponSpec(
    key="{{NEW_KEY}}",
    display_name="{{DISPLAY_NAME}}",
    price_points={{PRICE_POINTS}},
    damage={{DAMAGE}},
    fire_mode="{{FIRE_MODE}}",
    cooldown={{COOLDOWN}},
    magazine_size={{MAG_SIZE}},
    reserve_ammo={{RESERVE_AMMO}},
    reload_time={{RELOAD_TIME}},
    projectile_speed={{PROJECTILE_SPEED}},
    required_area="{{REQUIRED_AREA}}",
    unlock_wave={{UNLOCK_WAVE}},
    pellet_count={{PELLET_COUNT}},
    pellet_spread_degrees={{PELLET_SPREAD_DEGREES}},
    burst_count={{BURST_COUNT}},
    burst_interval={{BURST_INTERVAL}},
    projectile_radius={{PROJECTILE_RADIUS}},
),
```

## Nahrad placeholdery
- `{{NEW_KEY}}`: napr. `plasma_rifle`
- `{{FIRE_MODE}}`: `single`, `auto` nebo `burst`
- `{{REQUIRED_AREA}}`: existujici area key
- cisla doladit podle balancu

## Co jeste upravit
- Ikona zbrane (volitelne):
  - uloz PNG jako `game/assets/weapons/{{NEW_KEY}}.png`
  - kdyz chybi, UI pouzije placeholder ikonu (bez padu)
- Pridat/aktualizovat testy v `tests/test_weapons.py`

## Rychly test
```powershell
python -m pytest -q tests/test_weapons.py
python -m pytest -q tests/test_main_progression.py -k "weapon or armory"
```

## Typicke chyby
- `spec_key` neodpovida key v katalogu.
- `fire_mode` mimo povolene hodnoty.
- Chybejici carka mezi polozkami dict.

## Rollback
- Smaz pridany block z `WEAPON_CATALOG`.
- Smaz pripadnou novou ikonu v `game/assets/weapons/`.
- Vrat testy na puvodni stav.

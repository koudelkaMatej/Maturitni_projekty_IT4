﻿# 04 - Tune Skin Price/Color

## Pouziti
Pouzij, kdyz ucitel chce jen zmenit cenu nebo barvy existujiciho skinu.

## Krok za krokem (pro uplneho zacatecnika)

1. Priprav presne, co se meni:
- `{{SKIN_KEY}}` (ktery skin),
- nova cena,
- nove barvy (RGB ve formatu `R,G,B`).
2. Otevri `game/database.py`.
3. Najdi tuple s danym `skin_key` v `DEFAULT_SKINS`.
4. Uprav cenu/barvy (a pripadne display_name, pokud ucitel chce).
5. Otevri `database/seed.sql`.
6. Najdi radek pro stejny `skin_key` a uprav stejne hodnoty.
7. Uloz soubory.
8. Pro bezici/starsi DB muzes pouzit SQL `UPDATE` blok ze sablony.
9. Spust test:
- `python -m pytest -q tests/test_database.py`
10. Manual check:
- v shopu je nova cena,
- po vyberu skinu se projevi nove barvy.

## Rezim "bez rozhodovani" (autopilot)

Kdyz ucitel rekne "zmen cenu/barvu skinu", udelej jen:

1. Najdi `skin_key` v `game/database.py` a `database/seed.sql`.
2. Prepis jen cenu/barvy.
3. Spust `python -m pytest -q tests/test_database.py`.

## Soubor(y)
- `game/database.py` (`DEFAULT_SKINS`)
- `database/seed.sql`
- volitelne live update v `database/game.db`

## Najdi kotvu v kodu
- skin tuple podle `skin_key`

## Vloz tento blok

Safe varianta (jen cena):
```python
("{{SKIN_KEY}}", "{{DISPLAY_NAME}}", {{NEW_PRICE_COINS}}, "{{PRIMARY_RGB}}", "{{SECONDARY_RGB}}", {{IS_DEFAULT}}),
```

SQL update live DB:
```sql
UPDATE skins
SET price_coins={{NEW_PRICE_COINS}},
    primary_color='{{PRIMARY_RGB}}',
    secondary_color='{{SECONDARY_RGB}}'
WHERE skin_key='{{SKIN_KEY}}';
```

## Nahrad placeholdery
- RGB drzet jako `"R,G,B"`.
- `{{IS_DEFAULT}}` nech 0, pokud to neni default skin.

## Co jeste upravit
- Kdyz menis `display_name`, proved zmenu i v `seed.sql`.

## Rychly test
```powershell
python -m pytest -q tests/test_database.py
```

Manual shop check:
- cena odpovida,
- barvy odpovidaji na hraci po vyberu skinu.

## Typicke chyby
- Barvy mimo rozsah 0..255.
- Vice skinu s `is_default=1`.

## Rollback
- Vrat puvodni tuple values.
- Vrat puvodni SQL hodnoty.

﻿# 02 - Tune Weapon Stats

## Pouziti
Pouzij, kdyz ucitel chce jen zmenu hodnot existujici zbrane (bez nove entity).

## Krok za krokem (roboticky postup, jen Ctrl+C/Ctrl+V)

Pouzij, kdyz ucitel rekne napr.:
- "zvys damage u shotgun"
- "zmensi cooldown u snipera"

Postup:

1. Otevri `game/weapons.py`.
2. Stiskni `Ctrl+F`.
3. Vloz presny text zbrane, kterou ucitel rekl, napr. `"shotgun": WeaponSpec(`.
4. Kdyz ji najdes, uprav jen cisla, ktera ucitel rekl.
5. Nic jineho nemen.
6. Uloz `Ctrl+S`.
7. Otevri terminal.
8. Vloz a spust:
```powershell
python -m pytest -q tests/test_weapons.py
```
9. Kdyz test selze kvuli "expected value", otevri `tests/test_weapons.py`.
10. Stiskni `Ctrl+F` a najdi stejnou zbran.
11. Prepis pouze testove cislo na novou hodnotu.
12. Znovu spust stejny test.

Ultra-safe pravidlo:
- 1 uciteluv pozadavek = 1-2 prepsana cisla, nic navic.

## Soubor(y)
- `game/weapons.py`
- `tests/test_weapons.py`

## Najdi kotvu v kodu
- Konkretni zbran v `WEAPON_CATALOG`

## Vloz tento blok

Safe varianta (jen prepsani cisel v existujici zbrani):
```python
"{{WEAPON_KEY}}": WeaponSpec(
    key="{{WEAPON_KEY}}",
    display_name="{{DISPLAY_NAME}}",
    price_points={{PRICE_POINTS}},
    damage={{DAMAGE}},
    fire_mode="{{FIRE_MODE}}",
    cooldown={{COOLDOWN}},
    magazine_size={{MAG_SIZE}},
    reserve_ammo={{RESERVE_AMMO}},
    reload_time={{RELOAD_TIME}},
    projectile_speed={{PROJECTILE_SPEED}},
    required_area="{{REQUIRED_AREA}}",
    unlock_wave={{UNLOCK_WAVE}},
),
```

Full varianta (vetsi rebalance vcetne spread/burst):
```python
# navic uprav:
pellet_count={{PELLET_COUNT}},
pellet_spread_degrees={{PELLET_SPREAD_DEGREES}},
burst_count={{BURST_COUNT}},
burst_interval={{BURST_INTERVAL}},
projectile_radius={{PROJECTILE_RADIUS}},
```

## Nahrad placeholdery
- `{{WEAPON_KEY}}` musi byt existujici key (`shotgun`, `sniper`, ...)
- uprav jen to, co ucitel chtel

## Co jeste upravit
- Aktualizuj assertions v `tests/test_weapons.py` (damage/cooldown/reload/...)

## Rychly test
```powershell
python -m pytest -q tests/test_weapons.py
```

## Typicke chyby
- Zmenis kod, ale neupdatujes test values.
- Nechtene zmenis i jine zbrane.

## Rollback
- Vrat puvodni hodnoty jedne zbrane.
- Pust test znovu.

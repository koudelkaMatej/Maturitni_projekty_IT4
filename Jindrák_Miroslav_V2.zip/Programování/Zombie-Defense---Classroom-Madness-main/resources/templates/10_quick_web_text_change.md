﻿# 10 - Quick Web Text Change

## Pouziti
Pouzij, kdyz ucitel chce upravit text na webu bez zmeny backend logiky.

## Krok za krokem (pro uplneho zacatecnika)

1. Napis si presne vetu, kterou ucitel chce zmenit.
2. V terminalu najdi, kde ta veta je:
```powershell
rg -n "CAST_TEXT_KTERY_HLEDAS" web/templates
```
3. Otevri nalezeny `.html` soubor v `web/templates`.
4. Uprav jen text uvnitr HTML/Jinja, nemen route names ani Python kod.
5. Kdyz pridavas novy odstavec, zkopiruj `Safe varianta` `<p>{{NEW_TEXT}}</p>`.
6. Kdyz pridavas tlacitko/sekci, pouzij `Full varianta`.
7. U Jinja syntaxe pozor na zavorky:
- `{{ ... }}` pro hodnotu,
- `{% ... %}` pro logiku.
8. Uloz soubor.
9. Spust testy:
- `python -m pytest -q tests/test_web_pages.py`
- `python -m pytest -q tests/test_web_auth.py`
10. Spust web a otevri stranky:
- `/`, `/leaderboard`, `/login`, `/register`, `/profil`
11. Zkontroluj, ze text je zmeneny a stranka nespadne.

## Rezim "bez rozhodovani" (autopilot)

Kdyz ucitel chce jen zmenu textu:

1. Najdi text pres `rg -n`.
2. Prepis text 1:1.
3. Nemen `{{ ... }}` a `{% ... %}` casti.
4. Spust testy z `Rychly test`.

## Soubor(y)
- `web/templates/index.html`
- `web/templates/o-hre.html`
- `web/templates/o-nas.html`
- `web/templates/diagramy.html`
- `web/templates/leaderboard.html`
- `web/templates/login.html`
- `web/templates/register.html`
- `web/templates/profil.html`

## Najdi kotvu v kodu
- Hledej existujici text pomoci:
```powershell
rg -n "{{TEXT_TO_REPLACE}}" web/templates
```

## Vloz tento blok

Safe varianta (jen prepis textu):
```html
<p>{{NEW_TEXT}}</p>
```

Full varianta (novy blok s CTA):
```html
<section class="card">
  <h2>{{NEW_TITLE}}</h2>
  <p>{{NEW_TEXT}}</p>
  <a class="button" href="{{URL_OR_JINJA}}">{{BUTTON_LABEL}}</a>
</section>
```

## Nahrad placeholdery
- `{{URL_OR_JINJA}}` muze byt napr. `{{ url_for('leaderboard') }}`

## Co jeste upravit
- Kdyz menis nav text, zkontroluj i `web/templates/base.html`.
- Neprejmenovavat Flask route names bez zasahu do `web/backend_app.py`.

## Rychly test
```powershell
python -m pytest -q tests/test_web_pages.py
python -m pytest -q tests/test_web_auth.py
```

Manual:
- otevri `/`, `/leaderboard`, `/login`, `/register`, `/profil`.

## Typicke chyby
- Rozbite Jinja zavorky (`{{ ... }}` nebo `{% ... %}`).
- Zmena route nazvu v template bez backend zmeny.

## Rollback
- Vrat posledni editovany template na puvodni text.
- Pust `tests/test_web_pages.py`.

﻿# 05 - Add Zombie Type

## Pouziti
Pouzij, kdyz ucitel chce novy typ zombie (ne boss archetyp).

## Krok za krokem (pro uplneho zacatecnika)

1. Nejdriv se rozhodni:
- pokud ucitel chce jen "vic tezke vlny", pouzij `Safe varianta` (jen weights),
- pokud chce opravdu "novy typ zombie", pouzij `Full varianta`.
2. (Full) Priprav hodnoty:
- `{{NEW_ZOMBIE_ENUM}}` napr. `SPITTER`
- speed/hp/damage/score/coin/color.
3. Otevri `game/enemy.py`.
4. V `class ZombieType(Enum)` pridej novy enum token.
5. V `ZOMBIE_STATS` pridej novou polozku pro tento enum.
6. Otevri `game/waves.py`.
7. Najdi `_pick_spawn_type` a pridej novy typ do `random.choices(...)` + weights.
8. Uloz soubory.
9. Spust testy:
- `python -m pytest -q tests/test_enemy.py`
- `python -m pytest -q tests/test_waves.py`
10. Spust hru a over:
- novy typ se opravdu spawnuje,
- nema chyby animace/kolize/damage.

## Rezim "bez rozhodovani" (autopilot)

Kdyz ucitel nerekl "uplne novy typ", pouzij jen `Safe varianta`:

1. Otevri `game/waves.py`.
2. Najdi `_pick_spawn_type`.
3. Prepis jen `weights=[...]`.
4. Spust:
```powershell
python -m pytest -q tests/test_enemy.py
python -m pytest -q tests/test_waves.py
```

## Soubor(y)
- `game/enemy.py`
- `game/waves.py`
- volitelne `tests/test_enemy.py`
- volitelne `tests/test_waves.py`

## Najdi kotvu v kodu
- `class ZombieType(Enum):`
- `ZOMBIE_STATS: dict[ZombieType, ZombieStats] = {`
- `def _pick_spawn_type(self) -> ZombieType:`

## Vloz tento blok

Full varianta (novy typ + staty):
```python
class ZombieType(Enum):
    WALKER = auto()
    RUNNER = auto()
    TANK = auto()
    BOSS = auto()
    {{NEW_ZOMBIE_ENUM}} = auto()
```

```python
ZombieType.{{NEW_ZOMBIE_ENUM}}: ZombieStats(
    speed={{SPEED}},
    radius={{RADIUS}},
    max_health={{MAX_HEALTH}},
    damage={{DAMAGE}},
    color=({{R}}, {{G}}, {{B}}),
    score_value={{SCORE_VALUE}},
    coin_value={{COIN_VALUE}},
),
```

Safe varianta (bez noveho enumu, jen castejsi TANK/RUNNER):
```python
# uprav jen weights v _pick_spawn_type()
```

Napojeni do spawnu (priklad):
```python
return random.choices(
    [ZombieType.WALKER, ZombieType.RUNNER, ZombieType.TANK, ZombieType.{{NEW_ZOMBIE_ENUM}}],
    weights=[0.34, 0.40, 0.16, 0.10],
    k=1,
)[0]
```

## Nahrad placeholdery
- `{{NEW_ZOMBIE_ENUM}}`: uppercase enum token, napr. `SPITTER`

## Co jeste upravit
- Dopln test, ze novy typ existuje ve spawn population.
- Otestuj kolize/damage v runtime.

## Rychly test
```powershell
python -m pytest -q tests/test_enemy.py
python -m pytest -q tests/test_waves.py
```

## Typicke chyby
- Enum je pridany, ale chybi v `ZOMBIE_STATS` -> KeyError.
- Spawn weights nedavaji smysl (soucty necritical, ale balans je spatny).

## Rollback
- Smaz novy enum token.
- Smaz polozku ze `ZOMBIE_STATS`.
- Vrat spawn list/weights na puvodni stav.

﻿# Maturitni resources balicek (offline manual)

Tento balicek je pripraveny pro rychle upravy u maturity bez AI. Cilem je mit vse na principu:
1) najdi typ pozadavku,
2) otevri spravny template,
3) zkopiruj blok,
4) uprav placeholdery,
5) pust rychly test.

## Rozcestnik podle zadani ucitele

- Pridat novou zbran: `resources/templates/01_add_weapon.md`
- Upravit dmg/cooldown/reload/cenu zbrane: `resources/templates/02_tune_weapon_stats.md`
- Pridat novy skin do shopu: `resources/templates/03_add_skin.md`
- Upravit cenu/barvy skinu: `resources/templates/04_tune_skin_price_color.md`
- Pridat novy typ zombie: `resources/templates/05_add_zombie_type.md`
- Pridat novy typ boss archetypu: `resources/templates/06_add_boss_archetype.md`
- Rychly rebalance zombie/boss statu: `resources/templates/07_tune_zombie_boss_stats.md`
- Upravit wave pacing, mutatory nebo objective: `resources/templates/08_tune_wave_mutator_objective.md`
- Pridat/tunit power-up a drop rates: `resources/templates/09_add_powerup_or_tune_drop.md`
- Rychla zmena textu webu: `resources/templates/10_quick_web_text_change.md`
- Boss gameplay guide pro hrace: `resources/BOSS_HOW_TO.md`

## Mapa projektu (hlavni edit points)

- `game/weapons.py`
  - `WeaponSpec`, `WEAPON_CATALOG`
- `game/enemy.py`
  - `ZombieType`, `BossArchetype`, `ZOMBIE_STATS`, `Zombie.set_boss_archetype`
- `game/waves.py`
  - spawn budget/interval, mutator/objective rotation, boss archetype vyber
- `game/main.py`
  - boss labels/hints, napojeni wave metadata, armory/shop flow
- `game/database.py`
  - `DEFAULT_SKINS`, shop skin flow (`get_shop_skins`, `unlock_skin`, `select_skin`)
- `database/seed.sql`
  - seed data pro skins/weapons
- `web/templates/*.html`
  - texty a prezentacni cast
- `tests/*`
  - cilene testy podle typu upravy

## Rozhodovaci strom

1. Chce ucitel novy typ entity (nova zbran, novy zombie typ, novy boss archetyp, novy skin)?
- Ano: pouzij "add" template (`01`, `03`, `05`, `06`, `09`).
- Ne: pokracuj.

2. Chce ucitel jen zmenu cisel (damage, speed, hp, cena, cooldown, spawn pace)?
- Ano: pouzij "tune" template (`02`, `04`, `07`, `08`, `09`).
- Ne: pokracuj.

3. Chce ucitel jen text na webu/prezentaci?
- Ano: pouzij `10_quick_web_text_change.md`.

## Jednotny postup po kazde uprave

1. Uloz zmeny.
2. Spust cilene testy podle sablony (`resources/QUICK_COMMANDS.md`).
3. Udelej 30-60s smoke-check runtime:
- hra nabehne bez tracebacku,
- menu/armory/shop funguje,
- web route `/leaderboard`, `/login`, `/profil` nabehne.
4. Kdyz je problem, pouzij `Rollback` sekci v konkretni sablone.

## Dulezite poznamky

- Tento balicek nemeni runtime API, je to dokumentacni vrstva.
- Hlavni edit points pro maturitu:
  - `WeaponSpec`
  - `ZombieType`
  - `BossArchetype`
  - `ZOMBIE_STATS`
  - `DEFAULT_SKINS`
- Nazvy klicu v kodu nechavej anglicky (napr. `broodlord`, `auto_rifle`, `survive_timer`).

# Boss How-To Guide

This guide explains how each boss works, how to read telegraphs, and what to do in-game.

## Core telegraphs (all bosses)

- Orange line from boss body: charge windup direction.
  - Counter: move sideways across the line before the charge commits.
- Red landing ring: leap/slam target area.
  - Counter: leave the ring early and keep moving.
- Purple expanding ring: commander cast channel.
  - Counter: focus fire to interrupt the cast before it finishes.

## Warden (heavy control boss)

- Role: high-health anchor with stronger slam pressure.
- Strengths:
  - Tankiest profile.
  - Larger and stronger leap slam impact.
- Weaknesses:
  - Slower movement than other bosses.
  - Easier to kite at medium range.
- Best response:
  - Respect red ring spacing first.
  - Keep distance and punish after commitment windows.

## Ravager (aggressive gap-closer)

- Role: fast tempo boss with frequent charge/leap cycles.
- Strengths:
  - Faster movement.
  - Shorter charge and leap cooldown profile.
- Weaknesses:
  - Lower total health than Warden.
- Best response:
  - Watch orange line constantly.
  - Prioritize side-step discipline over greed damage.

## Broodlord (summoner/control boss)

- Role: summon pressure and battlefield overload.
- Strengths:
  - More frequent commander channels.
  - Extra escort pressure bias.
- Weaknesses:
  - Lower direct damage profile than baseline.
  - Vulnerable to focused interrupt bursts.
- Best response:
  - Save burst damage for purple ring cast windows.
  - Clear escorts quickly to keep movement lanes open.

## Phantom (mobility specialist)

- Role: high-frequency leap pressure with lighter slam hits.
- Strengths:
  - Faster leap cycle and high mobility.
- Weaknesses:
  - Lower health and lower slam damage/radius than other bosses.
- Best response:
  - Track red ring timing and pre-move.
  - Keep routes clear to avoid getting body-blocked by adds.

## Quick survival checklist

- Always keep one escape lane free.
- Do not tunnel damage during windups.
- Reposition first, shoot second.
- If commander cast starts, decide immediately:
  - commit interrupt burst, or
  - fully disengage and prepare for escort spike.

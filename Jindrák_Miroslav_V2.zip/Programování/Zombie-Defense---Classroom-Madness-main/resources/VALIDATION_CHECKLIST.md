﻿# VALIDATION CHECKLIST (5-6 minut)

Pouzij po kazde maturitni uprave.

## 1 minuta: syntakticka kontrola

- [ ] Spusteno:
```powershell
python -m compileall game web
```
- [ ] Bez SyntaxError / traceback.

## 3 minuty: funkcni kontrola hry

- [ ] Hra se spusti (`python game/main.py`).
- [ ] Main menu funguje.
- [ ] Armory/shop otevritelne bez padu.
- [ ] Kdyz jsi menil zbrane/zombie/bosse:
  - [ ] Lze vystrelit,
  - [ ] zombie se spawnuji,
  - [ ] wave pokracuje.
- [ ] Kdyz jsi menil skiny:
  - [ ] skin je videt v Shop,
  - [ ] jde vybrat/odemknout,
  - [ ] player barvy odpovidaji.

## 2 minuty: web kontrola

- [ ] Spusteno `python -m web.backend_app`.
- [ ] Otevreno `/leaderboard` bez chyby.
- [ ] Otevreno `/login` bez chyby.
- [ ] Otevreno `/profil` (nebo redirect na login) bez chyby.

## Fail-safe pred odevzdanim

Kdyz se neco rozbije tesne pred obhajobou:

1. Vrat jen posledni risky blok (z template sekce Rollback).
2. Spust minimalni test jen pro dotcenou oblast:
- weapon -> `tests/test_weapons.py`
- enemy/wave -> `tests/test_enemy.py` + `tests/test_waves.py`
- db/skin -> `tests/test_database.py`
- web -> `tests/test_web_pages.py`
3. Kdyz stale problem:
- nech safe variantu (jen numeric tuning),
- nedelaj full variantu (novy enum/novy flow).
4. Udrz stabilni build pred "hezkou" upravou.

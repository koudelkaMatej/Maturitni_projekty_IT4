﻿# QUICK COMMANDS (maturita)

Prikazy spoustej z rootu projektu:

`d:\ŠKOLA a TISK\Programování\Zombie-Defense---Classroom-Madness-main`

## 1) Zbrane

- Testy zbrani:
```powershell
python -m pytest -q tests/test_weapons.py
```

- Gameplay progres navazany na armory/zbrane:
```powershell
python -m pytest -q tests/test_main_progression.py -k "weapon or armory"
```

- Kde se pouziva konkretni weapon key:
```powershell
rg -n "auto_rifle|burst_rifle|shotgun|sniper|pistol" game tests
```

## 2) Zombie + Boss

- Enemy testy:
```powershell
python -m pytest -q tests/test_enemy.py
```

- Wave logika:
```powershell
python -m pytest -q tests/test_waves.py
```

- Boss flow v main progresu:
```powershell
python -m pytest -q tests/test_main_progression.py -k "boss"
```

- Kde se pouziva boss archetype string:
```powershell
rg -n "warden|ravager|broodlord|boss_archetype" game tests
```

## 3) Skins + DB

- Databaze testy:
```powershell
python -m pytest -q tests/test_database.py
```

- Rychle hledani skin flow:
```powershell
rg -n "DEFAULT_SKINS|skins|player_skins|unlock_skin|select_skin|get_shop_skins" game database tests
```

- Kdyz menis seed data:
```powershell
rg -n "INSERT INTO skins|INSERT OR IGNORE INTO player_skins" database/seed.sql
```

## 4) Web texty

- Zakladni web testy:
```powershell
python -m pytest -q tests/test_web_pages.py
```

- Auth testy (kdyz menis login/register texty nebo flow):
```powershell
python -m pytest -q tests/test_web_auth.py
```

- Hledani textu v sablonach:
```powershell
rg -n "Leaderboard|Registrace|Profil|Login|diagramy|o-hre|o-nas" web/templates
```

## 5) Rychly smoke check (manual)

- Spust hru:
```powershell
python game/main.py
```

- Spust web:
```powershell
python -m web.backend_app
```

- Otevri:
- `http://127.0.0.1:5000/`
- `http://127.0.0.1:5000/leaderboard`
- `http://127.0.0.1:5000/login`
- `http://127.0.0.1:5000/profil`

## 6) Rychla syntakticka kontrola (1 min)

```powershell
python -m compileall game web
```

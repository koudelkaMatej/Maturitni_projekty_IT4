@echo off
setlocal

set "ROOT=%~dp0"
cd /d "%ROOT%"

set "SCHOOL_PYTHON=G:\win32app\Portable Python-3.13.3 x64\python.exe"

echo [INFO] School PC setup started...

if exist "%ROOT%venv\Scripts\python.exe" (
  echo [INFO] Existing venv found at "%ROOT%venv".
) else (
  if not exist "%SCHOOL_PYTHON%" (
    echo [ERROR] School Python was not found:
    echo        %SCHOOL_PYTHON%
    echo [HINT] Check that G: drive is mounted and path is valid.
    pause
    exit /b 1
  )

  echo [INFO] Creating venv from school Python...
  "%SCHOOL_PYTHON%" -m venv venv
  if errorlevel 1 (
    echo [ERROR] venv creation failed.
    pause
    exit /b 1
  )
)

echo [INFO] Applying PowerShell execution policy for current user...
powershell -NoProfile -ExecutionPolicy Bypass -Command "Set-ExecutionPolicy -Scope CurrentUser -ExecutionPolicy RemoteSigned -Force"
if errorlevel 1 (
  echo [WARN] Could not set execution policy automatically.
  echo [WARN] If needed, run this manually in PowerShell:
  echo        Set-ExecutionPolicy -Scope CurrentUser -ExecutionPolicy RemoteSigned
)

echo [INFO] Activating venv in this shell...
call "%ROOT%venv\Scripts\activate.bat"
if errorlevel 1 (
  echo [ERROR] venv activation failed.
  pause
  exit /b 1
)

echo [OK] School PC setup is ready.
exit /b 0

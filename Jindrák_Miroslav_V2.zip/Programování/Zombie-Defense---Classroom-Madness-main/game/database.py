﻿"""SQLite persistence layer used by game runtime and web integration."""

from __future__ import annotations

import sqlite3
from datetime import datetime
from pathlib import Path

from werkzeug.security import check_password_hash, generate_password_hash

BASE_DIR = Path(__file__).resolve().parent.parent
DB_PATH = BASE_DIR / "database" / "game.db"
SCHEMA_PATH = BASE_DIR / "database" / "schema.sql"

DEFAULT_SKINS: list[tuple[str, str, int, str, str, int]] = [
    # Seeded cosmetics are idempotent and safe to upsert on every startup.
    ("classic", "Classic", 0, "70,160,255", "220,240,255", 1),
    ("ember", "Ember", 120, "255,145,80", "255,220,180", 0),
    ("toxic", "Toxic", 180, "90,230,120", "210,255,220", 0),
    ("frost", "Frost", 260, "110,180,255", "220,245,255", 0),
]


def get_connection(db_path: Path | None = None) -> sqlite3.Connection:
    """Create SQLite connection with row dict-like access enabled."""
    db_path = db_path or DB_PATH
    # Ensure database directory exists before opening SQLite file.
    db_path.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(db_path)
    # Row factory allows dict-like column access in call sites.
    conn.row_factory = sqlite3.Row
    # Foreign keys are off by default in SQLite, so enforce them explicitly.
    conn.execute("PRAGMA foreign_keys = ON")
    return conn


def _table_columns(conn: sqlite3.Connection, table_name: str) -> set[str]:
    """Return a set of column names for the selected table."""
    # PRAGMA table_info is used for lightweight schema introspection.
    rows = conn.execute(f"PRAGMA table_info({table_name})").fetchall()
    return {str(row["name"]) for row in rows}


def _ensure_schema_extensions(conn: sqlite3.Connection) -> None:
    """Apply additive migrations for older DB files."""
    # Migrations are additive-only so old classroom DB files keep working.
    player_columns = _table_columns(conn, "players")
    if "email" not in player_columns:
        conn.execute("ALTER TABLE players ADD COLUMN email TEXT")
    if "coins" not in player_columns:
        conn.execute("ALTER TABLE players ADD COLUMN coins INTEGER NOT NULL DEFAULT 0")

    conn.executescript(
        """
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            player_id INTEGER NOT NULL UNIQUE,
            username TEXT NOT NULL UNIQUE,
            password_hash TEXT NOT NULL,
            created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (player_id) REFERENCES players(id) ON DELETE CASCADE
        );

        CREATE TABLE IF NOT EXISTS skins (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            skin_key TEXT NOT NULL UNIQUE,
            display_name TEXT NOT NULL,
            price_coins INTEGER NOT NULL DEFAULT 0,
            primary_color TEXT NOT NULL,
            secondary_color TEXT NOT NULL,
            is_default INTEGER NOT NULL DEFAULT 0
        );

        CREATE TABLE IF NOT EXISTS player_skins (
            player_id INTEGER NOT NULL,
            skin_id INTEGER NOT NULL,
            unlocked_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
            is_selected INTEGER NOT NULL DEFAULT 0,
            PRIMARY KEY (player_id, skin_id),
            FOREIGN KEY (player_id) REFERENCES players(id) ON DELETE CASCADE,
            FOREIGN KEY (skin_id) REFERENCES skins(id) ON DELETE CASCADE
        );
        """
    )

    # Seed base skin catalog entries when missing.
    conn.executemany(
        """
        INSERT INTO skins (skin_key, display_name, price_coins, primary_color, secondary_color, is_default)
        VALUES (?, ?, ?, ?, ?, ?)
        ON CONFLICT(skin_key) DO NOTHING
        """,
        DEFAULT_SKINS,
    )

    player_ids = [int(row["id"]) for row in conn.execute("SELECT id FROM players").fetchall()]
    # Backfill default ownership for pre-skin players.
    for player_id in player_ids:
        _ensure_player_default_skin(conn, player_id)


def init_db(db_path: Path | None = None, schema_path: Path = SCHEMA_PATH) -> None:
    """Initialize DB schema from file and apply runtime-safe migrations."""
    with get_connection(db_path or DB_PATH) as conn:
        if schema_path.exists():
            # Preferred path: execute maintained SQL schema file.
            conn.executescript(schema_path.read_text(encoding="utf-8"))
        else:
            # Fallback path keeps game bootable if schema.sql is unavailable.
            conn.executescript(
                """
                CREATE TABLE IF NOT EXISTS players (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    name TEXT NOT NULL UNIQUE,
                    email TEXT UNIQUE,
                    coins INTEGER NOT NULL DEFAULT 0,
                    registered_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
                );

                CREATE TABLE IF NOT EXISTS matches (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    player_id INTEGER NOT NULL,
                    score INTEGER NOT NULL DEFAULT 0,
                    match_date TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
                    duration_seconds REAL NOT NULL DEFAULT 0,
                    FOREIGN KEY(player_id) REFERENCES players(id)
                );
                """
            )

        _ensure_schema_extensions(conn)


def _parse_color(color_text: str, fallback: tuple[int, int, int]) -> tuple[int, int, int]:
    """Parse RGB text payload and fall back when invalid."""
    try:
        # Stored color format is "r,g,b".
        parts = [int(part.strip()) for part in color_text.split(",")]
        if len(parts) == 3:
            return parts[0], parts[1], parts[2]
    except (ValueError, AttributeError):
        pass
    return fallback


def _get_default_skin_id(conn: sqlite3.Connection) -> int:
    """Return default skin id, creating the skin when missing."""
    # Prefer already marked default to avoid duplicate inserts.
    row = conn.execute(
        "SELECT id FROM skins WHERE is_default = 1 ORDER BY id LIMIT 1"
    ).fetchone()
    if row:
        return int(row["id"])

    conn.execute(
        """
        INSERT INTO skins (skin_key, display_name, price_coins, primary_color, secondary_color, is_default)
        VALUES (?, ?, ?, ?, ?, 1)
        """,
        ("classic", "Classic", 0, "70,160,255", "220,240,255"),
    )
    return int(
        conn.execute("SELECT id FROM skins WHERE skin_key = 'classic'").fetchone()["id"]
    )


def _ensure_player_default_skin(conn: sqlite3.Connection, player_id: int) -> None:
    """Ensure player owns and selects at least one default skin."""
    default_skin_id = _get_default_skin_id(conn)
    # Ownership insert is idempotent via OR IGNORE.
    conn.execute(
        """
        INSERT OR IGNORE INTO player_skins (player_id, skin_id, is_selected)
        VALUES (?, ?, 0)
        """,
        (player_id, default_skin_id),
    )

    has_selected = conn.execute(
        "SELECT 1 FROM player_skins WHERE player_id = ? AND is_selected = 1 LIMIT 1",
        (player_id,),
    ).fetchone()
    if not has_selected:
        # Guarantee exactly one selected skin when profile has none selected.
        conn.execute("UPDATE player_skins SET is_selected = 0 WHERE player_id = ?", (player_id,))
        conn.execute(
            "UPDATE player_skins SET is_selected = 1 WHERE player_id = ? AND skin_id = ?",
            (player_id, default_skin_id),
        )


def _upsert_player(conn: sqlite3.Connection, clean_name: str, email: str | None = None) -> int:
    """Insert or update player record and return player id."""
    # Name remains unique key; email only updates when new email is provided.
    conn.execute(
        """
        INSERT INTO players(name, email)
        VALUES (?, ?)
        ON CONFLICT(name) DO UPDATE SET email = COALESCE(excluded.email, players.email)
        """,
        (clean_name, email.strip() if email else None),
    )
    row = conn.execute("SELECT id FROM players WHERE name = ?", (clean_name,)).fetchone()
    player_id = int(row["id"])
    # Backfill skin ownership for newly created or migrated users.
    _ensure_player_default_skin(conn, player_id)
    return player_id


def save_match_result(
    player_name: str,
    score: int,
    duration_seconds: float,
    db_path: Path | None = None,
) -> None:
    """Insert player if needed and save one match row."""
    # Empty names are normalized so leaderboard rows are always printable.
    cleaned_name = player_name.strip() or "Hrac"
    match_date = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    with get_connection(db_path) as conn:
        player_id = _upsert_player(conn, cleaned_name)
        conn.execute(
            """
            INSERT INTO matches(player_id, score, match_date, duration_seconds)
            VALUES (?, ?, ?, ?)
            """,
            (player_id, int(score), match_date, float(duration_seconds)),
        )


def get_leaderboard(limit: int = 5, db_path: Path | None = None) -> list[dict[str, str | int | float]]:
    """Return leaderboard rows sorted by score and date."""
    with get_connection(db_path) as conn:
        rows = conn.execute(
            """
            SELECT p.name AS jmeno, m.score AS skore, m.match_date AS datum, m.duration_seconds AS doba
            FROM matches m
            JOIN players p ON p.id = m.player_id
            ORDER BY m.score DESC, m.match_date DESC
            LIMIT ?
            """,
            (limit,),
        ).fetchall()

    return [dict(row) for row in rows]


def register_player(name: str, email: str | None = None, db_path: Path | None = None) -> int:
    """Register player account (or update email) and return player id."""
    clean_name = name.strip()
    if not clean_name:
        raise ValueError("Player name cannot be empty.")

    with get_connection(db_path) as conn:
        return _upsert_player(conn, clean_name, email)


def get_player_profile(name: str, db_path: Path | None = None) -> dict[str, str | int]:
    """Return profile data, creating player if needed."""
    clean_name = name.strip() or "Hrac"
    with get_connection(db_path) as conn:
        player_id = _upsert_player(conn, clean_name)
        row = conn.execute(
            "SELECT id, name, coins FROM players WHERE id = ?",
            (player_id,),
        ).fetchone()

    return {"id": int(row["id"]), "name": str(row["name"]), "coins": int(row["coins"])}


def add_player_coins(player_id: int, amount: int, db_path: Path | None = None) -> int:
    """Add positive or negative amount to coins and return new balance."""
    with get_connection(db_path) as conn:
        conn.execute(
            "UPDATE players SET coins = MAX(0, coins + ?) WHERE id = ?",
            (int(amount), int(player_id)),
        )
        row = conn.execute("SELECT coins FROM players WHERE id = ?", (int(player_id),)).fetchone()
        if row is None:
            raise ValueError("Player not found.")
        return int(row["coins"])


def get_shop_skins(player_id: int, db_path: Path | None = None) -> list[dict[str, object]]:
    """Return all skins with ownership and selection flags for one player."""
    with get_connection(db_path) as conn:
        # Left join keeps unowned skins in result for shop display.
        rows = conn.execute(
            """
            SELECT
                s.skin_key,
                s.display_name,
                s.price_coins,
                s.primary_color,
                s.secondary_color,
                CASE WHEN ps.player_id IS NULL THEN 0 ELSE 1 END AS owned,
                COALESCE(ps.is_selected, 0) AS selected,
                s.is_default
            FROM skins s
            LEFT JOIN player_skins ps
                ON ps.skin_id = s.id
                AND ps.player_id = ?
            ORDER BY s.price_coins ASC, s.id ASC
            """,
            (int(player_id),),
        ).fetchall()

    items: list[dict[str, object]] = []
    for row in rows:
        # Convert SQL scalars into UI-friendly Python types.
        items.append(
            {
                "skin_key": row["skin_key"],
                "display_name": row["display_name"],
                "price_coins": int(row["price_coins"]),
                "primary_color": _parse_color(str(row["primary_color"]), (70, 160, 255)),
                "secondary_color": _parse_color(str(row["secondary_color"]), (220, 240, 255)),
                "owned": bool(row["owned"]),
                "selected": bool(row["selected"]),
                "is_default": bool(row["is_default"]),
            }
        )
    return items


def _set_selected_skin(conn: sqlite3.Connection, player_id: int, skin_id: int) -> None:
    """Mark one skin as selected for the player profile."""
    conn.execute("UPDATE player_skins SET is_selected = 0 WHERE player_id = ?", (int(player_id),))
    conn.execute(
        "UPDATE player_skins SET is_selected = 1 WHERE player_id = ? AND skin_id = ?",
        (int(player_id), int(skin_id)),
    )


def unlock_skin(player_id: int, skin_key: str, db_path: Path | None = None) -> tuple[bool, str]:
    """Attempt to buy and select a skin. Returns (success, status)."""
    with get_connection(db_path) as conn:
        skin_row = conn.execute(
            "SELECT id, price_coins FROM skins WHERE skin_key = ?",
            (skin_key,),
        ).fetchone()
        if skin_row is None:
            return False, "skin_not_found"

        skin_id = int(skin_row["id"])
        price = int(skin_row["price_coins"])

        owned = conn.execute(
            "SELECT 1 FROM player_skins WHERE player_id = ? AND skin_id = ?",
            (int(player_id), skin_id),
        ).fetchone()
        if owned:
            # Re-select already owned skin without charging coins again.
            _set_selected_skin(conn, int(player_id), skin_id)
            return True, "already_owned"

        coins_row = conn.execute(
            "SELECT coins FROM players WHERE id = ?",
            (int(player_id),),
        ).fetchone()
        if coins_row is None:
            return False, "player_not_found"

        if int(coins_row["coins"]) < price:
            return False, "insufficient_coins"

        # Spend currency and unlock/select in one transaction scope.
        conn.execute(
            "UPDATE players SET coins = coins - ? WHERE id = ?",
            (price, int(player_id)),
        )
        conn.execute(
            """
            INSERT OR IGNORE INTO player_skins (player_id, skin_id, is_selected)
            VALUES (?, ?, 0)
            """,
            (int(player_id), skin_id),
        )
        _set_selected_skin(conn, int(player_id), skin_id)
        return True, "unlocked"


def select_skin(player_id: int, skin_key: str, db_path: Path | None = None) -> bool:
    """Set an owned skin as selected. Returns True when successful."""
    with get_connection(db_path) as conn:
        row = conn.execute(
            """
            SELECT s.id
            FROM skins s
            JOIN player_skins ps ON ps.skin_id = s.id
            WHERE ps.player_id = ? AND s.skin_key = ?
            """,
            (int(player_id), skin_key),
        ).fetchone()
        if row is None:
            return False

        _set_selected_skin(conn, int(player_id), int(row["id"]))
        return True


def get_selected_skin(player_id: int, db_path: Path | None = None) -> dict[str, object]:
    """Return selected skin for player (or default fallback)."""
    with get_connection(db_path) as conn:
        row = conn.execute(
            """
            SELECT s.skin_key, s.display_name, s.primary_color, s.secondary_color
            FROM skins s
            JOIN player_skins ps ON ps.skin_id = s.id
            WHERE ps.player_id = ? AND ps.is_selected = 1
            LIMIT 1
            """,
            (int(player_id),),
        ).fetchone()

        if row is None:
            # Recover invalid profile state by forcing default selection.
            _ensure_player_default_skin(conn, int(player_id))
            row = conn.execute(
                """
                SELECT s.skin_key, s.display_name, s.primary_color, s.secondary_color
                FROM skins s
                JOIN player_skins ps ON ps.skin_id = s.id
                WHERE ps.player_id = ? AND ps.is_selected = 1
                LIMIT 1
                """,
                (int(player_id),),
            ).fetchone()

    if row is None:
        return {
            "skin_key": "classic",
            "display_name": "Classic",
            "primary_color": (70, 160, 255),
            "secondary_color": (220, 240, 255),
        }

    return {
        "skin_key": row["skin_key"],
        "display_name": row["display_name"],
        "primary_color": _parse_color(str(row["primary_color"]), (70, 160, 255)),
        "secondary_color": _parse_color(str(row["secondary_color"]), (220, 240, 255)),
    }


def create_web_user(
    username: str,
    password: str,
    email: str | None = None,
    db_path: Path | None = None,
) -> int:
    """Create web account bound to a player profile; returns user id."""
    clean_username = username.strip()
    if not clean_username:
        raise ValueError("Username cannot be empty.")
    if not password:
        raise ValueError("Password cannot be empty.")

    with get_connection(db_path) as conn:
        # Reserve username globally across all player profiles.
        duplicate = conn.execute(
            "SELECT id FROM users WHERE username = ?",
            (clean_username,),
        ).fetchone()
        if duplicate is not None:
            raise ValueError("Username is already taken.")

        player_id = _upsert_player(conn, clean_username, email)
        # Password is never stored in plain text.
        password_hash = generate_password_hash(password)
        conn.execute(
            """
            INSERT INTO users(player_id, username, password_hash)
            VALUES (?, ?, ?)
            """,
            (player_id, clean_username, password_hash),
        )
        row = conn.execute(
            "SELECT id FROM users WHERE username = ?",
            (clean_username,),
        ).fetchone()
        return int(row["id"])


def authenticate_web_user(
    username: str,
    password: str,
    db_path: Path | None = None,
) -> dict[str, str | int] | None:
    """Validate username/password and return session payload when valid."""
    clean_username = username.strip()
    if not clean_username or not password:
        return None

    with get_connection(db_path) as conn:
        row = conn.execute(
            """
            SELECT
                u.id AS user_id,
                u.player_id,
                u.username,
                u.password_hash,
                p.name AS player_name,
                p.email AS player_email
            FROM users u
            JOIN players p ON p.id = u.player_id
            WHERE u.username = ?
            LIMIT 1
            """,
            (clean_username,),
        ).fetchone()

    if row is None:
        return None
    # Hash verification guards against timing and plain-text leakage risks.
    if not check_password_hash(str(row["password_hash"]), password):
        return None

    return {
        "user_id": int(row["user_id"]),
        "player_id": int(row["player_id"]),
        "username": str(row["username"]),
        "player_name": str(row["player_name"]),
        "player_email": str(row["player_email"]) if row["player_email"] else "",
    }


def get_player_matches(player_id: int, limit: int = 20, db_path: Path | None = None) -> list[dict[str, str | int | float]]:
    """Return recent matches for one player."""
    with get_connection(db_path) as conn:
        # Most recent-first ordering powers profile history view.
        rows = conn.execute(
            """
            SELECT
                m.score AS skore,
                m.match_date AS datum,
                m.duration_seconds AS doba
            FROM matches m
            WHERE m.player_id = ?
            ORDER BY m.match_date DESC, m.score DESC
            LIMIT ?
            """,
            (int(player_id), int(limit)),
        ).fetchall()
    return [dict(row) for row in rows]

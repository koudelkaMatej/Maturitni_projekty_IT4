"""Main game loop and state manager for Zombie Defense."""

from __future__ import annotations

import sys
import random
from enum import Enum, auto

import pygame

try:
    from . import database, settings, storage
    from .audio import AudioManager
    from .camera import Camera
    from .enemy import (
        BossArchetype,
        ROLE_CHASE,
        ROLE_CUTTER_LEFT,
        ROLE_CUTTER_RIGHT,
        ROLE_FLANK_LEFT,
        ROLE_FLANK_RIGHT,
        Zombie,
        ZombieType,
    )
    from .lighting import apply_cone_visibility_mask, get_flashlight_cone_points, render_darkness_overlay
    from .player import Player
    from .powerups import PowerUpManager, PowerUpType
    from .projectile import Projectile
    from .ui import (
        draw_game_over,
        draw_hud,
        draw_howto_screen,
        draw_menu,
        draw_visual_mode_select,
        draw_login_input,
        draw_perk_draft_overlay,
        draw_armory_overlay,
        draw_mutation_drawer,
        draw_pause_overlay,
        draw_shop,
        draw_wave_banner,
        get_armory_button_rect,
        get_mutation_button_rect,
        get_menu_option_rects,
        get_visual_mode_option_rects,
        get_armory_row_rect,
        get_armory_tab_rects,
        get_howto_category_rects,
        get_pause_main_option_rects,
        get_pause_settings_option_rects,
        get_perk_card_rects,
    )
    from .weapons import ProjectileSpawn, WeaponInventory
    from .waves import WaveManager
except ImportError:  # pragma: no cover - supports running via `python game/main.py`
    from pathlib import Path

    current_dir = Path(__file__).resolve().parent
    if str(current_dir) not in sys.path:
        sys.path.insert(0, str(current_dir))

    import database
    import settings
    import storage
    from audio import AudioManager
    from camera import Camera
    from enemy import (
        BossArchetype,
        ROLE_CHASE,
        ROLE_CUTTER_LEFT,
        ROLE_CUTTER_RIGHT,
        ROLE_FLANK_LEFT,
        ROLE_FLANK_RIGHT,
        Zombie,
        ZombieType,
    )
    from lighting import apply_cone_visibility_mask, get_flashlight_cone_points, render_darkness_overlay
    from player import Player
    from powerups import PowerUpManager, PowerUpType
    from projectile import Projectile
    from ui import (
        draw_game_over,
        draw_hud,
        draw_howto_screen,
        draw_menu,
        draw_visual_mode_select,
        draw_login_input,
        draw_perk_draft_overlay,
        draw_armory_overlay,
        draw_mutation_drawer,
        draw_pause_overlay,
        draw_shop,
        draw_wave_banner,
        get_armory_button_rect,
        get_mutation_button_rect,
        get_menu_option_rects,
        get_visual_mode_option_rects,
        get_armory_row_rect,
        get_armory_tab_rects,
        get_howto_category_rects,
        get_pause_main_option_rects,
        get_pause_settings_option_rects,
        get_perk_card_rects,
    )
    from weapons import ProjectileSpawn, WeaponInventory
    from waves import WaveManager


class GameState(Enum):
    """High-level game screens/states."""

    MENU = auto()
    VISUAL_MODE_SELECT = auto()
    SHOP = auto()
    LOGIN = auto()
    PLAYING = auto()
    GUIDE = auto()
    GAME_OVER = auto()


RUN_PERK_DEFINITIONS: dict[str, dict[str, object]] = {
    "sharpshooter": {
        "name": "Sharpshooter",
        "description": "+15% projectile damage",
        "effects": {"damage_mult": 1.15},
    },
    "fast_hands": {
        "name": "Fast Hands",
        "description": "-20% reload time",
        "effects": {"reload_mult": 0.80},
    },
    "adrenaline": {
        "name": "Adrenaline",
        "description": "+8% movement speed",
        "effects": {"move_mult": 1.08},
    },
    "scavenger": {
        "name": "Scavenger",
        "description": "+12% scrap gains",
        "effects": {"scrap_mult": 1.12},
    },
    "overclock": {
        "name": "Overclock",
        "description": "-12% weapon cooldown",
        "effects": {"cooldown_mult": 0.88},
    },
    "hollow_points": {
        "name": "Hollow Points",
        "description": "+20% critical chance",
        "effects": {"crit_chance_add": 0.20},
    },
    "deadeye": {
        "name": "Deadeye",
        "description": "+35% critical damage bonus",
        "effects": {"crit_damage_add": 0.35},
    },
    "bloodlust": {
        "name": "Bloodlust",
        "description": "0.25% lifesteal from projectile damage (capped at 0.50 HP/sec)",
        "effects": {"lifesteal_add": 0.0025},
    },
    "plated_vest": {
        "name": "Plated Vest",
        "description": "-12% incoming damage",
        "effects": {"incoming_mult": 0.88},
    },
    "ammo_smith": {
        "name": "Ammo Smith",
        "description": "+18% ammo preserve chance",
        "effects": {"ammo_preserve_add": 0.18},
    },
    "kinetic_rounds": {
        "name": "Kinetic Rounds",
        "description": "+20% projectile travel speed (damage unchanged)",
        "effects": {"projectile_speed_mult": 1.20},
    },
    "power_hunter": {
        "name": "Power Hunter",
        "description": "+12% power-up drop rate",
        "effects": {"powerup_drop_mult": 1.12},
    },
    "quick_recovery": {
        "name": "Quick Recovery",
        "description": "+10 max HP and heal 15 HP",
        "effects": {"max_health_add": 10, "heal_add": 15},
    },
    "berserker": {
        "name": "Berserker",
        "description": "+30% damage below 40% HP",
        "effects": {"low_hp_damage_mult": 1.30},
    },
    "sprinter": {
        "name": "Sprinter",
        "description": "+12% move speed, +6% incoming damage",
        "effects": {"move_mult": 1.12, "incoming_mult": 1.06},
    },
    "last_stand": {
        "name": "Last Stand",
        "description": "One fatal hit per wave leaves you at 20 HP",
        "effects": {"last_stand_enable": True},
    },
    "field_engineer": {
        "name": "Field Engineer",
        "description": "+10% scrap gains, and Ammo Cache gives +25% more scrap when no ammo refill is needed",
        "effects": {"scrap_mult": 1.10, "ammo_cache_scrap_mult": 1.25},
    },
    "glass_cannon": {
        "name": "Execution Protocol",
        "description": "+14% projectile damage, +8% incoming damage",
        "effects": {"damage_mult": 1.14, "incoming_mult": 1.08},
    },
    "combat_medic": {
        "name": "Guardian Protocol",
        "description": "+16 max HP, heal 8 HP, and -6% incoming damage",
        "effects": {"max_health_add": 16, "heal_add": 8, "incoming_mult": 0.94},
    },
    "shock_cycle": {
        "name": "Shock Cycle",
        "description": "-8% weapon cooldown, -5% reload time",
        "effects": {"cooldown_mult": 0.92, "reload_mult": 0.95},
    },
    "ballistics_expert": {
        "name": "Dead Calibration",
        "description": "+8% critical chance and +18% critical damage bonus",
        "effects": {"crit_chance_add": 0.08, "crit_damage_add": 0.18},
    },
    "fleet_footed": {
        "name": "Resource Runner",
        "description": "+6% movement speed, +8% scrap gains, +8% power-up drop rate",
        "effects": {"move_mult": 1.06, "scrap_mult": 1.08, "powerup_drop_mult": 1.08},
    },
    "fortress_plating": {
        "name": "Fortress Plating",
        "description": "-15% incoming damage, -5% movement speed",
        "effects": {"incoming_mult": 0.85, "move_mult": 0.95},
    },
    "lucky_salvage": {
        "name": "Lucky Salvage",
        "description": "+6% scrap gains, and Ammo Cache gives +8% more scrap when no ammo refill is needed",
        "effects": {"scrap_mult": 1.06, "ammo_cache_scrap_mult": 1.08},
    },
    "vampiric_rounds": {
        "name": "Sanguine Divine",
        "description": "+0.10% lifesteal and raises lifesteal cap to 0.75 HP/sec",
        "effects": {"lifesteal_add": 0.0010, "lifesteal_cap_set": 0.75},
    },
    "pinpoint": {
        "name": "Pinpoint",
        "description": "+12% critical chance, +8% ammo preserve chance",
        "effects": {"crit_chance_add": 0.12, "ammo_preserve_add": 0.08},
    },
    "suppressive_fire": {
        "name": "Bullet Economy",
        "description": "-4% weapon cooldown and +14% ammo preserve chance",
        "effects": {"cooldown_mult": 0.96, "ammo_preserve_add": 0.14},
    },
    "ap_rounds": {
        "name": "AP Rounds",
        "description": "+8% projectile damage, +10% projectile speed",
        "effects": {"damage_mult": 1.08, "projectile_speed_mult": 1.10},
    },
}

ARMORY_UPGRADE_DEFINITIONS: dict[str, dict[str, object]] = {
    "reinforced_armor": {
        "name": "Reinforced Armor",
        "detail": "+15 Max HP / tier",
        "costs": [180, 320, 520],
        "effects": {"max_health_add": 15},
    },
    "combat_stims": {
        "name": "Combat Stims",
        "detail": "+2% Move Speed / tier",
        "costs": [200, 360, 580],
        "effects": {"move_mult": 1.02},
    },
    "targeting_rig": {
        "name": "Targeting Rig",
        "detail": "+10% Damage / tier",
        "costs": [240, 420, 670],
        "effects": {"damage_mult": 1.10},
    },
    "rapid_cycle": {
        "name": "Rapid Cycle",
        "detail": "-10% Reload Time / tier",
        "costs": [240, 420, 670],
        "effects": {"reload_mult": 0.90},
    },
    "trigger_tuning": {
        "name": "Trigger Tuning",
        "detail": "-8% Weapon Cooldown / tier",
        "costs": [260, 450, 720],
        "effects": {"cooldown_mult": 0.92},
    },
    "critical_lens": {
        "name": "Critical Lens",
        "detail": "+8% Crit Chance / tier",
        "costs": [220, 390, 620],
        "effects": {"crit_chance_add": 0.08},
    },
    "lucky_chamber": {
        "name": "Lucky Chamber",
        "detail": "+10% Ammo Preserve / tier",
        "costs": [200, 360, 580],
        "effects": {"ammo_preserve_add": 0.10},
    },
    "fortune_extractor": {
        "name": "Fortune Extractor",
        "detail": "+8% Scrap Gain / tier",
        "costs": [220, 390, 620],
        "effects": {"scrap_mult": 1.08},
    },
}

MUTATOR_DEFINITIONS: dict[str, dict[str, object]] = {
    "swarm_protocol": {
        "name": "Swarm Protocol",
        "hud": "Mutator: Swarm Protocol (+horde count, faster spawns)",
        "zombie_speed_mult": 1.08,
        "zombie_health_mult": 0.92,
        "zombie_damage_mult": 0.96,
        "elite_bonus": 0.08,
        "powerup_drop_mult": 1.0,
    },
    "fortified_horde": {
        "name": "Fortified Horde",
        "hud": "Mutator: Fortified Horde (heavier zombies)",
        "zombie_speed_mult": 0.96,
        "zombie_health_mult": 1.35,
        "zombie_damage_mult": 1.14,
        "elite_bonus": 0.12,
        "powerup_drop_mult": 1.0,
    },
    "hunter_pack": {
        "name": "Hunter Pack",
        "hud": "Mutator: Hunter Pack (aggressive pursuit)",
        "zombie_speed_mult": 1.20,
        "zombie_health_mult": 1.0,
        "zombie_damage_mult": 1.05,
        "elite_bonus": 0.10,
        "powerup_drop_mult": 1.05,
    },
    "nightmare_fog": {
        "name": "Nightmare Fog",
        "hud": "Mutator: Nightmare Fog (low visibility pressure)",
        "zombie_speed_mult": 1.05,
        "zombie_health_mult": 1.12,
        "zombie_damage_mult": 1.00,
        "elite_bonus": 0.10,
        "powerup_drop_mult": 1.0,
    },
    "scarcity_protocol": {
        "name": "Scarcity Protocol",
        "hud": "Mutator: Scarcity Protocol (lean resources)",
        "zombie_speed_mult": 1.10,
        "zombie_health_mult": 1.04,
        "zombie_damage_mult": 1.08,
        "elite_bonus": 0.12,
        "powerup_drop_mult": 0.82,
    },
}

OBJECTIVE_DEFINITIONS: dict[str, dict[str, str]] = {
    "survive_timer": {
        "name": "Survive Timer",
        "short": "Survive",
    },
    "kill_quota": {
        "name": "Kill Quota",
        "short": "Quota",
    },
    "no_hit_window": {
        "name": "No-Hit Window",
        "short": "No-Hit",
    },
    "elite_hunt": {
        "name": "Elite Hunt",
        "short": "Elite Hunt",
    },
    "ammo_discipline": {
        "name": "Ammo Discipline",
        "short": "Ammo Discipline",
    },
}

VISUAL_MODE_ORDER = ("night", "day", "blackout")
ARMORY_VISIBLE_ROWS = 7
TACTICAL_SLING_UNLOCK_WAVE = 8
TACTICAL_SLING_COST = 950
# Combat pacing and boss encounter tuning.
BOSS_ESCORT_BASE_COUNT = 2
NO_HIT_STREAK_THRESHOLD = 16.0
WAVE_TWIST_COOLDOWN = 3
WAVE_TWIST_KEYS = ("ammo_cache_denial", "elite_surge", "safe_zone_pulse")
LIFESTEAL_HEAL_CAP_PER_SECOND = 0.50
BOSS_LEAP_CORE_RATIO = 0.55
BOSS_LEAP_DODGE_MIN_COMMIT_DISTANCE = 80.0
BOSS_LEAP_DODGE_MIN_LATERAL_DISTANCE = 52.0
BOSS_LEAP_DODGE_MIN_PLAYER_SPEED = 145.0
BOSS_AMBUSH_CONTACT_LOCKOUT = 0.25

BOSS_ARCHETYPE_LABELS: dict[str, str] = {
    BossArchetype.WARDEN.value: "Warden",
    BossArchetype.RAVAGER.value: "Ravager",
    BossArchetype.BROODLORD.value: "Broodlord",
    BossArchetype.PHANTOM.value: "Phantom",
    BossArchetype.ZONE_CASTER.value: "Zone Caster",
    BossArchetype.STEALTH_ASSASSIN.value: "Stealth Assassin",
}

BOSS_COUNTER_HINTS: dict[str, str] = {
    BossArchetype.WARDEN.value: "Boss Tip: Warden slam is heavy. Keep outside landing ring.",
    BossArchetype.RAVAGER.value: "Boss Tip: Ravager charge is lethal. Side-step during windup.",
    BossArchetype.BROODLORD.value: "Boss Tip: Broodlord call can be interrupted by focused fire.",
    BossArchetype.PHANTOM.value: "Boss Tip: Phantom leaps often. Move early when ring appears.",
    BossArchetype.ZONE_CASTER.value: "Boss Tip: Zone Caster marks lanes. Rotate early before zones arm.",
    BossArchetype.STEALTH_ASSASSIN.value: "Boss Tip: Stealth Assassin ambushes in a lane. Side-step line telegraph.",
}

WAVE_TWIST_LABELS: dict[str, str] = {
    "ammo_cache_denial": "Ammo Cache Denial",
    "elite_surge": "Elite Surge",
    "safe_zone_pulse": "Safe-Zone Pulse",
}

GUIDE_SECTION_TITLES: tuple[str, ...] = (
    "Basics & Goal",
    "Controls & HUD",
    "Enemies & Bosses",
    "Weapons & Ammo",
    "Power-Ups",
    "Progression & Economy",
)
GUIDE_BOSS_SECTION_INDEX = 2


class Game:
    """Coordinates input, update loop, rendering and persistence."""

    def __init__(self):
        """Initialize Game runtime state."""
        pygame.init()
        pygame.display.set_caption("Zombie Defense - Classroom Madness")

        self.width, self.height = 1000, 700
        self.screen = pygame.Surface((self.width, self.height))
        self.min_window_size = (640, 448)
        self.windowed_size = (self.width, self.height)
        self.is_fullscreen = False
        self.viewport_rect = pygame.Rect(0, 0, self.width, self.height)
        self.viewport_scale = 1.0
        self.display_surface = pygame.Surface((self.width, self.height))
        self.apply_display_mode(fullscreen=False, size=self.windowed_size)
        self.clock = pygame.time.Clock()

        self.world_rect = pygame.Rect(0, 0, 3200, 2200)
        self.world_spawn = pygame.Vector2(self.world_rect.center)

        database.init_db()

        self.state = GameState.MENU
        self.menu_selection = 0
        self.shop_selection = 0

        self.player_name = ""
        self.player_profile_id: int | None = None
        self.player_coins = 0
        self.login_username_input = ""
        self.login_password_input = ""
        self.login_active_field = "username"
        self.login_error = ""
        self.menu_message = ""
        self.score_saved = False
        self.visual_mode = "night"
        self.visual_mode_selection = 0

        self.player = Player(self.world_spawn.x, self.world_spawn.y)
        self.camera = Camera(self.width, self.height, self.world_rect)
        self.camera.update(self.player.position)

        self.zombies: list[Zombie] = []
        self.projectiles: list[Projectile] = []
        self.powerups = PowerUpManager()
        self.wave_manager = WaveManager(intermission_duration=4.5)

        self.kills = 0
        self.score = 0
        self.coins_earned_run = 0
        self.pending_coin_delta = 0
        self.coin_flush_timer = 0.0
        self.coin_flush_interval = 1.0
        self.survival_time = 0.0

        self.weapon_inventory = WeaponInventory()
        self.fire_button_prev = False
        self.run_scrap = 0
        self.run_scrap_multiplier = 1.0
        self.damage_multiplier = 1.0
        self.player_speed_multiplier = 1.0
        self.weapon_cooldown_multiplier = 1.0
        self.crit_chance = 0.0
        self.crit_damage_bonus = 0.0
        self.lifesteal_ratio = 0.0
        self.incoming_damage_multiplier = 1.0
        self.ammo_preserve_chance = 0.0
        self.projectile_speed_multiplier = 1.0
        self.powerup_drop_multiplier = 1.0
        self.ammo_cache_scrap_multiplier = 1.0
        self.low_hp_damage_multiplier = 1.0
        self.crit_base_multiplier = 1.6
        self.last_stand_enabled = False
        self.last_stand_available = False
        self.lifesteal_cap_per_second = LIFESTEAL_HEAL_CAP_PER_SECOND
        self.lifesteal_window_elapsed = 0.0
        self.lifesteal_healed_this_window = 0.0
        self.lifesteal_heal_buffer = 0.0
        self.active_run_perks: set[str] = set()
        self.pending_perk_choices: list[str] = []
        self.perk_selection = 0
        self.perk_choice_open = False
        self.armory_open = False
        self.armory_tab = "weapons"
        self.armory_selection = 0
        self.armory_scroll_offset = 0
        self.armory_message = ""
        self.armory_message_timer = 0.0
        self.mutation_drawer_open = False
        self.mutation_drawer_scroll = 0
        self.pause_open = False
        self.pause_settings_open = False
        self.pause_selection = 0
        self.pause_settings_selection = 0
        self.guide_section_index = 0
        self.guide_scroll_offset = 0
        self.guide_origin = "menu"
        self.owned_run_weapons: set[str] = set()
        self.extra_weapon_slot_unlocked = False
        self.run_upgrade_levels: dict[str, int] = {key: 0 for key in ARMORY_UPGRADE_DEFINITIONS}
        self.combat_calibration_level = 0

        self.player_hit_cooldown = 0.45
        self.player_hit_timer = 0.0
        self.last_aim_direction = pygame.Vector2(1, 0)
        self.player_velocity = pygame.Vector2()
        self._player_previous_position = pygame.Vector2(self.player.position)
        self.player_motion_sustain = 0.0
        self.total_shots_fired = 0
        self.player_took_damage_this_frame = False
        self.boss_contact_damage_lockout_timer = 0.0
        self.active_boss_hazards: list[dict[str, object]] = []

        self.active_wave_kind = "standard"
        self.active_wave_objective: str | None = None
        self.active_wave_mutator: str | None = None
        self.active_boss_archetype: str | None = None
        self.active_wave_twist: str | None = None
        self.last_wave_twist: str | None = None
        self.wave_twist_pulse_timer = 0.0
        self.safe_zone_pulse_flash_timer = 0.0
        self.no_hit_streak_seconds = 0.0
        self.boss_contact_damage_lockout_timer = 0.0
        self.active_boss_hazards = []
        self.wave_mutator_enemy_speed_mult = 1.0
        self.wave_mutator_enemy_health_mult = 1.0
        self.wave_mutator_enemy_damage_mult = 1.0
        self.wave_mutator_elite_bonus = 0.0
        self.wave_powerup_drop_multiplier = 1.0
        self.objective_state: dict[str, float | int | bool | str] = {}
        self.objective_failed = False
        self.objective_failure_message = ""
        self.objective_wave_start_kills = 0
        self.objective_wave_start_shots = 0
        self.objective_elite_kills = 0

        self.wave_banner_duration = 3.5
        self.wave_banner_timer = 0.0
        self.wave_banner_wave = 1
        self.wave_banner_is_boss = False
        self.wave_banner_subtitle = ""
        self.last_wave_banner_announced_wave = 0

        self.audio = AudioManager()
        self.audio.load_optional("assets/audio/wave_complete.wav")

        self.shop_items: list[dict[str, object]] = []

        self.initialize_player_from_settings()
        self.leaderboard_lines = self.get_leaderboard_lines()

    def initialize_player_from_settings(self) -> None:
        """Load remembered login username and keep runtime as Guest until login."""
        # Loading username is UX convenience; auth state remains guest until password check.
        self.login_username_input = settings.load_last_player_name() or ""
        self.login_password_input = ""
        self.login_active_field = "username"
        self.login_error = ""
        self.player_name = ""
        self.player_profile_id = None
        self.player_coins = 0
        self.shop_items = []
        self.menu_message = ""

    def load_player_profile(self, name: str) -> None:
        """Load/create profile and apply selected cosmetic skin."""
        clean_name = name.strip()
        if not clean_name:
            raise ValueError("Username cannot be empty.")
        # Profile lookup auto-creates player row when missing.
        profile = database.get_player_profile(clean_name)
        self.player_name = str(profile["name"])
        self.player_profile_id = int(profile["id"])
        self.player_coins = int(profile["coins"])

        selected_skin = database.get_selected_skin(self.player_profile_id)
        self.player.apply_skin(
            selected_skin["primary_color"],
            selected_skin["secondary_color"],
        )

        # Shop ownership depends on active authenticated player profile.
        self.refresh_shop_items()

    def apply_default_guest_skin(self) -> None:
        """Restore default visual skin when no account is authenticated."""
        self.player.apply_skin((70, 160, 255), (220, 240, 255))

    def is_authenticated(self) -> bool:
        """Return True when an account is currently authenticated in runtime."""
        return self.player_profile_id is not None and bool(self.player_name.strip())

    def open_login_screen(self) -> None:
        """Open in-game login UI and reset transient login feedback."""
        self.state = GameState.LOGIN
        self.login_password_input = ""
        self.login_active_field = "username"
        self.login_error = ""

    def logout_profile(self) -> None:
        """Switch active runtime identity back to Guest mode."""
        # Clear account-bound runtime state so next run is fully guest-scoped.
        self.player_name = ""
        self.player_profile_id = None
        self.player_coins = 0
        self.pending_coin_delta = 0
        self.shop_items = []
        self.login_password_input = ""
        self.login_error = ""
        self.apply_default_guest_skin()

    def attempt_login(self) -> bool:
        """Authenticate current login form payload and load bound player profile."""
        username = self.login_username_input.strip()
        password = self.login_password_input
        user = database.authenticate_web_user(username, password)
        if user is None:
            self.login_error = "Invalid username or password."
            return False

        # Prefer canonical player_name from DB, fallback to username for resilience.
        player_name = str(user.get("player_name") or user.get("username") or username)
        self.load_player_profile(player_name)
        settings.save_last_player_name(username)
        self.login_username_input = username
        self.login_password_input = ""
        self.login_active_field = "username"
        self.login_error = ""
        self.menu_message = f"Logged in as {self.player_name}."
        self.state = GameState.MENU
        return True

    def refresh_shop_items(self) -> None:
        """Reload shop inventory with ownership/selection flags."""
        if self.player_profile_id is None:
            self.shop_items = []
            return
        self.shop_items = database.get_shop_skins(self.player_profile_id)

    def reset_game(self) -> None:
        """Reset runtime entities and counters for a fresh game."""
        # Runtime collections are reset in-place to avoid stale entity references.
        self.player.reset(self.world_spawn.x, self.world_spawn.y)
        self.zombies.clear()
        self.projectiles.clear()
        self.powerups.reset()
        self.wave_manager.start_first_wave()

        self.kills = 0
        self.score = 0
        self.coins_earned_run = 0
        self.pending_coin_delta = 0
        self.coin_flush_timer = 0.0
        self.survival_time = 0.0

        self.weapon_inventory.reset_for_new_run()
        self.fire_button_prev = False
        # Run progression reset centralizes all temporary upgrades/perks/mutators.
        self.reset_run_progression()

        self.player_hit_timer = 0.0
        self.last_aim_direction = pygame.Vector2(1, 0)
        self.player_velocity = pygame.Vector2()
        self._player_previous_position = pygame.Vector2(self.player.position)
        self.player_motion_sustain = 0.0
        self.total_shots_fired = 0
        self.player_took_damage_this_frame = False
        self.boss_contact_damage_lockout_timer = 0.0
        self.active_boss_hazards = []

        self.camera.update(self.player.position)
        self.start_wave_banner(self.wave_manager.current_wave)
        self.score_saved = False

    def reset_run_progression(self) -> None:
        """Reset run-only progression systems."""
        # These values intentionally do not persist between runs.
        self.run_scrap = 0
        self.run_scrap_multiplier = 1.0
        self.damage_multiplier = 1.0
        self.player_speed_multiplier = 1.0
        self.weapon_cooldown_multiplier = 1.0
        self.crit_chance = 0.0
        self.crit_damage_bonus = 0.0
        self.lifesteal_ratio = 0.0
        self.incoming_damage_multiplier = 1.0
        self.ammo_preserve_chance = 0.0
        self.projectile_speed_multiplier = 1.0
        self.powerup_drop_multiplier = 1.0
        self.ammo_cache_scrap_multiplier = 1.0
        self.low_hp_damage_multiplier = 1.0
        self.last_stand_enabled = False
        self.last_stand_available = False
        self.crit_base_multiplier = 1.6
        self.lifesteal_cap_per_second = LIFESTEAL_HEAL_CAP_PER_SECOND
        self.lifesteal_window_elapsed = 0.0
        self.lifesteal_healed_this_window = 0.0
        self.lifesteal_heal_buffer = 0.0
        self.last_wave_banner_announced_wave = 0
        self.player.max_health = 100
        self.player.health = min(self.player.health, self.player.max_health)
        self.active_run_perks = set()
        self.pending_perk_choices = []
        self.perk_selection = 0
        self.perk_choice_open = False
        self.armory_open = False
        self.armory_tab = "weapons"
        self.armory_selection = 0
        self.armory_scroll_offset = 0
        self.armory_message = ""
        self.armory_message_timer = 0.0
        self.mutation_drawer_open = False
        self.mutation_drawer_scroll = 0
        self.pause_open = False
        self.pause_settings_open = False
        self.pause_selection = 0
        self.pause_settings_selection = 0
        self.guide_section_index = 0
        self.guide_scroll_offset = 0
        self.guide_origin = "menu"
        self.owned_run_weapons = set()
        self.extra_weapon_slot_unlocked = False
        self.run_upgrade_levels = {key: 0 for key in ARMORY_UPGRADE_DEFINITIONS}
        self.combat_calibration_level = 0
        self.active_wave_kind = "standard"
        self.active_wave_objective = None
        self.active_wave_mutator = None
        self.active_boss_archetype = None
        self.active_wave_twist = None
        self.last_wave_twist = None
        self.wave_twist_pulse_timer = 0.0
        self.safe_zone_pulse_flash_timer = 0.0
        self.no_hit_streak_seconds = 0.0
        self.boss_contact_damage_lockout_timer = 0.0
        self.active_boss_hazards = []
        self.wave_mutator_enemy_speed_mult = 1.0
        self.wave_mutator_enemy_health_mult = 1.0
        self.wave_mutator_enemy_damage_mult = 1.0
        self.wave_mutator_elite_bonus = 0.0
        self.wave_powerup_drop_multiplier = 1.0
        self.objective_state = {}
        self.objective_failed = False
        self.objective_failure_message = ""
        self.objective_wave_start_kills = 0
        self.objective_wave_start_shots = 0
        self.objective_elite_kills = 0
        # Re-apply drop multiplier baseline after mutator/perk reset.
        self.sync_powerup_drop_multiplier()

    @staticmethod
    def get_leaderboard_lines() -> list[str]:
        """Build menu leaderboard lines from database or JSON fallback."""
        db_rows = database.get_leaderboard(5)
        if db_rows:
            return [storage.format_score_line(row) for row in db_rows]
        return storage.get_leaderboard_lines(5)

    def award_coins(self, amount: int) -> None:
        """Queue coin gain and update local display counters immediately."""
        if amount <= 0 or self.player_profile_id is None:
            return

        # Coin writes are batched and flushed asynchronously to the DB.
        gained = int(amount)
        self.player_coins += gained
        self.pending_coin_delta += gained
        self.coins_earned_run += gained

    def award_run_scrap(self, amount: int) -> None:
        """Increase run-only scrap currency using active multipliers."""
        if amount <= 0:
            return

        # Scrap gain compounds permanent run bonus and temporary power-up bonus.
        multiplier = float(getattr(self, "run_scrap_multiplier", 1.0))
        powerup_mult = float(getattr(getattr(self, "powerups", None), "scrap_gain_multiplier", 1.0))
        gained = int(round(int(amount) * multiplier * powerup_mult))
        if gained <= 0:
            return
        self.run_scrap = int(getattr(self, "run_scrap", 0)) + gained

    def sync_powerup_drop_multiplier(self) -> None:
        """Apply combined perk + mutator drop multiplier to power-up manager."""
        run_mult = float(getattr(self, "powerup_drop_multiplier", 1.0))
        wave_mult = float(getattr(self, "wave_powerup_drop_multiplier", 1.0))
        powerups = getattr(self, "powerups", None)
        if powerups is not None and hasattr(powerups, "drop_chance_multiplier"):
            powerups.drop_chance_multiplier = max(0.1, run_mult * wave_mult)

    def current_ammo_pressure_ratio(self) -> float:
        """Return 0..1 scarcity ratio used to bias ammo drop chance."""
        inventory = getattr(self, "weapon_inventory", None)
        if inventory is None or not hasattr(inventory, "slots") or not hasattr(inventory, "catalog"):
            return 0.0

        pressures: list[float] = []
        for slot_state in inventory.slots:
            if slot_state is None:
                continue
            spec = inventory.catalog.get(slot_state.spec_key)
            if spec is None or spec.reserve_ammo is None:
                continue

            mag_ratio = 0.0 if spec.magazine_size <= 0 else slot_state.ammo_in_mag / spec.magazine_size
            reserve_ratio = 0.0 if spec.reserve_ammo <= 0 else (slot_state.reserve_ammo or 0) / spec.reserve_ammo
            weighted_fill = max(0.0, min(1.0, 0.65 * mag_ratio + 0.35 * reserve_ratio))
            pressures.append(1.0 - weighted_fill)

        if not pressures:
            return 0.0
        # Use highest scarcity weapon so drop logic reacts to worst ammo state.
        return max(0.0, min(1.0, max(pressures)))

    def apply_ammo_cache_pickup(self) -> None:
        """Resolve ammo pickup reward or fallback scrap when ammo is not needed."""
        bonus_mult = max(0.25, float(getattr(self, "ammo_cache_scrap_multiplier", 1.0)))

        def scaled_scrap(base_amount: int) -> int:
            return max(1, int(round(int(base_amount) * bonus_mult)))

        powerups = getattr(self, "powerups", None)
        feedback = getattr(powerups, "register_ammo_cache_feedback", None)
        if str(getattr(self, "active_wave_twist", "")) == "ammo_cache_denial":
            # Special twist converts ammo cache into scrap-only reward.
            gained = scaled_scrap(10)
            self.award_run_scrap(gained)
            if callable(feedback):
                feedback(f"Ammo Cache denied: +{gained} scrap")
            return
        if self.weapon_inventory.apply_ammo_pickup():
            # Normal branch: refill ammo when at least one finite weapon needs it.
            if callable(feedback):
                feedback("Ammo Cache: reloaded")
            return
        gained = scaled_scrap(8)
        self.award_run_scrap(gained)
        if callable(feedback):
            feedback(f"Ammo Cache: +{gained} scrap")

    def handle_collected_pickups(self, collected: list[PowerUpType]) -> None:
        """Apply post-collection gameplay effects handled outside PowerUpManager."""
        for kind in collected:
            if kind == PowerUpType.AMMO_CACHE:
                self.apply_ammo_cache_pickup()

    def run_perk_labels(self) -> list[str]:
        """Return active run perk labels for HUD rendering."""
        labels: list[str] = []
        for perk_key in sorted(getattr(self, "active_run_perks", set())):
            perk = RUN_PERK_DEFINITIONS.get(perk_key)
            if perk is None:
                continue
            labels.append(f"Perk: {perk['name']}")
        return labels

    def run_perk_drawer_lines(self) -> list[str]:
        """Return detailed permanent mutation lines for left drawer panel."""
        lines: list[str] = []
        for perk_key in sorted(getattr(self, "active_run_perks", set())):
            perk = RUN_PERK_DEFINITIONS.get(perk_key)
            if perk is None:
                continue
            name = str(perk.get("name", perk_key))
            description = str(perk.get("description", "")).strip()
            if description:
                lines.append(f"{name}: {description}")
            else:
                lines.append(name)
        return lines

    @staticmethod
    def boss_archetype_label(archetype_key: str | None) -> str:
        """Return human-readable boss archetype label."""
        token = str(archetype_key or "").strip().lower()
        if token in BOSS_ARCHETYPE_LABELS:
            return BOSS_ARCHETYPE_LABELS[token]
        return "Warden"

    @staticmethod
    def boss_counter_hint(archetype_key: str | None) -> str:
        """Return one-line HUD tip for active boss archetype."""
        token = str(archetype_key or "").strip().lower()
        if token in BOSS_COUNTER_HINTS:
            return BOSS_COUNTER_HINTS[token]
        return BOSS_COUNTER_HINTS[BossArchetype.WARDEN.value]

    @staticmethod
    def wave_twist_label(twist_key: str | None) -> str:
        """Return compact label for active wave twist."""
        token = str(twist_key or "").strip().lower()
        if token in WAVE_TWIST_LABELS:
            return WAVE_TWIST_LABELS[token]
        return ""

    def choose_wave_twist(self, wave_number: int, wave_kind: str, *, is_boss_wave: bool) -> str | None:
        """Pick occasional non-boss wave mini-event with soft anti-repeat."""
        if str(wave_kind or "standard") != "standard":
            return None
        wave = max(1, int(wave_number))
        if is_boss_wave or wave % WAVE_TWIST_COOLDOWN != 0:
            return None

        last = str(getattr(self, "last_wave_twist", "") or "")
        weights: list[float] = []
        for token in WAVE_TWIST_KEYS:
            weight = 1.0
            if token == last:
                weight *= 0.35
            weights.append(weight)
        picked = random.choices(list(WAVE_TWIST_KEYS), weights=weights, k=1)[0]
        self.last_wave_twist = picked
        return picked

    def advance_lifesteal_window(self, dt: float) -> None:
        """Advance 1-second lifesteal cap window and reset healed budget when needed."""
        if dt <= 0:
            return
        elapsed = float(getattr(self, "lifesteal_window_elapsed", 0.0)) + float(dt)
        while elapsed >= 1.0:
            elapsed -= 1.0
            self.lifesteal_healed_this_window = 0.0
        self.lifesteal_window_elapsed = elapsed

    def apply_lifesteal_from_damage(self, dealt_damage: int) -> None:
        """Convert dealt projectile damage into capped lifesteal healing."""
        lifesteal_ratio = float(getattr(self, "lifesteal_ratio", 0.0))
        if lifesteal_ratio <= 0.0 or dealt_damage <= 0:
            return
        heal_raw = float(dealt_damage) * lifesteal_ratio
        if heal_raw <= 0:
            return

        per_second_cap = max(0.0, float(getattr(self, "lifesteal_cap_per_second", LIFESTEAL_HEAL_CAP_PER_SECOND)))
        healed_in_window = max(0.0, float(getattr(self, "lifesteal_healed_this_window", 0.0)))
        remaining = max(0.0, per_second_cap - healed_in_window)
        if remaining <= 0:
            return

        heal_budget = min(heal_raw, remaining)
        if heal_budget <= 0:
            return
        buffer = max(0.0, float(getattr(self, "lifesteal_heal_buffer", 0.0))) + heal_budget
        whole_heal = int(buffer)
        if whole_heal > 0:
            self.player.heal(whole_heal)
            buffer -= whole_heal
        self.lifesteal_heal_buffer = max(0.0, buffer)
        self.lifesteal_healed_this_window = healed_in_window + heal_budget

    def combined_incoming_damage_multiplier(self) -> float:
        """Return permanent and temporary incoming-damage multiplier stack."""
        perk_mult = float(getattr(self, "incoming_damage_multiplier", 1.0))
        powerup_mult = float(getattr(getattr(self, "powerups", None), "incoming_damage_multiplier", 1.0))
        return max(0.05, perk_mult * powerup_mult)

    def next_wave_danger_tag(self) -> str:
        """Return armory intel hint for the next wave's likely pressure profile."""
        manager = getattr(self, "wave_manager", None)
        if manager is None:
            return "Balanced pressure"

        wave = max(1, int(getattr(manager, "current_wave", 1)))
        is_boss_wave = bool(getattr(manager, "is_boss_wave", lambda _wave=None: False)(wave))
        if is_boss_wave:
            preview = None
            if hasattr(manager, "preview_next_boss_archetype"):
                preview = manager.preview_next_boss_archetype(wave)
            return f"Boss archetype: {self.boss_archetype_label(preview)}"

        wave_kind = "standard"
        if hasattr(manager, "_wave_kind_for_wave"):
            wave_kind = str(manager._wave_kind_for_wave(wave))
        objective_key = None
        mutator_key = None
        if hasattr(manager, "_objective_for_wave"):
            objective_key = manager._objective_for_wave(wave)
        if hasattr(manager, "_mutator_for_wave"):
            mutator_key = manager._mutator_for_wave(wave, wave_kind)

        if str(objective_key or "") in {"survive_timer", "kill_quota"} or str(mutator_key or "") in {"swarm_protocol", "hunter_pack"}:
            return "Speed-heavy pressure"
        if str(mutator_key or "") in {"fortified_horde"} or str(objective_key or "") in {"elite_hunt"}:
            return "Tank-heavy pressure"
        return "Balanced pressure"

    def apply_effect_bundle(self, effects: dict[str, object]) -> None:
        """Apply structured run effect dictionary and clamp gameplay limits."""
        if not effects:
            return

        self.damage_multiplier = float(getattr(self, "damage_multiplier", 1.0))
        self.player_speed_multiplier = float(getattr(self, "player_speed_multiplier", 1.0))
        self.run_scrap_multiplier = float(getattr(self, "run_scrap_multiplier", 1.0))
        self.weapon_cooldown_multiplier = float(getattr(self, "weapon_cooldown_multiplier", 1.0))
        self.crit_chance = float(getattr(self, "crit_chance", 0.0))
        self.crit_damage_bonus = float(getattr(self, "crit_damage_bonus", 0.0))
        self.lifesteal_ratio = float(getattr(self, "lifesteal_ratio", 0.0))
        self.lifesteal_cap_per_second = float(getattr(self, "lifesteal_cap_per_second", LIFESTEAL_HEAL_CAP_PER_SECOND))
        self.incoming_damage_multiplier = float(getattr(self, "incoming_damage_multiplier", 1.0))
        self.ammo_preserve_chance = float(getattr(self, "ammo_preserve_chance", 0.0))
        self.projectile_speed_multiplier = float(getattr(self, "projectile_speed_multiplier", 1.0))
        self.powerup_drop_multiplier = float(getattr(self, "powerup_drop_multiplier", 1.0))
        self.low_hp_damage_multiplier = float(getattr(self, "low_hp_damage_multiplier", 1.0))
        self.last_stand_enabled = bool(getattr(self, "last_stand_enabled", False))
        self.last_stand_available = bool(getattr(self, "last_stand_available", False))
        self.crit_base_multiplier = float(getattr(self, "crit_base_multiplier", 1.6))

        if "damage_mult" in effects:
            self.damage_multiplier *= float(effects["damage_mult"])
        if "reload_mult" in effects and hasattr(self, "weapon_inventory"):
            self.weapon_inventory.reload_time_multiplier *= float(effects["reload_mult"])
        if "move_mult" in effects:
            self.player_speed_multiplier *= float(effects["move_mult"])
        if "scrap_mult" in effects:
            self.run_scrap_multiplier *= float(effects["scrap_mult"])
        if "cooldown_mult" in effects:
            self.weapon_cooldown_multiplier *= float(effects["cooldown_mult"])
        if "crit_chance_add" in effects:
            self.crit_chance += float(effects["crit_chance_add"])
        if "crit_damage_add" in effects:
            self.crit_damage_bonus += float(effects["crit_damage_add"])
        if "lifesteal_add" in effects:
            self.lifesteal_ratio += float(effects["lifesteal_add"])
        if "lifesteal_cap_set" in effects:
            self.lifesteal_cap_per_second = max(
                float(getattr(self, "lifesteal_cap_per_second", LIFESTEAL_HEAL_CAP_PER_SECOND)),
                float(effects["lifesteal_cap_set"]),
            )
        if "incoming_mult" in effects:
            self.incoming_damage_multiplier *= float(effects["incoming_mult"])
        if "ammo_preserve_add" in effects:
            self.ammo_preserve_chance += float(effects["ammo_preserve_add"])
        if "projectile_speed_mult" in effects:
            self.projectile_speed_multiplier *= float(effects["projectile_speed_mult"])
        if "powerup_drop_mult" in effects:
            self.powerup_drop_multiplier *= float(effects["powerup_drop_mult"])
        if "ammo_cache_scrap_mult" in effects:
            self.ammo_cache_scrap_multiplier = float(getattr(self, "ammo_cache_scrap_multiplier", 1.0))
            self.ammo_cache_scrap_multiplier *= float(effects["ammo_cache_scrap_mult"])
        player = getattr(self, "player", None)
        if "max_health_add" in effects and player is not None and hasattr(player, "max_health"):
            player.max_health += int(effects["max_health_add"])
        if "heal_add" in effects and player is not None:
            if hasattr(player, "heal"):
                player.heal(int(effects["heal_add"]))
            elif hasattr(player, "health") and hasattr(player, "max_health"):
                player.health = min(int(player.max_health), int(player.health) + int(effects["heal_add"]))
        if "low_hp_damage_mult" in effects:
            self.low_hp_damage_multiplier *= float(effects["low_hp_damage_mult"])
        if bool(effects.get("last_stand_enable", False)):
            self.last_stand_enabled = True
            self.last_stand_available = True

        if player is not None and hasattr(player, "max_health") and hasattr(player, "health"):
            player.max_health = max(1, int(player.max_health))
            player.health = min(player.health, player.max_health)
        if hasattr(self, "weapon_inventory"):
            self.weapon_inventory.reload_time_multiplier = max(0.35, float(self.weapon_inventory.reload_time_multiplier))
        self.weapon_cooldown_multiplier = max(0.45, float(self.weapon_cooldown_multiplier))
        self.crit_chance = max(0.0, min(0.55, float(self.crit_chance)))
        self.ammo_preserve_chance = max(0.0, min(0.60, float(self.ammo_preserve_chance)))
        self.lifesteal_ratio = max(0.0, min(0.25, float(self.lifesteal_ratio)))
        self.lifesteal_cap_per_second = max(0.0, float(getattr(self, "lifesteal_cap_per_second", LIFESTEAL_HEAL_CAP_PER_SECOND)))
        self.powerup_drop_multiplier = max(0.1, float(self.powerup_drop_multiplier))
        self.ammo_cache_scrap_multiplier = max(0.25, min(2.5, float(getattr(self, "ammo_cache_scrap_multiplier", 1.0))))
        self.player_speed_multiplier = min(1.35, max(0.25, float(self.player_speed_multiplier)))
        self.sync_powerup_drop_multiplier()

    def apply_run_perk(self, perk_key: str) -> None:
        """Apply one selected run perk using structured effect payload."""
        perks = getattr(self, "active_run_perks", set())
        if perk_key in perks:
            return

        perk = RUN_PERK_DEFINITIONS.get(perk_key)
        if perk is None:
            return

        perks.add(perk_key)
        self.active_run_perks = perks
        self.apply_effect_bundle(dict(perk.get("effects", {})))

    def maybe_offer_run_perk(self, cleared_wave: int) -> None:
        """Open perk draft every two cleared waves during intermission."""
        if cleared_wave <= 0 or cleared_wave % 2 != 0:
            return

        active = set(getattr(self, "active_run_perks", set()))
        if len(active) >= len(RUN_PERK_DEFINITIONS):
            return

        perk_keys = [key for key in RUN_PERK_DEFINITIONS if key not in active]
        if not perk_keys:
            return
        self.pending_perk_choices = random.sample(perk_keys, k=min(4, len(perk_keys)))
        self.perk_selection = 0
        self.perk_choice_open = bool(self.pending_perk_choices)
        if self.perk_choice_open:
            self.armory_open = False
            self.mutation_drawer_open = False
            self.mutation_drawer_scroll = 0

    def armory_specs(self) -> list[dict[str, object]]:
        """Return active armory rows for selected tab."""
        if str(getattr(self, "armory_tab", "weapons")) == "upgrades":
            return self.armory_upgrade_rows()
        return self.armory_weapon_rows()

    @staticmethod
    def weapon_armory_explanation(spec: object) -> str:
        """Return concise player-facing weapon explanation for Armory bar."""
        damage = int(getattr(spec, "damage", 0))
        cooldown = float(getattr(spec, "cooldown", 0.0))
        magazine = int(getattr(spec, "magazine_size", 0))
        reserve = getattr(spec, "reserve_ammo", None)
        fire_mode = str(getattr(spec, "fire_mode", "single")).replace("_", " ")
        unlock_wave = int(getattr(spec, "unlock_wave", 1))
        reserve_text = "infinite reserve" if reserve is None else f"{int(reserve)} reserve"
        return (
            f"{getattr(spec, 'display_name', 'Weapon')}: {fire_mode} fire, {damage} damage per shot, "
            f"{cooldown:.2f}s cooldown, {magazine}-round mag with {reserve_text}. Unlocks at wave {unlock_wave}."
        )

    def armory_weapon_rows(self) -> list[dict[str, object]]:
        """Return weapon tab rows (weapon actions + per-weapon ammo refill)."""
        manager = getattr(self, "wave_manager", None)
        wave = max(1, int(getattr(manager, "current_wave", 1)))
        owned = set(getattr(self, "owned_run_weapons", set()))
        rows: list[dict[str, object]] = []

        for spec in self.weapon_inventory.weapon_shop_specs():
            row: dict[str, object] = {
                "kind": "weapon",
                "weapon_key": spec.key,
                "name": spec.display_name,
                "detail": f"DMG {spec.damage}",
                "enabled": True,
                "status": "",
                "explain": self.weapon_armory_explanation(spec),
            }
            if spec.key in owned:
                row["status"] = "Owned (equip)"
            elif wave < spec.unlock_wave:
                row["status"] = f"Unlocks wave {spec.unlock_wave}"
                row["enabled"] = False
                row["blocked_message"] = f"Unlocks at wave {spec.unlock_wave}"
            else:
                row["status"] = f"{spec.price_points} scrap"
            rows.append(row)

        rows.extend(self.armory_ammo_refill_rows())
        return rows

    def armory_upgrade_rows(self) -> list[dict[str, object]]:
        """Return stat-upgrade rows with current tier and next cost."""
        levels = getattr(self, "run_upgrade_levels", {})
        rows: list[dict[str, object]] = []
        for upgrade_key, upgrade in ARMORY_UPGRADE_DEFINITIONS.items():
            costs = list(upgrade["costs"])
            level = int(levels.get(upgrade_key, 0))
            max_level = len(costs)
            row: dict[str, object] = {
                "kind": "upgrade",
                "upgrade_key": upgrade_key,
                "name": str(upgrade["name"]),
                "detail": f"T{level}/{max_level}",
                "enabled": level < max_level,
                "explain": f"{upgrade['name']}: {upgrade['detail']}. Buy tiers to stack this effect.",
            }
            if level >= max_level:
                row["status"] = "MAX"
                row["blocked_message"] = "Already maxed"
            else:
                next_cost = int(costs[level])
                row["status"] = f"{next_cost} scrap"
                row["cost"] = next_cost
            rows.append(row)

        manager = getattr(self, "wave_manager", None)
        wave = max(1, int(getattr(manager, "current_wave", 1)))
        sling_unlocked = bool(getattr(self, "extra_weapon_slot_unlocked", False))
        if hasattr(self, "weapon_inventory") and hasattr(self.weapon_inventory, "has_extra_slot"):
            sling_unlocked = sling_unlocked or bool(self.weapon_inventory.has_extra_slot())
        sling_row: dict[str, object] = {
            "kind": "extra_slot_unlock",
            "name": "Tactical Sling",
            "detail": "Unlocks main slot 3",
            "enabled": False,
            "status": "",
            "explain": "Tactical Sling: one-time run upgrade that unlocks a third purchasable main weapon slot.",
        }
        if sling_unlocked:
            sling_row["status"] = "Unlocked"
            sling_row["blocked_message"] = "Already unlocked this run"
        elif wave < TACTICAL_SLING_UNLOCK_WAVE:
            sling_row["status"] = f"Unlocks wave {TACTICAL_SLING_UNLOCK_WAVE}"
            sling_row["blocked_message"] = f"Unlocks at wave {TACTICAL_SLING_UNLOCK_WAVE}"
        else:
            sling_row["status"] = f"{TACTICAL_SLING_COST} scrap"
            sling_row["enabled"] = True
            sling_row["cost"] = TACTICAL_SLING_COST
        rows.append(sling_row)

        player = getattr(self, "player", None)
        missing_hp = 0
        if player is not None and hasattr(player, "max_health") and hasattr(player, "health"):
            missing_hp = max(0, int(player.max_health) - int(player.health))
        repair_row: dict[str, object] = {
            "kind": "field_repair",
            "name": "Field Repair",
            "detail": "Restore missing HP",
            "enabled": missing_hp > 0,
            "explain": "Field Repair: instantly restores your missing HP in exchange for scrap.",
        }
        if missing_hp <= 0:
            repair_row["status"] = "HP full"
            repair_row["blocked_message"] = "Health is already full"
        else:
            repair_cost = max(15, int(round(missing_hp * 3.4)))
            repair_row["status"] = f"{repair_cost} scrap"
            repair_row["cost"] = repair_cost
            repair_row["heal_amount"] = missing_hp
        rows.append(repair_row)

        calibration_level = int(getattr(self, "combat_calibration_level", 0))
        calibration_cost = 280 + calibration_level * 140
        rows.append(
            {
                "kind": "combat_calibration",
                "name": "Combat Calibration",
                "detail": f"T{calibration_level} (+3% DMG)",
                "enabled": True,
                "status": f"{calibration_cost} scrap",
                "cost": calibration_cost,
                "explain": "Combat Calibration: repeatable upgrade that permanently boosts run damage by +3% each purchase.",
            }
        )
        rows.append(
            {
                "kind": "wave_intel",
                "name": "Intel Uplink",
                "detail": self.next_wave_danger_tag(),
                "enabled": False,
                "status": "Preview",
                "blocked_message": "Intel row is informational only",
                "explain": "Intel Uplink: non-purchasable preview of next-wave danger profile.",
            }
        )
        return rows

    def armory_ammo_refill_rows(self) -> list[dict[str, object]]:
        """Build armory rows for refilling any owned finite-ammo weapon."""
        rows: list[dict[str, object]] = []
        finite_states = self.weapon_inventory.owned_finite_weapon_states()
        if not finite_states:
            return [
                {
                    "kind": "ammo_refill_weapon",
                    "name": "Ammo Refill",
                    "detail": "Owned finite weapons",
                    "status": "Buy a finite-ammo weapon first",
                    "enabled": False,
                    "blocked_message": "No finite-ammo weapon owned",
                    "explain": "Ammo Refill: buy one to fully restock any owned finite-ammo weapon, even when not equipped.",
                }
            ]

        for state in finite_states:
            spec = self.weapon_inventory.catalog[state.spec_key]
            reserve_total = int(spec.reserve_ammo or 0)
            reserve_value = int(state.reserve_ammo or 0)
            detail = f"Mag {state.ammo_in_mag}/{spec.magazine_size}  Res {reserve_value}/{reserve_total}"
            row: dict[str, object] = {
                "kind": "ammo_refill_weapon",
                "name": f"Refill {spec.display_name}",
                "detail": detail,
                "status": "",
                "enabled": False,
                "weapon_key": spec.key,
                "explain": f"Ammo Refill: fully restocks {spec.display_name} magazine and reserve regardless of active weapon.",
            }
            if self.weapon_inventory.is_ammo_full(state):
                row["status"] = "Already full"
                row["blocked_message"] = "Ammo already full"
            else:
                cost = int(self.weapon_inventory.ammo_refill_cost(spec.key))
                row["status"] = f"{cost} scrap"
                row["cost"] = cost
                row["enabled"] = True
            rows.append(row)
        return rows

    def toggle_armory(self) -> None:
        """Toggle armory overlay during intermission only."""
        if getattr(self, "perk_choice_open", False):
            return
        if not self.wave_manager.is_intermission():
            return
        self.armory_open = not getattr(self, "armory_open", False)
        if self.armory_open:
            self.mutation_drawer_open = False
            self.mutation_drawer_scroll = 0
        self.armory_tab = "weapons"
        self.armory_selection = 0
        self.armory_scroll_offset = 0
        self.armory_message = ""
        self.armory_message_timer = 0.0

    def set_armory_message(self, text: str) -> None:
        """Store armory feedback text with a visible timeout."""
        self.armory_message = text
        self.armory_message_timer = 1.5

    def switch_armory_tab(self, tab_key: str) -> None:
        """Switch active armory tab and reset row selection."""
        target = str(tab_key).lower().strip()
        if target not in {"weapons", "upgrades"}:
            return
        if target == self.armory_tab:
            return
        self.armory_tab = target
        self.armory_selection = 0
        self.armory_scroll_offset = 0

    def try_buy_armory_selection(self) -> bool:
        """Try executing currently selected armory row action."""
        rows = self.armory_specs()
        if not rows:
            return False

        index = min(max(0, int(getattr(self, "armory_selection", 0))), len(rows) - 1)
        row = rows[index]
        kind = str(row.get("kind", "weapon"))

        if kind == "wave_intel":
            self.set_armory_message(str(row.get("detail", "Intel unavailable")))
            return False

        if kind in {"ammo_refill", "ammo_refill_weapon"}:
            if not bool(row.get("enabled", False)):
                self.set_armory_message(str(row.get("blocked_message", row.get("status", "Unavailable"))))
                return False

            cost = int(row.get("cost", 0))
            if int(getattr(self, "run_scrap", 0)) < cost:
                self.set_armory_message("Not enough scrap")
                return False

            weapon_key = str(row.get("weapon_key", "")).strip()
            target_state = self.weapon_inventory.active_state
            if weapon_key:
                owned_state = self.weapon_inventory.get_owned_weapon_state(weapon_key)
                if owned_state is not None:
                    target_state = owned_state
            if not self.weapon_inventory.refill_weapon_ammo(target_state):
                self.set_armory_message("Refill unavailable")
                return False

            self.run_scrap -= cost
            self.set_armory_message("Ammo restocked")
            return True

        if kind == "extra_slot_unlock":
            if bool(getattr(self, "extra_weapon_slot_unlocked", False)):
                self.set_armory_message("Tactical Sling already unlocked")
                return False
            if not bool(row.get("enabled", False)):
                self.set_armory_message(str(row.get("blocked_message", row.get("status", "Unavailable"))))
                return False

            cost = int(row.get("cost", TACTICAL_SLING_COST))
            if int(getattr(self, "run_scrap", 0)) < cost:
                self.set_armory_message("Not enough scrap")
                return False

            self.run_scrap -= cost
            self.extra_weapon_slot_unlocked = True
            self.weapon_inventory.unlock_extra_slot()
            self.set_armory_message("Tactical Sling installed: slot 3 unlocked")
            return True

        if kind == "field_repair":
            if not bool(row.get("enabled", False)):
                self.set_armory_message(str(row.get("blocked_message", row.get("status", "Unavailable"))))
                return False

            cost = int(row.get("cost", 0))
            if int(getattr(self, "run_scrap", 0)) < cost:
                self.set_armory_message("Not enough scrap")
                return False

            heal_amount = int(row.get("heal_amount", 0))
            if heal_amount <= 0:
                self.set_armory_message("Health already full")
                return False

            self.run_scrap -= cost
            self.player.heal(heal_amount)
            self.set_armory_message("Armor patched and HP restored")
            return True

        if kind == "combat_calibration":
            cost = int(row.get("cost", 0))
            if int(getattr(self, "run_scrap", 0)) < cost:
                self.set_armory_message("Not enough scrap")
                return False

            self.run_scrap -= cost
            self.combat_calibration_level = int(getattr(self, "combat_calibration_level", 0)) + 1
            self.apply_effect_bundle({"damage_mult": 1.03})
            self.set_armory_message(f"Combat Calibration T{self.combat_calibration_level}")
            return True

        if kind == "upgrade":
            if not bool(row.get("enabled", False)):
                self.set_armory_message(str(row.get("blocked_message", "Unavailable")))
                return False

            cost = int(row.get("cost", 0))
            if int(getattr(self, "run_scrap", 0)) < cost:
                self.set_armory_message("Not enough scrap")
                return False

            upgrade_key = str(row.get("upgrade_key", ""))
            upgrade = ARMORY_UPGRADE_DEFINITIONS.get(upgrade_key)
            if upgrade is None:
                self.set_armory_message("Unavailable")
                return False

            levels = dict(getattr(self, "run_upgrade_levels", {}))
            current_level = int(levels.get(upgrade_key, 0))
            if current_level >= len(list(upgrade["costs"])):
                self.set_armory_message("Already maxed")
                return False

            self.run_scrap -= cost
            levels[upgrade_key] = current_level + 1
            self.run_upgrade_levels = levels
            self.apply_effect_bundle(dict(upgrade["effects"]))
            self.set_armory_message(f"Upgraded {upgrade['name']} (T{current_level + 1})")
            return True

        weapon_key = str(row.get("weapon_key", ""))
        if weapon_key not in self.weapon_inventory.catalog:
            self.set_armory_message("Unavailable")
            return False
        spec = self.weapon_inventory.catalog[weapon_key]
        owned = set(getattr(self, "owned_run_weapons", set()))
        if spec.key in owned:
            self.weapon_inventory.buy_weapon(spec.key)
            self.set_armory_message(f"Equipped {spec.display_name}")
            return True

        wave = max(1, int(getattr(self.wave_manager, "current_wave", 1)))
        if wave < spec.unlock_wave:
            self.set_armory_message(f"Unlocks at wave {spec.unlock_wave}")
            return False

        if int(getattr(self, "run_scrap", 0)) < spec.price_points:
            self.set_armory_message("Not enough scrap")
            return False

        self.run_scrap -= int(spec.price_points)
        self.weapon_inventory.buy_weapon(spec.key)
        owned.add(spec.key)
        self.owned_run_weapons = owned
        self.set_armory_message(f"Bought {spec.display_name}")
        return True

    def flush_pending_coins(self, force: bool = False) -> None:
        """Persist queued coin deltas in a single DB write."""
        if self.player_profile_id is None or self.pending_coin_delta <= 0:
            return

        if not force and self.coin_flush_timer < self.coin_flush_interval:
            return

        try:
            self.player_coins = database.add_player_coins(self.player_profile_id, self.pending_coin_delta)
            self.pending_coin_delta = 0
            self.coin_flush_timer = 0.0
        except Exception:
            # Keep queued coins and retry next frame.
            return

    def start_wave_banner(
        self,
        wave_number: int,
        is_boss: bool | None = None,
        subtitle: str = "",
        *,
        force: bool = False,
    ) -> None:
        """Start short center-screen wave banner animation."""
        safe_wave = max(1, int(wave_number))
        if not force and int(getattr(self, "last_wave_banner_announced_wave", 0)) == safe_wave:
            return

        self.wave_banner_wave = safe_wave
        if is_boss is None:
            manager = getattr(self, "wave_manager", None)
            if manager is not None and hasattr(manager, "is_boss_wave"):
                self.wave_banner_is_boss = bool(manager.is_boss_wave(self.wave_banner_wave))
            else:
                self.wave_banner_is_boss = False
        else:
            self.wave_banner_is_boss = bool(is_boss)
        self.wave_banner_subtitle = str(subtitle or "")
        self.wave_banner_timer = self.wave_banner_duration
        self.last_wave_banner_announced_wave = safe_wave

    def update_wave_banner_timer(self, dt: float) -> None:
        """Count down banner visibility timer."""
        self.wave_banner_timer = max(0.0, self.wave_banner_timer - dt)

    def process_wave_clear(self) -> None:
        """Apply wave-clear rewards and trigger intermission visuals/audio."""
        if str(getattr(self, "active_wave_kind", "standard")) == "objective":
            self.zombies.clear()
            self.projectiles.clear()
        cleared_wave = max(1, self.wave_manager.current_wave - 1)
        score_gain = 30 + cleared_wave * 12
        self.score += score_gain
        self.award_coins(8 + cleared_wave * 3)
        self.award_run_scrap(16 + cleared_wave * 6)
        self.maybe_offer_run_perk(cleared_wave)
        is_boss_wave = False
        if hasattr(self.wave_manager, "is_boss_wave"):
            is_boss_wave = bool(self.wave_manager.is_boss_wave(self.wave_manager.current_wave))
        subtitle = "BOSS ROUND" if is_boss_wave else ""
        self.start_wave_banner(
            self.wave_manager.current_wave,
            is_boss=is_boss_wave,
            subtitle=subtitle,
        )
        self.audio.play_wave_complete()
        self.reset_wave_rule_runtime()

    def reset_wave_rule_runtime(self) -> None:
        """Clear per-wave mutator/objective runtime state back to defaults."""
        self.active_wave_kind = "standard"
        self.active_wave_objective = None
        self.active_wave_mutator = None
        self.active_boss_archetype = None
        self.active_wave_twist = None
        self.wave_twist_pulse_timer = 0.0
        self.safe_zone_pulse_flash_timer = 0.0
        self.no_hit_streak_seconds = 0.0
        self.wave_mutator_enemy_speed_mult = 1.0
        self.wave_mutator_enemy_health_mult = 1.0
        self.wave_mutator_enemy_damage_mult = 1.0
        self.wave_mutator_elite_bonus = 0.0
        self.wave_powerup_drop_multiplier = 1.0
        self.objective_state = {}
        self.objective_failed = False
        self.objective_failure_message = ""
        self.objective_wave_start_kills = int(getattr(self, "kills", 0))
        self.objective_wave_start_shots = int(getattr(self, "total_shots_fired", 0))
        self.objective_elite_kills = 0
        self.sync_powerup_drop_multiplier()

    def configure_wave_runtime(
        self,
        wave_kind: str,
        objective_key: str | None,
        mutator_key: str | None,
        boss_archetype: str | None = None,
        wave_twist: str | None = None,
    ) -> None:
        """Apply mutator/objective runtime context for a newly started wave."""
        self.reset_wave_rule_runtime()
        self.active_wave_kind = str(wave_kind or "standard")
        self.active_wave_objective = objective_key
        self.active_wave_mutator = mutator_key
        token = str(boss_archetype or "").strip().lower()
        self.active_boss_archetype = token if token in BOSS_ARCHETYPE_LABELS else None
        twist_token = str(wave_twist or "").strip().lower()
        self.active_wave_twist = twist_token if twist_token in WAVE_TWIST_LABELS else None
        self.wave_twist_pulse_timer = 0.0
        self.safe_zone_pulse_flash_timer = 0.0
        self.no_hit_streak_seconds = 0.0
        self.objective_wave_start_kills = int(getattr(self, "kills", 0))
        self.objective_wave_start_shots = int(getattr(self, "total_shots_fired", 0))
        self.objective_elite_kills = 0

        mutator = MUTATOR_DEFINITIONS.get(str(mutator_key or ""))
        if mutator:
            self.wave_mutator_enemy_speed_mult = float(mutator.get("zombie_speed_mult", 1.0))
            self.wave_mutator_enemy_health_mult = float(mutator.get("zombie_health_mult", 1.0))
            self.wave_mutator_enemy_damage_mult = float(mutator.get("zombie_damage_mult", 1.0))
            self.wave_mutator_elite_bonus = float(mutator.get("elite_bonus", 0.0))
            self.wave_powerup_drop_multiplier = float(mutator.get("powerup_drop_mult", 1.0))
        self.sync_powerup_drop_multiplier()

        if self.active_wave_kind != "objective":
            return

        wave = max(1, int(getattr(self.wave_manager, "current_wave", 1)))
        objective_state: dict[str, float | int | bool | str] = {"objective_key": str(objective_key or "")}
        objective_key_token = str(objective_key or "")
        if objective_key_token == "survive_timer":
            objective_state["target_seconds"] = float(min(62.0, 20.0 + wave * 1.8))
            objective_state["elapsed_seconds"] = 0.0
        elif objective_key_token == "kill_quota":
            objective_state["target_kills"] = int(14 + wave * 2.9)
        elif objective_key_token == "no_hit_window":
            objective_state["target_seconds"] = float(min(44.0, 14.0 + wave * 1.4))
            objective_state["elapsed_seconds"] = 0.0
        elif objective_key_token == "elite_hunt":
            objective_state["target_elites"] = int(max(3, min(14, 2 + wave // 2)))
        elif objective_key_token == "ammo_discipline":
            target_kills = int(10 + wave * 2.1)
            objective_state["target_kills"] = target_kills
            objective_state["shot_budget"] = int(max(22, round(target_kills * 4.0)))
        self.objective_state = objective_state

    def objective_spawn_exhausted(self) -> bool:
        """Return True when objective wave has no pending/active enemies left."""
        manager = getattr(self, "wave_manager", None)
        if manager is None:
            return len(getattr(self, "zombies", [])) == 0
        to_spawn = int(getattr(manager, "to_spawn", 0))
        boss_pending = int(getattr(manager, "boss_spawn_pending", 0))
        return to_spawn <= 0 and boss_pending <= 0 and len(getattr(self, "zombies", [])) == 0

    def objective_progress_label(self) -> str:
        """Return concise HUD objective progress line."""
        if str(getattr(self, "active_wave_kind", "standard")) != "objective":
            return ""

        objective_key = str(getattr(self, "active_wave_objective", "") or "")
        objective = OBJECTIVE_DEFINITIONS.get(objective_key, {})
        short_name = str(objective.get("short", objective_key.replace("_", " ").title()))
        state = dict(getattr(self, "objective_state", {}))
        kills_delta = int(getattr(self, "kills", 0)) - int(getattr(self, "objective_wave_start_kills", 0))
        shots_delta = int(getattr(self, "total_shots_fired", 0)) - int(getattr(self, "objective_wave_start_shots", 0))

        if objective_key == "survive_timer":
            elapsed = float(state.get("elapsed_seconds", 0.0))
            target = max(0.1, float(state.get("target_seconds", 1.0)))
            return f"Objective: {short_name} {elapsed:0.1f}/{target:0.1f}s"
        if objective_key == "kill_quota":
            target = max(1, int(state.get("target_kills", 1)))
            return f"Objective: {short_name} {max(0, kills_delta)}/{target}"
        if objective_key == "no_hit_window":
            elapsed = float(state.get("elapsed_seconds", 0.0))
            target = max(0.1, float(state.get("target_seconds", 1.0)))
            return f"Objective: {short_name} {elapsed:0.1f}/{target:0.1f}s"
        if objective_key == "elite_hunt":
            target = max(1, int(state.get("target_elites", 1)))
            return f"Objective: {short_name} {int(getattr(self, 'objective_elite_kills', 0))}/{target}"
        if objective_key == "ammo_discipline":
            target = max(1, int(state.get("target_kills", 1)))
            budget = max(1, int(state.get("shot_budget", 1)))
            return f"Objective: {short_name} K {max(0, kills_delta)}/{target} | S {max(0, shots_delta)}/{budget}"
        return f"Objective: {short_name}"

    def wave_rule_label(self) -> str:
        """Return concise current wave-rule HUD label."""
        manager = getattr(self, "wave_manager", None)
        if manager is not None and hasattr(manager, "is_intermission") and bool(manager.is_intermission()):
            return ""

        if str(getattr(self, "active_wave_kind", "standard")) == "objective":
            return self.objective_progress_label()

        boss_archetype = str(getattr(self, "active_boss_archetype", "") or "")
        if boss_archetype:
            return self.boss_counter_hint(boss_archetype)

        mutator_key = str(getattr(self, "active_wave_mutator", "") or "")
        mutator = MUTATOR_DEFINITIONS.get(mutator_key)
        twist_key = str(getattr(self, "active_wave_twist", "") or "")
        twist_label = self.wave_twist_label(twist_key)
        if mutator:
            mutator_label = str(mutator.get("hud", ""))
            if twist_label:
                return f"{mutator_label} | Event: {twist_label}"
            return mutator_label
        if twist_label:
            return f"Event: {twist_label}"
        return ""

    def fail_objective_wave(self, reason: str) -> None:
        """Fail active objective and immediately end run."""
        if bool(getattr(self, "objective_failed", False)):
            return
        self.objective_failed = True
        self.objective_failure_message = str(reason)
        self.armory_open = False
        self.mutation_drawer_open = False
        self.perk_choice_open = False
        self.pause_open = False
        self.flush_pending_coins(force=True)
        self.persist_result()
        self.state = GameState.GAME_OVER

    def update_objective_wave(self, dt: float) -> None:
        """Evaluate objective progress/success/failure for active objective waves."""
        if str(getattr(self, "active_wave_kind", "standard")) != "objective":
            return
        if bool(getattr(self.wave_manager, "is_intermission", lambda: False)()):
            return

        objective_key = str(getattr(self, "active_wave_objective", "") or "")
        state = dict(getattr(self, "objective_state", {}))
        kills_delta = int(getattr(self, "kills", 0)) - int(getattr(self, "objective_wave_start_kills", 0))
        shots_delta = int(getattr(self, "total_shots_fired", 0)) - int(getattr(self, "objective_wave_start_shots", 0))
        exhausted = self.objective_spawn_exhausted()

        if objective_key == "survive_timer":
            elapsed = float(state.get("elapsed_seconds", 0.0)) + max(0.0, float(dt))
            target = max(0.1, float(state.get("target_seconds", 1.0)))
            state["elapsed_seconds"] = elapsed
            self.objective_state = state
            if elapsed >= target:
                self.wave_manager.complete_objective_wave()
        elif objective_key == "kill_quota":
            target = max(1, int(state.get("target_kills", 1)))
            if kills_delta >= target:
                self.wave_manager.complete_objective_wave()
            elif exhausted:
                self.fail_objective_wave("Objective failed: kill quota missed.")
        elif objective_key == "no_hit_window":
            if bool(getattr(self, "player_took_damage_this_frame", False)):
                self.fail_objective_wave("Objective failed: no-hit window broken.")
                return
            elapsed = float(state.get("elapsed_seconds", 0.0)) + max(0.0, float(dt))
            target = max(0.1, float(state.get("target_seconds", 1.0)))
            state["elapsed_seconds"] = elapsed
            self.objective_state = state
            if elapsed >= target:
                self.wave_manager.complete_objective_wave()
        elif objective_key == "elite_hunt":
            target = max(1, int(state.get("target_elites", 1)))
            if int(getattr(self, "objective_elite_kills", 0)) >= target:
                self.wave_manager.complete_objective_wave()
            elif exhausted:
                self.fail_objective_wave("Objective failed: elite hunt incomplete.")
        elif objective_key == "ammo_discipline":
            target = max(1, int(state.get("target_kills", 1)))
            budget = max(1, int(state.get("shot_budget", 1)))
            if kills_delta >= target:
                self.wave_manager.complete_objective_wave()
            elif shots_delta > budget:
                self.fail_objective_wave("Objective failed: ammo discipline exceeded shot budget.")
            elif exhausted:
                self.fail_objective_wave("Objective failed: ammo discipline quota missed.")

    def elite_spawn_share_for_wave(self, wave_number: int | None = None) -> float:
        """Return deterministic elite promotion chance for current wave."""
        wave = max(1, int(getattr(self.wave_manager, "current_wave", 1) if wave_number is None else wave_number))
        if wave < 6:
            base_share = 0.0
        else:
            base_share = min(0.82, 0.12 + (wave - 6) * 0.075)

        if str(getattr(self, "active_wave_objective", "")) == "elite_hunt":
            base_share = max(base_share, 0.62)

        base_share += float(getattr(self, "wave_mutator_elite_bonus", 0.0))
        if str(getattr(self, "active_wave_mutator", "")) == "fortified_horde":
            base_share += 0.05
        if str(getattr(self, "active_wave_twist", "")) == "elite_surge":
            base_share += 0.14
        return max(0.0, min(0.9, base_share))

    def promote_zombie_to_elite(self, zombie: Zombie) -> None:
        """Promote one spawned zombie into elite variant."""
        if bool(getattr(zombie, "is_elite", False)):
            return
        zombie.is_elite = True
        zombie.max_health = max(1, int(round(zombie.max_health * 1.65)))
        zombie.health = max(zombie.health, zombie.max_health)
        zombie.base_speed *= 1.14
        zombie.speed = zombie.base_speed
        zombie.damage = max(1, int(round(zombie.damage * 1.25)))
        zombie.score_value = max(1, int(round(zombie.score_value * 1.7)))
        zombie.coin_value = max(1, int(round(zombie.coin_value * 1.6)))
        base = tuple(int(channel) for channel in zombie.color)
        zombie.color = (
            min(255, int(base[0] * 0.72 + 118)),
            min(255, int(base[1] * 0.56 + 80)),
            min(255, int(base[2] * 0.46 + 94)),
        )

    def apply_wave_modifiers_to_zombie(self, zombie: Zombie) -> None:
        """Apply active mutator and elite-share tuning to spawned zombie."""
        # Apply wave-level multipliers before archetype-specific overrides.
        zombie.base_speed *= float(getattr(self, "wave_mutator_enemy_speed_mult", 1.0))
        zombie.speed = zombie.base_speed
        zombie.max_health = max(
            1,
            int(round(zombie.max_health * float(getattr(self, "wave_mutator_enemy_health_mult", 1.0)))),
        )
        zombie.health = zombie.max_health
        zombie.damage = max(1, int(round(zombie.damage * float(getattr(self, "wave_mutator_enemy_damage_mult", 1.0)))))
        if zombie.kind.name == "BOSS":
            # Boss archetype is resolved from active runtime or wave manager fallback.
            archetype = str(getattr(self, "active_boss_archetype", "") or "")
            if not archetype:
                manager = getattr(self, "wave_manager", None)
                archetype = str(getattr(manager, "active_boss_archetype", "") or "")
            zombie.set_boss_archetype(archetype or BossArchetype.WARDEN.value)
            return
        # Elite promotion is skipped for bosses and rolled on normal enemies.
        if random.random() < self.elite_spawn_share_for_wave():
            self.promote_zombie_to_elite(zombie)

    def spawn_boss_escorts(self, boss: Zombie) -> None:
        """Spawn commander-call escorts around active boss."""
        phase = max(1, int(getattr(boss, "boss_phase", 1)))
        base_count = BOSS_ESCORT_BASE_COUNT + (phase - 1)
        count_scale = max(0.5, float(getattr(boss, "boss_escort_count_scale", 1.0)))
        escort_count = max(1, int(round(base_count * count_scale)))
        archetype = str(getattr(boss, "boss_archetype", "") or "")
        # Broodlord heavily prefers runner escorts, others use mixed scaling.
        if archetype == BossArchetype.BROODLORD.value:
            runner_weight = 0.90
            tank_weight = 0.10
        else:
            runner_weight = 0.82 - (phase - 1) * 0.06 + float(getattr(boss, "boss_escort_runner_bias", 0.0))
            runner_weight = max(0.58, min(0.90, runner_weight))
            tank_weight = 1.0 - runner_weight
        for _ in range(escort_count):
            escort_kind = random.choices(
                [ZombieType.RUNNER, ZombieType.TANK],
                weights=[runner_weight, tank_weight],
                k=1,
            )[0]

            angle = random.uniform(0.0, 360.0)
            radius = random.uniform(110.0, 190.0)
            offset = pygame.Vector2(radius, 0).rotate(angle)
            # Place escorts around boss while clamping to world bounds.
            spawn_position = boss.position + offset
            spawn_position.x = max(self.world_rect.left + 24, min(self.world_rect.right - 24, spawn_position.x))
            spawn_position.y = max(self.world_rect.top + 24, min(self.world_rect.bottom - 24, spawn_position.y))

            escort = Zombie(spawn_position.x, spawn_position.y, escort_kind)
            self.apply_wave_modifiers_to_zombie(escort)
            self.zombies.append(escort)

    def _apply_special_damage_to_player(
        self,
        raw_damage: int,
        *,
        hit_timer_scale: float,
        knockback_source: pygame.Vector2 | None = None,
        knockback_distance: float = 0.0,
    ) -> None:
        """Apply one boss-special damage packet with shared survivability rules."""
        if raw_damage <= 0:
            return
        scaled_damage = max(1, int(round(raw_damage * self.combined_incoming_damage_multiplier())))
        projected_health = self.player.health - scaled_damage
        if projected_health <= 0 and self.last_stand_enabled and self.last_stand_available:
            self.player.health = min(self.player.max_health, max(1, 20))
            self.last_stand_available = False
        else:
            self.player.take_damage(scaled_damage)
        self.player_took_damage_this_frame = True
        self.player_hit_timer = max(self.player_hit_timer, self.player_hit_cooldown * max(0.0, float(hit_timer_scale)))
        if knockback_source is None or knockback_distance <= 0.0:
            return
        knockback = self.player.position - knockback_source
        if knockback.length_squared() > 0.0:
            self.player.position += knockback.normalize() * float(knockback_distance)

    def update_boss_hazards(self, dt: float) -> None:
        """Advance active boss hazard zones and apply timed damage ticks."""
        hazards = list(getattr(self, "active_boss_hazards", []))
        if not hazards:
            return
        updated: list[dict[str, object]] = []
        for hazard in hazards:
            center = pygame.Vector2(hazard.get("center", self.player.position))
            radius = max(0.0, float(hazard.get("radius", 0.0)))
            damage = max(0, int(hazard.get("damage", 0)))
            arm_time = max(0.0, float(hazard.get("arm_time", 0.0)) - dt)
            active_time = max(0.0, float(hazard.get("active_time", 0.0)))
            tick_interval = max(0.05, float(hazard.get("tick_interval", 0.30)))
            tick_timer = max(0.0, float(hazard.get("tick_timer", 0.0)))

            if arm_time > 0.0:
                hazard["arm_time"] = arm_time
                hazard["active_time"] = active_time
                hazard["tick_interval"] = tick_interval
                hazard["tick_timer"] = tick_timer
                hazard["center"] = center
                hazard["radius"] = radius
                hazard["damage"] = damage
                updated.append(hazard)
                continue

            active_time = max(0.0, active_time - dt)
            tick_timer = max(0.0, tick_timer - dt)
            if active_time > 0.0 and tick_timer == 0.0:
                if self.player.position.distance_to(center) <= radius:
                    self._apply_special_damage_to_player(damage, hit_timer_scale=0.45)
                tick_timer = tick_interval

            if active_time <= 0.0:
                continue

            hazard["arm_time"] = 0.0
            hazard["active_time"] = active_time
            hazard["tick_interval"] = tick_interval
            hazard["tick_timer"] = tick_timer
            hazard["center"] = center
            hazard["radius"] = radius
            hazard["damage"] = damage
            updated.append(hazard)

        self.active_boss_hazards = updated

    def process_boss_special_attacks(self) -> None:
        """Resolve boss-specific commander calls and slam pulses."""
        if not self.zombies:
            return

        for zombie in list(self.zombies):
            if not hasattr(zombie, "kind") or zombie.kind != ZombieType.BOSS:
                continue

            if hasattr(zombie, "consume_commander_call") and zombie.consume_commander_call():
                # Commander call emits a support wave once when consumed.
                self.spawn_boss_escorts(zombie)

            zone_payload = None
            if hasattr(zombie, "consume_zone_cast"):
                zone_payload = zombie.consume_zone_cast()
            if zone_payload is not None:
                centers, zone_radius, zone_damage, arm_time, active_time, tick_interval = zone_payload
                if not hasattr(self, "active_boss_hazards"):
                    self.active_boss_hazards = []
                for center in centers:
                    clamped_center = pygame.Vector2(center)
                    clamped_center.x = max(self.world_rect.left + 24, min(self.world_rect.right - 24, clamped_center.x))
                    clamped_center.y = max(self.world_rect.top + 24, min(self.world_rect.bottom - 24, clamped_center.y))
                    self.active_boss_hazards.append(
                        {
                            "center": clamped_center,
                            "radius": float(zone_radius),
                            "damage": int(zone_damage),
                            "arm_time": float(arm_time),
                            "active_time": float(active_time),
                            "tick_interval": float(tick_interval),
                            "tick_timer": 0.0,
                        }
                    )

            slam_payload = None
            if hasattr(zombie, "consume_slam_pulse"):
                slam_payload = zombie.consume_slam_pulse()
            if slam_payload is not None:
                slam_radius, slam_damage = slam_payload
                if slam_radius > 0.0 and slam_damage > 0:
                    # Evaluate slam radius against current player position at impact time.
                    impact_center = pygame.Vector2(zombie.position)
                    player_offset = self.player.position - impact_center
                    player_distance = player_offset.length()
                    if player_distance <= float(slam_radius):
                        core_radius = float(getattr(zombie, "boss_leap_core_radius", 0.0))
                        if core_radius <= 0.0:
                            # Fallback ensures compatibility with legacy slam payloads.
                            core_radius = float(slam_radius) * BOSS_LEAP_CORE_RATIO

                        dodge_success = False
                        if player_distance > core_radius:
                            # Outer ring is dodgeable only with enough movement, lateral sidestep, and speed.
                            commit_player_pos = pygame.Vector2(getattr(zombie, "boss_leap_commit_player_pos", self.player.position))
                            moved_since_commit = self.player.position.distance_to(commit_player_pos)
                            leap_axis = pygame.Vector2(getattr(zombie, "boss_leap_axis", pygame.Vector2()))
                            if leap_axis.length_squared() > 0.0:
                                leap_axis = leap_axis.normalize()
                                lateral_offset = abs((player_offset.x * leap_axis.y) - (player_offset.y * leap_axis.x))
                            else:
                                lateral_offset = 0.0
                            player_velocity = pygame.Vector2(getattr(self, "player_velocity", pygame.Vector2()))
                            player_speed = player_velocity.length()
                            # Dodge requires all three checks to enforce skillful movement.
                            dodge_success = (
                                moved_since_commit >= BOSS_LEAP_DODGE_MIN_COMMIT_DISTANCE
                                and lateral_offset >= BOSS_LEAP_DODGE_MIN_LATERAL_DISTANCE
                                and player_speed >= BOSS_LEAP_DODGE_MIN_PLAYER_SPEED
                            )
                        if not dodge_success:
                            # Slam keeps original hit timing and knockback pressure.
                            self._apply_special_damage_to_player(
                                slam_damage,
                                hit_timer_scale=0.6,
                                knockback_source=pygame.Vector2(zombie.position),
                                knockback_distance=26.0,
                            )

            ambush_payload = None
            if hasattr(zombie, "consume_ambush_pulse"):
                ambush_payload = zombie.consume_ambush_pulse()
            if ambush_payload is not None:
                origin, direction, length, half_width, ambush_damage, lockout = ambush_payload
                strike_dir = pygame.Vector2(direction)
                if strike_dir.length_squared() == 0.0:
                    strike_dir = pygame.Vector2(1, 0)
                strike_dir = strike_dir.normalize()
                to_player = self.player.position - pygame.Vector2(origin)
                forward = to_player.dot(strike_dir)
                lateral = abs((to_player.x * strike_dir.y) - (to_player.y * strike_dir.x))
                if 0.0 <= forward <= float(length) and lateral <= float(half_width):
                    self._apply_special_damage_to_player(
                        ambush_damage,
                        hit_timer_scale=0.6,
                    )
                self.boss_contact_damage_lockout_timer = max(
                    float(getattr(self, "boss_contact_damage_lockout_timer", 0.0)),
                    float(lockout if lockout > 0.0 else BOSS_AMBUSH_CONTACT_LOCKOUT),
                )

    def update_wave_twist(self, dt: float) -> None:
        """Run active wave mini-event logic."""
        self.safe_zone_pulse_flash_timer = max(0.0, float(getattr(self, "safe_zone_pulse_flash_timer", 0.0)) - dt)
        if str(getattr(self, "active_wave_twist", "")) != "safe_zone_pulse":
            return
        if bool(getattr(self.wave_manager, "is_intermission", lambda: False)()):
            return

        self.wave_twist_pulse_timer = max(0.0, float(getattr(self, "wave_twist_pulse_timer", 0.0)) - dt)
        if self.wave_twist_pulse_timer > 0.0:
            return

        self.wave_twist_pulse_timer = 6.5
        self.safe_zone_pulse_flash_timer = 0.34
        pulse_radius = 170.0
        # Safe-zone pulse pushes nearby zombies outward from player center.
        for zombie in self.zombies:
            offset = zombie.position - self.player.position
            distance = offset.length()
            if distance <= 0.0 or distance > pulse_radius:
                continue
            strength = (pulse_radius - distance) / pulse_radius
            push_distance = 52.0 * (0.55 + strength)
            if zombie.kind == ZombieType.BOSS:
                # Bosses are intentionally less affected by pulse control.
                push_distance *= 0.42
            zombie.position += offset.normalize() * push_distance
            zombie.position.x = max(self.world_rect.left + 24, min(self.world_rect.right - 24, zombie.position.x))
            zombie.position.y = max(self.world_rect.top + 24, min(self.world_rect.bottom - 24, zombie.position.y))

    def update_no_hit_streak(self, dt: float) -> None:
        """Grant periodic scrap burst when player avoids damage for a duration."""
        if bool(getattr(self.wave_manager, "is_intermission", lambda: False)()):
            self.no_hit_streak_seconds = 0.0
            return
        if bool(getattr(self, "player_took_damage_this_frame", False)):
            self.no_hit_streak_seconds = 0.0
            return

        self.no_hit_streak_seconds = float(getattr(self, "no_hit_streak_seconds", 0.0)) + max(0.0, dt)
        threshold = float(NO_HIT_STREAK_THRESHOLD)
        if self.no_hit_streak_seconds < threshold:
            return

        wave = max(1, int(getattr(self.wave_manager, "current_wave", 1)))
        bonus = 16 + wave * 2
        while self.no_hit_streak_seconds >= threshold:
            self.award_run_scrap(bonus)
            self.no_hit_streak_seconds -= threshold

    def persist_result(self) -> None:
        """Save final run to JSON fallback and SQLite leaderboard."""
        if self.score_saved:
            return

        self.flush_pending_coins(force=True)
        clean_name = self.player_name.strip() if self.is_authenticated() else "Guest"
        if not clean_name:
            clean_name = "Guest"
        storage.save_score(clean_name, self.score)
        database.save_match_result(clean_name, self.score, self.survival_time)
        self.leaderboard_lines = self.get_leaderboard_lines()
        self.score_saved = True

    def run(self) -> None:
        """Start the perpetual game loop."""
        while True:
            dt = self.clock.tick(60) / 1000
            self.handle_events()
            self.update(dt)
            self.render()

    def clamp_window_size(self, size: tuple[int, int]) -> tuple[int, int]:
        """Clamp requested window size to the minimum supported resolution."""
        width = max(self.min_window_size[0], int(size[0]))
        height = max(self.min_window_size[1], int(size[1]))
        return width, height

    def apply_display_mode(self, *, fullscreen: bool, size: tuple[int, int] | None = None) -> None:
        """Switch between fullscreen and resizable window display modes."""
        if fullscreen:
            self.is_fullscreen = True
            self.display_surface = pygame.display.set_mode((0, 0), pygame.FULLSCREEN)
        else:
            requested_size = self.windowed_size if size is None else size
            clamped_size = self.clamp_window_size(requested_size)
            self.windowed_size = clamped_size
            self.is_fullscreen = False
            self.display_surface = pygame.display.set_mode(clamped_size, pygame.RESIZABLE)

        self.recalculate_viewport()

    def recalculate_viewport(self) -> None:
        """Recompute letterboxed viewport rectangle and scale factor."""
        if self.display_surface is None:
            return

        display_width, display_height = self.display_surface.get_size()
        if display_width <= 0 or display_height <= 0:
            self.viewport_rect = pygame.Rect(0, 0, self.width, self.height)
            self.viewport_scale = 1.0
            return

        scale = min(display_width / self.width, display_height / self.height)
        scaled_width = max(1, int(self.width * scale))
        scaled_height = max(1, int(self.height * scale))
        viewport_x = (display_width - scaled_width) // 2
        viewport_y = (display_height - scaled_height) // 2

        self.viewport_rect = pygame.Rect(viewport_x, viewport_y, scaled_width, scaled_height)
        self.viewport_scale = scale

    def toggle_fullscreen(self) -> None:
        """Toggle fullscreen mode while preserving last windowed size."""
        if self.is_fullscreen:
            self.apply_display_mode(fullscreen=False, size=self.windowed_size)
            return

        if self.display_surface is not None:
            self.windowed_size = self.clamp_window_size(self.display_surface.get_size())

        self.apply_display_mode(fullscreen=True)

    def window_to_logical(self, pos: tuple[int, int], clamp: bool = False) -> pygame.Vector2 | None:
        """Convert display-space coordinates to logical game-space coordinates."""
        if self.viewport_scale <= 0:
            return None

        left = float(self.viewport_rect.left)
        top = float(self.viewport_rect.top)
        right = float(self.viewport_rect.right)
        bottom = float(self.viewport_rect.bottom)

        x = float(pos[0])
        y = float(pos[1])

        if clamp:
            x = max(left, min(x, right - 1))
            y = max(top, min(y, bottom - 1))
        elif not (left <= x < right and top <= y < bottom):
            return None

        logical_x = (x - left) / self.viewport_scale
        logical_y = (y - top) / self.viewport_scale
        logical_x = max(0.0, min(logical_x, self.width - 1))
        logical_y = max(0.0, min(logical_y, self.height - 1))
        return pygame.Vector2(logical_x, logical_y)

    def get_mouse_logical_pos(self, clamp: bool = True) -> pygame.Vector2 | None:
        """Return current mouse position in logical game coordinates."""
        return self.window_to_logical(pygame.mouse.get_pos(), clamp=clamp)

    def overlay_pause_active(self) -> bool:
        """Pause progression when intermission overlays are open."""
        if bool(getattr(self, "pause_open", False)):
            return True

        manager = getattr(self, "wave_manager", None)
        if manager is None or not hasattr(manager, "is_intermission"):
            return False
        return bool(manager.is_intermission()) and (
            bool(getattr(self, "armory_open", False)) or bool(getattr(self, "perk_choice_open", False))
        )

    def armory_button_rect(self) -> pygame.Rect:
        """Return HUD rectangle used for intermission armory button click handling."""
        return get_armory_button_rect(self.width)

    def mutation_button_rect(self) -> pygame.Rect:
        """Return HUD rectangle used for mutation drawer button click handling."""
        return get_mutation_button_rect(self.width)

    def armory_tab_rects(self) -> dict[str, pygame.Rect]:
        """Return clickable tab rectangles for armory overlay."""
        return get_armory_tab_rects(self.width)

    def pause_main_option_rects(self) -> list[pygame.Rect]:
        """Return clickable pause menu option rectangles."""
        return get_pause_main_option_rects(self.width, self.height)

    def pause_settings_option_rects(self) -> list[pygame.Rect]:
        """Return clickable pause settings option rectangles."""
        return get_pause_settings_option_rects(self.width, self.height)

    def armory_visible_row_count(self) -> int:
        """Return number of armory rows visible without scrolling."""
        return ARMORY_VISIBLE_ROWS

    def clamp_armory_scroll_offset(self, row_count: int) -> None:
        """Clamp armory scroll offset against current row count and viewport size."""
        safe_count = max(0, int(row_count))
        visible = max(1, int(self.armory_visible_row_count()))
        max_offset = max(0, safe_count - visible)
        self.armory_scroll_offset = max(0, min(int(getattr(self, "armory_scroll_offset", 0)), max_offset))

    def ensure_armory_selection_visible(self, row_count: int) -> None:
        """Keep selected armory row inside current scroll window."""
        safe_count = max(0, int(row_count))
        if safe_count <= 0:
            self.armory_selection = 0
            self.armory_scroll_offset = 0
            return

        self.armory_selection = min(max(0, int(getattr(self, "armory_selection", 0))), safe_count - 1)
        self.clamp_armory_scroll_offset(safe_count)
        visible = max(1, int(self.armory_visible_row_count()))
        offset = int(getattr(self, "armory_scroll_offset", 0))

        if self.armory_selection < offset:
            offset = self.armory_selection
        elif self.armory_selection >= offset + visible:
            offset = self.armory_selection - visible + 1

        max_offset = max(0, safe_count - visible)
        self.armory_scroll_offset = max(0, min(offset, max_offset))

    def open_pause_menu(self) -> None:
        """Open pause overlay and reset submenu cursors."""
        self.pause_open = True
        self.pause_settings_open = False
        self.pause_selection = 0
        self.pause_settings_selection = 0
        self.mutation_drawer_open = False
        self.mutation_drawer_scroll = 0

    def close_pause_menu(self) -> None:
        """Close pause overlay and return to active gameplay."""
        self.pause_open = False
        self.pause_settings_open = False
        self.pause_selection = 0
        self.pause_settings_selection = 0

    @staticmethod
    def guide_sections() -> list[dict[str, object]]:
        """Return visual guide sections and card content."""
        return [
            {
                "title": GUIDE_SECTION_TITLES[0],
                "intro": "Stay alive through escalating waves, manage ammo, and survive boss rounds.",
                "cards": [
                    {
                        "title": "Core Objective",
                        "icon": "goal",
                        "accent": (120, 196, 255),
                        "bullets": [
                            "Clear each wave and survive pressure spikes.",
                            "Boss waves arrive on progression milestones.",
                            "Intermission lets you prep with armory upgrades.",
                        ],
                    },
                    {
                        "title": "Run Flow",
                        "icon": "flow",
                        "accent": (170, 214, 255),
                        "bullets": [
                            "Fight -> collect drops -> buy upgrades.",
                            "Draft mutations every few waves.",
                            "Adapt to mutators, objectives, and wave twists.",
                        ],
                    },
                ],
            },
            {
                "title": GUIDE_SECTION_TITLES[1],
                "intro": "Keep moving, control space, and use overlays without losing awareness.",
                "cards": [
                    {
                        "title": "Movement & Combat",
                        "icon": "keys",
                        "accent": (255, 208, 132),
                        "bullets": [
                            "WASD move, mouse aim, left click fire.",
                            "R reload, Q cycle weapons, 1/2/3/0 direct swap.",
                            "Do not stand still during boss telegraphs.",
                        ],
                    },
                    {
                        "title": "Combat UI",
                        "icon": "hud",
                        "accent": (208, 226, 255),
                        "bullets": [
                            "Top-left: HP and wave pacing.",
                            "Top-right: coins, scrap, mode, quick buttons.",
                            "Bottom-right: active weapon and slot status.",
                        ],
                    },
                ],
            },
            {
                "title": GUIDE_SECTION_TITLES[2],
                "intro": "Read telegraphs early and dodge before commitment frames.",
                "cards": [
                    {
                        "title": "Warden",
                        "icon": "boss_warden",
                        "accent": (232, 120, 120),
                        "bullets": [
                            "Heavy slam pressure with wider landing ring.",
                            "Bait leap ring then strafe hard outside radius.",
                        ],
                    },
                    {
                        "title": "Ravager",
                        "icon": "boss_ravager",
                        "accent": (250, 172, 102),
                        "bullets": [
                            "Fast charge and leap commitment windows.",
                            "Angle sideways early, never backpedal straight.",
                        ],
                    },
                    {
                        "title": "Broodlord",
                        "icon": "boss_broodlord",
                        "accent": (198, 154, 246),
                        "bullets": [
                            "Spawns escort pressure during casts.",
                            "Clear summons quickly to restore dodge space.",
                        ],
                    },
                    {
                        "title": "Phantom",
                        "icon": "boss_phantom",
                        "accent": (146, 214, 255),
                        "bullets": [
                            "Frequent reposition and leap cadence.",
                            "Treat first telegraph as immediate dodge cue.",
                        ],
                    },
                    {
                        "title": "Zone Caster",
                        "icon": "boss_zone_caster",
                        "accent": (255, 198, 122),
                        "bullets": [
                            "Marks three delayed hazard zones around your path.",
                            "Rotate out during gold telegraph before red activation.",
                        ],
                    },
                    {
                        "title": "Stealth Assassin",
                        "icon": "boss_stealth_assassin",
                        "accent": (138, 236, 252),
                        "bullets": [
                            "Repositions to your flank then strikes in a lane.",
                            "Dodge sideways off the line before ambush resolves.",
                        ],
                    },
                ],
            },
            {
                "title": GUIDE_SECTION_TITLES[3],
                "intro": "Different weapons reward different pacing and positioning.",
                "cards": [
                    {
                        "title": "Pistol / Fallback",
                        "icon": "weapon:pistol",
                        "accent": (182, 204, 228),
                        "bullets": [
                            "Always available fallback slot.",
                            "Reliable when primary magazines run dry.",
                        ],
                    },
                    {
                        "title": "Burst / Auto / Shotgun / Sniper",
                        "icon": "weapon:auto_rifle",
                        "accent": (206, 224, 244),
                        "bullets": [
                            "Burst: controlled medium-range output.",
                            "Auto: sustained DPS and crowd control.",
                            "Shotgun/Sniper: high impact with strict spacing.",
                        ],
                    },
                    {
                        "title": "Ammo Discipline",
                        "icon": "ammo",
                        "accent": (255, 220, 146),
                        "bullets": [
                            "Reload before panic moments.",
                            "Use ammo cache and refill windows smartly.",
                            "Preserve heavy ammo for elites and bosses.",
                        ],
                    },
                ],
            },
            {
                "title": GUIDE_SECTION_TITLES[4],
                "intro": "Pickups are short power spikes. Use them proactively.",
                "cards": [
                    {
                        "title": "Rapid Fire / Freeze",
                        "icon": "power_temp",
                        "accent": (130, 204, 255),
                        "bullets": [
                            "Rapid Fire boosts firing cadence briefly.",
                            "Freeze slows zombies to create breathing room.",
                        ],
                    },
                    {
                        "title": "Fortify / Heal",
                        "icon": "power_defense",
                        "accent": (255, 154, 122),
                        "bullets": [
                            "Fortify reduces incoming damage.",
                            "Heal restores HP and stabilizes risky runs.",
                        ],
                    },
                    {
                        "title": "Ammo Cache / Scrap Magnet",
                        "icon": "power_resource",
                        "accent": (192, 232, 190),
                        "bullets": [
                            "Ammo Cache resolves ammo pressure instantly.",
                            "Scrap Magnet amplifies temporary scrap gains.",
                        ],
                    },
                ],
            },
            {
                "title": GUIDE_SECTION_TITLES[5],
                "intro": "Long-term run strength comes from smart upgrade sequencing.",
                "cards": [
                    {
                        "title": "Mutations & Perks",
                        "icon": "perk",
                        "accent": (180, 214, 255),
                        "bullets": [
                            "Perk drafts shape your run identity.",
                            "Balance offense, sustain, and utility scaling.",
                        ],
                    },
                    {
                        "title": "Armory Economy",
                        "icon": "economy",
                        "accent": (255, 214, 144),
                        "bullets": [
                            "Spend scrap during intermission for consistency.",
                            "Upgrade tiers stack and define power curve.",
                        ],
                    },
                    {
                        "title": "Objectives, Mutators, Wave Twists",
                        "icon": "mutator",
                        "accent": (208, 190, 250),
                        "bullets": [
                            "Wave rules can change priorities each round.",
                            "Read HUD labels and pivot strategy quickly.",
                        ],
                    },
                ],
            },
        ]

    def open_guide(self, origin: str, start_section: int = 0) -> None:
        """Open standalone guide screen from menu, pause or live gameplay."""
        sections = self.guide_sections()
        max_index = max(0, len(sections) - 1)
        safe_section = max(0, min(int(start_section), max_index))
        origin_token = str(origin or "menu").strip().lower()
        if origin_token not in {"menu", "pause", "playing_hotkey"}:
            origin_token = "menu"

        self.guide_origin = origin_token
        self.guide_section_index = safe_section
        self.guide_scroll_offset = 0
        if origin_token == "pause":
            self.close_pause_menu()
        self.state = GameState.GUIDE

    def close_guide(self) -> None:
        """Return to the state that opened the standalone guide screen."""
        origin_token = str(getattr(self, "guide_origin", "menu"))
        self.guide_scroll_offset = 0
        if origin_token == "pause":
            self.state = GameState.PLAYING
            self.open_pause_menu()
            return
        if origin_token == "playing_hotkey":
            self.state = GameState.PLAYING
            return
        self.state = GameState.MENU

    def toggle_mutation_drawer(self) -> None:
        """Toggle left-side mutations drawer when no blocking overlay is active."""
        if bool(getattr(self, "pause_open", False)) or bool(getattr(self, "perk_choice_open", False)) or bool(getattr(self, "armory_open", False)):
            return
        self.mutation_drawer_open = not bool(getattr(self, "mutation_drawer_open", False))
        if self.mutation_drawer_open:
            self.mutation_drawer_scroll = 0
        else:
            self.mutation_drawer_scroll = 0

    def activate_pause_selection(self, index: int) -> None:
        """Execute pause menu action for selected row."""
        safe_index = min(max(0, int(index)), 3)
        self.pause_selection = safe_index

        if safe_index == 0:
            self.close_pause_menu()
            return
        if safe_index == 1:
            self.open_guide("pause")
            return
        if safe_index == 2:
            self.pause_settings_open = True
            self.pause_settings_selection = 0
            return

        self.flush_pending_coins(force=True)
        self.armory_open = False
        self.perk_choice_open = False
        self.armory_message = ""
        self.armory_message_timer = 0.0
        self.mutation_drawer_open = False
        self.mutation_drawer_scroll = 0
        self.close_pause_menu()
        self.state = GameState.MENU

    def activate_pause_settings_selection(self, index: int) -> None:
        """Execute pause settings action for selected row."""
        safe_index = min(max(0, int(index)), 1)
        self.pause_settings_selection = safe_index
        if safe_index == 0:
            self.toggle_fullscreen()
            return
        self.pause_settings_open = False
        self.pause_settings_selection = 0

    def handle_pause_event(
        self,
        event: pygame.event.Event,
        *,
        mouse_pos: pygame.Vector2 | None = None,
    ) -> None:
        """Handle input while runtime pause overlay is open."""
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_ESCAPE:
                if self.pause_settings_open:
                    self.pause_settings_open = False
                    self.pause_settings_selection = 0
                else:
                    self.close_pause_menu()
                return

            if self.pause_settings_open:
                if event.key in (pygame.K_UP, pygame.K_w):
                    self.pause_settings_selection = (int(getattr(self, "pause_settings_selection", 0)) - 1) % 2
                    return
                if event.key in (pygame.K_DOWN, pygame.K_s):
                    self.pause_settings_selection = (int(getattr(self, "pause_settings_selection", 0)) + 1) % 2
                    return
                if event.key in (pygame.K_RETURN, pygame.K_SPACE):
                    self.activate_pause_settings_selection(int(getattr(self, "pause_settings_selection", 0)))
                    return
                return

            if event.key in (pygame.K_UP, pygame.K_w):
                self.pause_selection = (int(getattr(self, "pause_selection", 0)) - 1) % 4
                return
            if event.key in (pygame.K_DOWN, pygame.K_s):
                self.pause_selection = (int(getattr(self, "pause_selection", 0)) + 1) % 4
                return
            if event.key in (pygame.K_RETURN, pygame.K_SPACE):
                self.activate_pause_selection(int(getattr(self, "pause_selection", 0)))
                return

        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            click_pos = mouse_pos
            if click_pos is None:
                click_pos = self.window_to_logical((int(event.pos[0]), int(event.pos[1])), clamp=False)
            if click_pos is None:
                return

            if self.pause_settings_open:
                for idx, rect in enumerate(self.pause_settings_option_rects()):
                    if rect.collidepoint(click_pos):
                        self.pause_settings_selection = idx
                        self.activate_pause_settings_selection(idx)
                        return
                return

            for idx, rect in enumerate(self.pause_main_option_rects()):
                if rect.collidepoint(click_pos):
                    self.pause_selection = idx
                    self.activate_pause_selection(idx)
                    return

    def visual_mode_label(self) -> str:
        """Return compact HUD label of current visual mode."""
        mode = str(getattr(self, "visual_mode", "night")).lower()
        mode_name = "Night"
        if mode == "day":
            mode_name = "Day"
        elif mode == "blackout":
            mode_name = "Blackout"
        return f"Visual Mode: {mode_name}"

    @staticmethod
    def visual_mode_options() -> list[str]:
        """Return display labels for visual mode picker options."""
        return ["Night", "Day", "Blackout"]

    def open_visual_mode_select(self) -> None:
        """Open visual mode picker before starting a run."""
        self.visual_mode_selection = 0
        self.state = GameState.VISUAL_MODE_SELECT

    def start_run_with_selected_visual_mode(self) -> None:
        """Apply selected visual mode and start a fresh run."""
        selection = max(0, min(int(getattr(self, "visual_mode_selection", 0)), len(VISUAL_MODE_ORDER) - 1))
        self.visual_mode = VISUAL_MODE_ORDER[selection]
        self.reset_game()
        self.state = GameState.PLAYING

    def handle_visual_mode_select_event(self, event: pygame.event.Event) -> None:
        """Handle keyboard and mouse input in visual mode picker."""
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_ESCAPE:
                self.state = GameState.MENU
                return
            if event.key in (pygame.K_UP, pygame.K_w):
                self.visual_mode_selection = (int(getattr(self, "visual_mode_selection", 0)) - 1) % len(VISUAL_MODE_ORDER)
                return
            if event.key in (pygame.K_DOWN, pygame.K_s):
                self.visual_mode_selection = (int(getattr(self, "visual_mode_selection", 0)) + 1) % len(VISUAL_MODE_ORDER)
                return
            if event.key in (pygame.K_RETURN, pygame.K_SPACE):
                self.start_run_with_selected_visual_mode()
                return

        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            mouse_pos = self.window_to_logical((int(event.pos[0]), int(event.pos[1])), clamp=False)
            if mouse_pos is None:
                return
            for index, rect in enumerate(get_visual_mode_option_rects(self.width, self.height)):
                if rect.collidepoint(mouse_pos):
                    self.visual_mode_selection = index
                    self.start_run_with_selected_visual_mode()
                    return

    def handle_events(self) -> None:
        """Route pygame events by active game state."""
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                self.quit_game()
                continue

            if event.type == pygame.KEYDOWN:
                alt_enter = event.key == pygame.K_RETURN and bool(getattr(event, "mod", 0) & pygame.KMOD_ALT)
                if event.key == pygame.K_F11 or alt_enter:
                    self.toggle_fullscreen()
                    continue

            if event.type == pygame.VIDEORESIZE:
                if self.is_fullscreen:
                    continue

                requested = (int(event.w), int(event.h))
                self.apply_display_mode(fullscreen=False, size=self.clamp_window_size(requested))
                continue

            if event.type == pygame.WINDOWSIZECHANGED:
                if not self.is_fullscreen and self.display_surface is not None:
                    self.windowed_size = self.clamp_window_size(self.display_surface.get_size())
                self.recalculate_viewport()
                continue

            if self.state == GameState.MENU:
                self.handle_menu_event(event)
            elif self.state == GameState.VISUAL_MODE_SELECT:
                self.handle_visual_mode_select_event(event)
            elif self.state == GameState.SHOP:
                self.handle_shop_event(event)
            elif self.state == GameState.LOGIN:
                self.handle_login_event(event)
            elif self.state == GameState.PLAYING:
                self.handle_playing_event(event)
            elif self.state == GameState.GUIDE:
                self.handle_guide_event(event)
            elif self.state == GameState.GAME_OVER:
                self.handle_game_over_event(event)

    def _menu_option_rects(self) -> list[pygame.Rect]:
        """Return clickable rectangles for menu options."""
        return get_menu_option_rects(
            self.width,
            self.height,
            has_message=bool(getattr(self, "menu_message", "")),
            leaderboard_count=len(getattr(self, "leaderboard_lines", [])),
        )

    def handle_menu_event(self, event: pygame.event.Event) -> None:
        """Handle keyboard and mouse input in the main menu."""
        if event.type == pygame.KEYDOWN:
            if event.key in (pygame.K_UP, pygame.K_w):
                self.menu_selection = (self.menu_selection - 1) % 5
                self.menu_message = ""
            elif event.key in (pygame.K_DOWN, pygame.K_s):
                self.menu_selection = (self.menu_selection + 1) % 5
                self.menu_message = ""
            elif event.key in (pygame.K_RETURN, pygame.K_SPACE):
                self.activate_menu_selection()
        elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            mouse_pos = self.window_to_logical((int(event.pos[0]), int(event.pos[1])), clamp=False)
            if mouse_pos is None:
                return
            for index, rect in enumerate(self._menu_option_rects()):
                if rect.collidepoint(mouse_pos):
                    self.menu_selection = index
                    self.menu_message = ""
                    self.activate_menu_selection()
                    break

    def activate_menu_selection(self) -> None:
        """Run action bound to currently selected menu option."""
        if self.menu_selection == 0:
            self.open_visual_mode_select()
        elif self.menu_selection == 1:
            if self.is_authenticated():
                self.logout_profile()
                self.menu_message = "Logged out. Playing as Guest."
            else:
                self.open_login_screen()
        elif self.menu_selection == 2:
            if not self.is_authenticated():
                self.menu_message = "Login required for Skins Shop."
                return

            self.refresh_shop_items()
            self.shop_selection = 0
            self.menu_message = ""
            self.state = GameState.SHOP
        elif self.menu_selection == 3:
            self.open_guide("menu", start_section=0)
        else:
            self.quit_game()

    def handle_guide_event(self, event: pygame.event.Event) -> None:
        """Handle keyboard and mouse navigation inside standalone guide screen."""
        sections = self.guide_sections()
        section_count = len(sections)
        if section_count <= 0:
            if event.type == pygame.KEYDOWN and event.key in (pygame.K_ESCAPE, pygame.K_BACKSPACE):
                self.close_guide()
            return

        if event.type == pygame.KEYDOWN:
            if event.key in (pygame.K_ESCAPE, pygame.K_BACKSPACE):
                self.close_guide()
                return
            if event.key in (pygame.K_UP, pygame.K_w):
                self.guide_section_index = (int(getattr(self, "guide_section_index", 0)) - 1) % section_count
                self.guide_scroll_offset = 0
                return
            if event.key in (pygame.K_DOWN, pygame.K_s):
                self.guide_section_index = (int(getattr(self, "guide_section_index", 0)) + 1) % section_count
                self.guide_scroll_offset = 0
                return
            if event.key in (pygame.K_RETURN, pygame.K_SPACE):
                self.guide_scroll_offset = 0
                return
            if event.key == pygame.K_PAGEUP:
                self.guide_scroll_offset = max(0, int(getattr(self, "guide_scroll_offset", 0)) - 96)
                return
            if event.key == pygame.K_PAGEDOWN:
                self.guide_scroll_offset = int(getattr(self, "guide_scroll_offset", 0)) + 96
                return
            if event.key == pygame.K_HOME:
                self.guide_scroll_offset = 0
                return

        if event.type == pygame.MOUSEWHEEL:
            current = int(getattr(self, "guide_scroll_offset", 0))
            self.guide_scroll_offset = max(0, current - int(getattr(event, "y", 0)) * 36)
            return

        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            mouse_pos = self.window_to_logical((int(event.pos[0]), int(event.pos[1])), clamp=False)
            if mouse_pos is None:
                return

            for idx, rect in enumerate(get_howto_category_rects(self.width, self.height, section_count)):
                if rect.collidepoint(mouse_pos):
                    self.guide_section_index = idx
                    self.guide_scroll_offset = 0
                    return

    def handle_login_event(self, event: pygame.event.Event) -> None:
        """Handle account login form typing, field focus and submit actions."""
        if event.type != pygame.KEYDOWN:
            return

        if event.key == pygame.K_ESCAPE:
            self.login_password_input = ""
            self.login_error = ""
            self.login_active_field = "username"
            self.state = GameState.MENU
            return

        if event.key in (pygame.K_TAB, pygame.K_UP, pygame.K_DOWN):
            self.login_active_field = "password" if self.login_active_field == "username" else "username"
            return

        if event.key == pygame.K_RETURN:
            self.attempt_login()
            return

        if event.key == pygame.K_BACKSPACE:
            if self.login_active_field == "username":
                self.login_username_input = self.login_username_input[:-1]
            else:
                self.login_password_input = self.login_password_input[:-1]
            return

        if not event.unicode or not event.unicode.isprintable():
            return

        self.login_error = ""
        if self.login_active_field == "username":
            if len(self.login_username_input) < 30:
                self.login_username_input += event.unicode
        elif len(self.login_password_input) < 64:
            self.login_password_input += event.unicode

    def _shop_row_rect(self, row_index: int) -> pygame.Rect:
        """Return clickable rectangle for one shop row index."""
        row_top = 210
        row_height = 52
        rect = pygame.Rect(self.width // 2 - 220, row_top + row_index * row_height - 8, 460, 40)
        return rect

    def handle_shop_event(self, event: pygame.event.Event) -> None:
        """Handle keyboard and mouse input in the skin shop."""
        row_count = len(self.shop_items) + 1

        if event.type == pygame.KEYDOWN:
            if event.key in (pygame.K_ESCAPE, pygame.K_BACKSPACE):
                self.state = GameState.MENU
                return

            if event.key in (pygame.K_UP, pygame.K_w):
                self.shop_selection = (self.shop_selection - 1) % row_count
            elif event.key in (pygame.K_DOWN, pygame.K_s):
                self.shop_selection = (self.shop_selection + 1) % row_count
            elif event.key in (pygame.K_RETURN, pygame.K_SPACE):
                self.activate_shop_selection()

        elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            mouse_pos = self.window_to_logical((int(event.pos[0]), int(event.pos[1])), clamp=False)
            if mouse_pos is None:
                return
            for index in range(row_count):
                if self._shop_row_rect(index).collidepoint(mouse_pos):
                    self.shop_selection = index
                    self.activate_shop_selection()
                    break

    def activate_shop_selection(self) -> None:
        """Buy, equip or exit based on current shop selection."""
        if self.player_profile_id is None:
            self.state = GameState.MENU
            return

        if self.shop_selection >= len(self.shop_items):
            self.state = GameState.MENU
            return

        item = self.shop_items[self.shop_selection]
        skin_key = str(item["skin_key"])

        if bool(item["owned"]):
            database.select_skin(self.player_profile_id, skin_key)
        else:
            database.unlock_skin(self.player_profile_id, skin_key)

        self.load_player_profile(self.player_name)
        self.refresh_shop_items()
        self.shop_selection = min(self.shop_selection, len(self.shop_items))

    def handle_playing_event(self, event: pygame.event.Event) -> None:
        """Handle gameplay and overlay input while in PLAYING state."""
        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            mouse_pos = self.window_to_logical((int(event.pos[0]), int(event.pos[1])), clamp=False)
            if mouse_pos is None:
                return

            if getattr(self, "pause_open", False):
                self.handle_pause_event(event, mouse_pos=mouse_pos)
                return

            if getattr(self, "perk_choice_open", False):
                self.handle_perk_choice_event(event, mouse_pos=mouse_pos)
                return

            if self.wave_manager.is_intermission() and self.armory_button_rect().collidepoint(mouse_pos):
                self.toggle_armory()
                return

            if getattr(self, "armory_open", False):
                self.handle_armory_event(event, mouse_pos=mouse_pos)
                return

            if self.mutation_button_rect().collidepoint(mouse_pos):
                self.toggle_mutation_drawer()
                return
            return

        if event.type == pygame.MOUSEWHEEL:
            if bool(getattr(self, "mutation_drawer_open", False)):
                current = int(getattr(self, "mutation_drawer_scroll", 0))
                self.mutation_drawer_scroll = max(0, current - int(getattr(event, "y", 0)))
            return

        if event.type != pygame.KEYDOWN:
            return

        if getattr(self, "perk_choice_open", False):
            self.handle_perk_choice_event(event)
            return

        if getattr(self, "armory_open", False):
            self.handle_armory_event(event)
            return

        if getattr(self, "pause_open", False):
            self.handle_pause_event(event)
            return

        if event.key == pygame.K_ESCAPE:
            self.open_pause_menu()
            return

        if event.key in (pygame.K_h, pygame.K_F1):
            self.open_guide("playing_hotkey", start_section=GUIDE_BOSS_SECTION_INDEX)
            return

        if event.key == pygame.K_p:
            self.toggle_mutation_drawer()
            return

        if bool(getattr(self, "mutation_drawer_open", False)):
            current = int(getattr(self, "mutation_drawer_scroll", 0))
            if event.key == pygame.K_PAGEUP:
                self.mutation_drawer_scroll = max(0, current - 4)
                return
            if event.key == pygame.K_PAGEDOWN:
                self.mutation_drawer_scroll = current + 4
                return
            if event.key == pygame.K_HOME:
                self.mutation_drawer_scroll = 0
                return

        if event.key == pygame.K_TAB:
            self.toggle_armory()
            return

        if event.key == pygame.K_r:
            self.try_reload_active_weapon()
            return

        self.handle_weapon_switch_input(event.key)

    def confirm_perk_selection(self, index: int) -> None:
        """Apply selected perk choice and close the draft overlay."""
        choices = list(getattr(self, "pending_perk_choices", []))
        if not choices:
            self.perk_choice_open = False
            return

        safe_index = min(max(0, int(index)), len(choices) - 1)
        self.apply_run_perk(choices[safe_index])
        self.pending_perk_choices = []
        self.perk_selection = 0
        self.perk_choice_open = False

    def handle_perk_choice_event(
        self,
        event: pygame.event.Event,
        mouse_pos: pygame.Vector2 | None = None,
    ) -> None:
        """Handle input while perk draft overlay is open."""
        choices = list(getattr(self, "pending_perk_choices", []))
        if not choices:
            self.perk_choice_open = False
            return

        if event.type == pygame.KEYDOWN and event.key in (pygame.K_LEFT, pygame.K_a):
            self.perk_selection = (int(getattr(self, "perk_selection", 0)) - 1) % len(choices)
            return
        if event.type == pygame.KEYDOWN and event.key in (pygame.K_RIGHT, pygame.K_d):
            self.perk_selection = (int(getattr(self, "perk_selection", 0)) + 1) % len(choices)
            return
        if event.type == pygame.KEYDOWN and event.key in (pygame.K_RETURN, pygame.K_SPACE):
            index = min(max(0, int(getattr(self, "perk_selection", 0))), len(choices) - 1)
            self.confirm_perk_selection(index)
            return

        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            click_pos = mouse_pos
            if click_pos is None:
                click_pos = self.window_to_logical((int(event.pos[0]), int(event.pos[1])), clamp=False)
            if click_pos is None:
                return

            for index, rect in enumerate(get_perk_card_rects(self.width, self.height, len(choices))):
                if rect.collidepoint(click_pos):
                    self.perk_selection = index
                    self.confirm_perk_selection(index)
                    return

    def handle_armory_event(
        self,
        event: pygame.event.Event,
        mouse_pos: pygame.Vector2 | None = None,
    ) -> None:
        """Handle input while intermission armory overlay is open."""
        if event.type == pygame.KEYDOWN and event.key in (pygame.K_ESCAPE, pygame.K_TAB):
            self.armory_open = False
            self.armory_scroll_offset = 0
            self.armory_message = ""
            self.armory_message_timer = 0.0
            return

        if event.type == pygame.KEYDOWN and event.key in (pygame.K_LEFT, pygame.K_a):
            self.switch_armory_tab("weapons")
            return
        if event.type == pygame.KEYDOWN and event.key in (pygame.K_RIGHT, pygame.K_d):
            self.switch_armory_tab("upgrades")
            return

        rows = self.armory_specs()
        if not rows:
            return
        self.ensure_armory_selection_visible(len(rows))

        if event.type == pygame.KEYDOWN and event.key in (pygame.K_UP, pygame.K_w):
            self.armory_selection = (int(getattr(self, "armory_selection", 0)) - 1) % len(rows)
            self.ensure_armory_selection_visible(len(rows))
            return
        if event.type == pygame.KEYDOWN and event.key in (pygame.K_DOWN, pygame.K_s):
            self.armory_selection = (int(getattr(self, "armory_selection", 0)) + 1) % len(rows)
            self.ensure_armory_selection_visible(len(rows))
            return
        if event.type == pygame.KEYDOWN and event.key in (pygame.K_RETURN, pygame.K_SPACE):
            self.try_buy_armory_selection()
            return

        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            click_pos = mouse_pos
            if click_pos is None:
                click_pos = self.window_to_logical((int(event.pos[0]), int(event.pos[1])), clamp=False)
            if click_pos is None:
                return

            for tab_key, rect in self.armory_tab_rects().items():
                if rect.collidepoint(click_pos):
                    self.switch_armory_tab(tab_key)
                    return

            offset = int(getattr(self, "armory_scroll_offset", 0))
            visible = max(1, int(self.armory_visible_row_count()))
            visible_rows = rows[offset : offset + visible]
            for visible_index in range(len(visible_rows)):
                if get_armory_row_rect(self.width, visible_index).collidepoint(click_pos):
                    self.armory_selection = offset + visible_index
                    self.ensure_armory_selection_visible(len(rows))
                    self.try_buy_armory_selection()
                    return

    def try_reload_active_weapon(self) -> bool:
        """Attempt to reload active weapon and return success state."""
        return self.weapon_inventory.start_reload_active()

    def handle_weapon_switch_input(self, key: int) -> None:
        """Handle hotkeys that cycle or switch equipped weapon slots."""
        if key == pygame.K_q:
            self.weapon_inventory.cycle_slot()
            return
        if key == pygame.K_1:
            self.weapon_inventory.switch_to_slot(1)
            return
        if key == pygame.K_2:
            self.weapon_inventory.switch_to_slot(2)
            return
        if key == pygame.K_3:
            self.weapon_inventory.switch_to_slot(3)
            return
        if key in (pygame.K_0, pygame.K_4):
            self.weapon_inventory.switch_to_slot(0)

    def handle_game_over_event(self, event: pygame.event.Event) -> None:
        """Handle restart, menu return or quit from game-over screen."""
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_r:
                self.reset_game()
                self.state = GameState.PLAYING
            elif event.key == pygame.K_m:
                self.state = GameState.MENU
            elif event.key == pygame.K_ESCAPE:
                self.quit_game()

    def get_movement_input(self) -> pygame.Vector2:
        """Collect movement vector from keyboard."""
        if getattr(self, "pause_open", False) or getattr(self, "perk_choice_open", False) or getattr(self, "armory_open", False):
            return pygame.Vector2(0, 0)

        keys = pygame.key.get_pressed()
        direction = pygame.Vector2(0, 0)

        if keys[pygame.K_w] or keys[pygame.K_UP]:
            direction.y -= 1
        if keys[pygame.K_s] or keys[pygame.K_DOWN]:
            direction.y += 1
        if keys[pygame.K_a] or keys[pygame.K_LEFT]:
            direction.x -= 1
        if keys[pygame.K_d] or keys[pygame.K_RIGHT]:
            direction.x += 1

        return direction

    def should_fire(self) -> bool:
        """Return True when shooting input is currently active."""
        if getattr(self, "pause_open", False) or getattr(self, "perk_choice_open", False) or getattr(self, "armory_open", False):
            return False

        keys = pygame.key.get_pressed()
        mouse_buttons = pygame.mouse.get_pressed(3)
        return mouse_buttons[0] or keys[pygame.K_SPACE]

    def get_aim_direction(self) -> pygame.Vector2:
        """Return normalized world-space aim direction from player to mouse."""
        mouse_pos = self.get_mouse_logical_pos(clamp=True)
        if mouse_pos is None:
            mouse_pos = pygame.Vector2(self.width / 2, self.height / 2)

        mouse_world = self.camera.screen_to_world(mouse_pos)
        aim_direction = mouse_world - self.player.position
        if aim_direction.length_squared() == 0:
            return pygame.Vector2(self.last_aim_direction)
        return aim_direction.normalize()

    @staticmethod
    def _spatial_hash_key(position: pygame.Vector2, cell_size: float) -> tuple[int, int]:
        """Return integer spatial-hash key for one world position."""
        return (int(position.x // cell_size), int(position.y // cell_size))

    def build_zombie_spatial_hash(self, cell_size: float = 128.0) -> dict[tuple[int, int], list[Zombie]]:
        """Build lightweight spatial hash so neighbor lookup avoids O(n^2)."""
        buckets: dict[tuple[int, int], list[Zombie]] = {}
        for zombie in self.zombies:
            key = self._spatial_hash_key(zombie.position, cell_size)
            if key not in buckets:
                buckets[key] = []
            buckets[key].append(zombie)
        return buckets

    def get_nearby_zombies(
        self,
        zombie: Zombie,
        buckets: dict[tuple[int, int], list[Zombie]],
        *,
        cell_size: float = 128.0,
        max_distance: float = 120.0,
    ) -> list[Zombie]:
        """Return nearby zombies from adjacent spatial buckets."""
        center = self._spatial_hash_key(zombie.position, cell_size)
        max_distance_sq = max_distance * max_distance
        nearby: list[Zombie] = []
        for dx in (-1, 0, 1):
            for dy in (-1, 0, 1):
                key = (center[0] + dx, center[1] + dy)
                for other in buckets.get(key, []):
                    if other is zombie:
                        continue
                    if zombie.position.distance_squared_to(other.position) <= max_distance_sq:
                        nearby.append(other)
        return nearby

    def compute_pack_pressure(self, *, radius: float = 245.0) -> float:
        """Return 0..1 pressure from local horde density and sustained player movement."""
        if not self.zombies:
            return 0.0

        close_count = sum(1 for zombie in self.zombies if zombie.position.distance_to(self.player.position) <= radius)
        density_pressure = max(0.0, min(1.0, (close_count - 2) / 9.0))
        motion_pressure = max(0.0, min(1.0, float(getattr(self, "player_motion_sustain", 0.0)) / 1.2))
        return max(0.0, min(1.0, density_pressure * 0.65 + motion_pressure * 0.55))

    def assign_pack_roles(self, player_velocity: pygame.Vector2, pack_pressure: float) -> dict[int, str]:
        """Assign chase/cutter/flank roles to current zombie pack for this tick."""
        role_by_id: dict[int, str] = {id(zombie): ROLE_CHASE for zombie in self.zombies}
        if len(self.zombies) < 3:
            return role_by_id

        moving = player_velocity.length() >= 70.0
        if moving:
            role_ratio = 0.24 + min(0.08, max(0.0, float(pack_pressure)) * 0.08)
        else:
            role_ratio = 0.08

        role_count = int(round(len(self.zombies) * role_ratio))
        if moving and len(self.zombies) >= 5:
            role_count = max(2, role_count)
        role_count = max(0, min(role_count, len(self.zombies)))
        if role_count <= 0:
            return role_by_id

        sorted_by_distance = sorted(self.zombies, key=lambda zombie: zombie.position.distance_squared_to(self.player.position))
        selected = sorted_by_distance[:role_count]

        cutter_count = max(1, role_count // 2) if moving else 1
        cutter_count = min(cutter_count, role_count)
        flank_count = role_count - cutter_count

        for idx, zombie in enumerate(selected[:cutter_count]):
            role_by_id[id(zombie)] = ROLE_CUTTER_LEFT if idx % 2 == 0 else ROLE_CUTTER_RIGHT

        for idx, zombie in enumerate(selected[cutter_count : cutter_count + flank_count]):
            role_by_id[id(zombie)] = ROLE_FLANK_LEFT if idx % 2 == 0 else ROLE_FLANK_RIGHT

        return role_by_id

    def spawn_projectiles(self, spawns: list[ProjectileSpawn]) -> None:
        """Create projectile entities using active damage and crit modifiers."""
        # Shot count is tracked for objective and run analytics.
        self.total_shots_fired = int(getattr(self, "total_shots_fired", 0)) + len(spawns)
        damage_multiplier = float(getattr(self, "damage_multiplier", 1.0))
        low_hp_multiplier = float(getattr(self, "low_hp_damage_multiplier", 1.0))
        hp_ratio = 1.0
        if self.player.max_health > 0:
            hp_ratio = self.player.health / self.player.max_health
        if hp_ratio <= 0.40:
            # Low-HP perk damage bonus applies only in critical health range.
            damage_multiplier *= low_hp_multiplier

        crit_chance = float(getattr(self, "crit_chance", 0.0))
        crit_multiplier = float(getattr(self, "crit_base_multiplier", 1.6)) + float(getattr(self, "crit_damage_bonus", 0.0))
        projectile_speed_multiplier = float(getattr(self, "projectile_speed_multiplier", 1.0))
        for spawn in spawns:
            shot_damage = float(spawn.damage) * damage_multiplier
            if random.random() < crit_chance:
                # Crits are resolved per projectile spawn.
                shot_damage *= crit_multiplier
            damage = max(1, int(round(shot_damage)))
            self.projectiles.append(
                Projectile(
                    self.player.position,
                    spawn.direction,
                    speed=spawn.speed * projectile_speed_multiplier,
                    radius=spawn.radius,
                    damage=damage,
                )
            )

    def update(self, dt: float) -> None:
        """Advance world simulation while playing."""
        if self.state != GameState.PLAYING:
            return
        # This flag is reset each frame and set by any successful hit on player.
        self.player_took_damage_this_frame = False

        overlay_pause = self.overlay_pause_active()
        if not overlay_pause:
            # Timers and progression advance only when no blocking overlay is open.
            self.survival_time += dt
            self.player_hit_timer = max(0.0, self.player_hit_timer - dt)
            self.coin_flush_timer += dt
            self.advance_lifesteal_window(dt)
            self.update_wave_banner_timer(dt)
            self.weapon_inventory.update_timers(dt)
            self.armory_message_timer = max(0.0, float(getattr(self, "armory_message_timer", 0.0)) - dt)
            self.boss_contact_damage_lockout_timer = max(
                0.0,
                float(getattr(self, "boss_contact_damage_lockout_timer", 0.0)) - dt,
            )
            if self.armory_message_timer == 0.0:
                self.armory_message = ""
        else:
            # Prevent stale edge-trigger shot when returning from overlays.
            self.fire_button_prev = False

        # Movement input still updates camera/player pose while overlay is open (dt=0).
        input_vector = self.get_movement_input()
        self.player.update(
            0.0 if overlay_pause else dt,
            input_vector,
            self.world_rect,
            speed_multiplier=float(getattr(self, "player_speed_multiplier", 1.0)),
        )
        self.camera.update(self.player.position)
        if not hasattr(self, "player_velocity"):
            self.player_velocity = pygame.Vector2()
        if not hasattr(self, "_player_previous_position"):
            self._player_previous_position = pygame.Vector2(self.player.position)
        if not hasattr(self, "player_motion_sustain"):
            self.player_motion_sustain = 0.0

        if overlay_pause or dt <= 0:
            # Freeze derived velocity state while simulation is paused.
            self.player_velocity.update(0.0, 0.0)
            self._player_previous_position = pygame.Vector2(self.player.position)
            self.player_motion_sustain = max(0.0, float(getattr(self, "player_motion_sustain", 0.0)) - dt * 1.3)
        else:
            # Velocity is derived from position delta to reflect effective movement.
            previous = pygame.Vector2(self._player_previous_position)
            self.player_velocity = (self.player.position - previous) / dt
            self._player_previous_position = pygame.Vector2(self.player.position)
            if self.player_velocity.length() >= 95.0:
                self.player_motion_sustain = min(2.4, float(getattr(self, "player_motion_sustain", 0.0)) + dt)
            else:
                self.player_motion_sustain = max(0.0, float(getattr(self, "player_motion_sustain", 0.0)) - dt * 1.15)

        aim_direction = self.get_aim_direction()
        self.last_aim_direction = pygame.Vector2(aim_direction)

        if not overlay_pause:
            self.powerups.update(dt)
            collected = self.powerups.collect_at_player(self.player)
            if collected:
                self.handle_collected_pickups(collected)
        # Periodic DB sync runs regardless of overlay state.
        self.flush_pending_coins(force=False)

        if overlay_pause:
            # Keep wave state stable while paused by reusing cached active values.
            spawn_types: list[object] = []
            wave_started = False
            wave_cleared = False
            wave_kind = str(getattr(self, "active_wave_kind", "standard"))
            objective_type = getattr(self, "active_wave_objective", None)
            mutator_key = getattr(self, "active_wave_mutator", None)
            boss_archetype = getattr(self, "active_boss_archetype", None)
        else:
            # Normal wave manager tick drives spawns, starts, clears, and metadata.
            events = self.wave_manager.update(dt, alive_count=len(self.zombies))
            spawn_types = events.spawn_types
            wave_started = events.wave_started
            wave_cleared = events.wave_cleared
            wave_kind = str(getattr(events, "wave_kind", getattr(self, "active_wave_kind", "standard")))
            objective_type = getattr(events, "objective_type", getattr(self, "active_wave_objective", None))
            mutator_key = getattr(events, "mutator_key", getattr(self, "active_wave_mutator", None))
            event_boss_archetype = getattr(events, "boss_archetype", None)
            if event_boss_archetype is None:
                boss_archetype = getattr(self, "active_boss_archetype", None)
            else:
                boss_archetype = event_boss_archetype

        if wave_started:
            # Close intermission overlays and configure wave runtime rules.
            self.armory_open = False
            self.armory_scroll_offset = 0
            self.armory_message = ""
            self.armory_message_timer = 0.0
            current_wave = max(1, int(getattr(self.wave_manager, "current_wave", 1)))
            is_boss_wave = bool(getattr(self.wave_manager, "is_boss_wave", lambda _wave=None: False)(current_wave))
            wave_twist = self.choose_wave_twist(current_wave, wave_kind, is_boss_wave=is_boss_wave)
            self.configure_wave_runtime(
                wave_kind,
                objective_type,
                mutator_key,
                boss_archetype=boss_archetype,
                wave_twist=wave_twist,
            )
            if is_boss_wave:
                subtitle = f"BOSS: {self.boss_archetype_label(self.active_boss_archetype)}"
                self.start_wave_banner(current_wave, is_boss=True, subtitle=subtitle)
            if bool(getattr(self, "last_stand_enabled", False)):
                # Last Stand refreshes once at each wave start.
                self.last_stand_available = True
        elif not overlay_pause and not wave_cleared:
            self.active_wave_kind = wave_kind
            self.active_wave_objective = objective_type
            self.active_wave_mutator = mutator_key
            self.active_boss_archetype = boss_archetype

        if not self.wave_manager.is_intermission():
            self.armory_open = False
            self.armory_scroll_offset = 0

        for zombie_kind in spawn_types:
            # Spawn requests are already rate-limited by wave manager internals.
            zombie = Zombie.spawn_near_view(self.world_rect, self.camera.view_rect, zombie_kind)
            self.apply_wave_modifiers_to_zombie(zombie)
            self.zombies.append(zombie)

        if not overlay_pause:
            self.update_objective_wave(dt)
            if self.state != GameState.PLAYING:
                return

        if wave_cleared:
            self.process_wave_clear()

        if not overlay_pause:
            # Trigger state distinguishes hold-fire from first-press actions.
            trigger_down = self.should_fire()
            trigger_pressed = trigger_down and not self.fire_button_prev
            self.fire_button_prev = trigger_down
            spawns = self.weapon_inventory.step_fire(
                trigger_down=trigger_down,
                trigger_pressed=trigger_pressed,
                aim_direction=aim_direction,
                cooldown_multiplier=self.powerups.shoot_cooldown_multiplier * float(getattr(self, "weapon_cooldown_multiplier", 1.0)),
                ammo_preserve_chance=float(getattr(self, "ammo_preserve_chance", 0.0)),
            )
            self.spawn_projectiles(spawns)

            # Build local steering context once so each zombie update stays cheap.
            player_velocity = pygame.Vector2(getattr(self, "player_velocity", pygame.Vector2()))
            pack_pressure = self.compute_pack_pressure()
            role_map = self.assign_pack_roles(player_velocity, pack_pressure)
            buckets = self.build_zombie_spatial_hash()
            for zombie in self.zombies:
                nearby = self.get_nearby_zombies(zombie, buckets)
                zombie.update(
                    dt,
                    self.player.position,
                    self.powerups.zombie_speed_multiplier,
                    player_velocity=player_velocity,
                    nearby_zombies=nearby,
                    surround_strength=pack_pressure,
                    role=role_map.get(id(zombie), ROLE_CHASE),
                    pack_pressure=pack_pressure,
                )
            self.process_boss_special_attacks()
            self.update_boss_hazards(dt)
            self.update_wave_twist(dt)
            if not self.player.is_alive:
                # Persist immediately on death to avoid loss from abrupt exits.
                self.flush_pending_coins(force=True)
                self.persist_result()
                self.state = GameState.GAME_OVER
                return

            for projectile in self.projectiles:
                projectile.update(dt)

            self.handle_collisions()
            # Cull out-of-bounds projectiles after collision resolution.
            self.projectiles = [projectile for projectile in self.projectiles if not projectile.is_out_of_bounds(self.world_rect)]
            self.update_objective_wave(0.0)
            self.update_no_hit_streak(dt)
            if self.state != GameState.PLAYING:
                return

        if not self.player.is_alive:
            self.flush_pending_coins(force=True)
            self.persist_result()
            self.state = GameState.GAME_OVER

    def handle_collisions(self) -> None:
        """Resolve projectile-zombie and zombie-player collisions."""
        remaining_projectiles: list[Projectile] = []
        dead_zombies_by_id: dict[int, Zombie] = {}

        # Projectile collisions resolve first to keep damage and kill rewards deterministic.
        for projectile in self.projectiles:
            hit = False
            for zombie in self.zombies:
                if projectile.position.distance_to(zombie.position) <= projectile.radius + zombie.radius:
                    dealt_damage = min(zombie.health, projectile.damage)
                    if hasattr(zombie, "register_channel_damage"):
                        zombie.register_channel_damage(dealt_damage)
                    if zombie.take_damage(projectile.damage):
                        dead_zombies_by_id[id(zombie)] = zombie
                    self.apply_lifesteal_from_damage(dealt_damage)
                    hit = True
                    break

            if not hit:
                remaining_projectiles.append(projectile)

        self.projectiles = remaining_projectiles

        if dead_zombies_by_id:
            dead_ids = set(dead_zombies_by_id)
            self.zombies = [zombie for zombie in self.zombies if id(zombie) not in dead_ids]
            ammo_pressure = self.current_ammo_pressure_ratio()

            for zombie in dead_zombies_by_id.values():
                self.kills += 1
                self.score += zombie.score_value
                self.award_coins(zombie.coin_value)
                self.award_run_scrap(zombie.coin_value * 3)
                if bool(getattr(zombie, "is_elite", False)):
                    self.objective_elite_kills = int(getattr(self, "objective_elite_kills", 0)) + 1
                self.wave_manager.notify_zombie_killed()
                try:
                    # Ammo pressure biases power-up drop odds toward ammo relief.
                    self.powerups.maybe_spawn_drop(zombie.position, ammo_pressure=ammo_pressure)
                except TypeError:
                    # Compatibility for tests/stubs with legacy 1-arg signature.
                    self.powerups.maybe_spawn_drop(zombie.position)

        colliding_zombies: list[Zombie] = []
        for zombie in self.zombies:
            if zombie.position.distance_to(self.player.position) <= zombie.radius + self.player.radius:
                colliding_zombies.append(zombie)

        # Contact hits are throttled by hit cooldown to avoid damage stacking in one frame.
        contact_lockout = float(getattr(self, "boss_contact_damage_lockout_timer", 0.0))
        if colliding_zombies and self.player_hit_timer == 0.0 and contact_lockout == 0.0:
            incoming_damage = max(zombie.damage for zombie in colliding_zombies)
            scaled_damage = max(1, int(round(incoming_damage * self.combined_incoming_damage_multiplier())))
            projected_health = self.player.health - scaled_damage
            if projected_health <= 0 and self.last_stand_enabled and self.last_stand_available:
                self.player.health = min(self.player.max_health, max(1, 20))
                self.last_stand_available = False
            else:
                self.player.take_damage(scaled_damage)
            self.player_took_damage_this_frame = True
            self.player_hit_timer = self.player_hit_cooldown

        for zombie in colliding_zombies:
            push_dir = zombie.position - self.player.position
            if push_dir.length_squared() > 0:
                # Push enemies off player body to avoid indefinite overlap locking.
                zombie.position += push_dir.normalize() * 16

    def draw_world_background(self) -> None:
        """Render map floor grid and world borders."""
        mode = str(getattr(self, "visual_mode", "night")).lower()
        if mode == "day":
            self.screen.fill((64, 88, 112))
            grid_color = (84, 104, 124)
            border_color = (116, 136, 156)
        elif mode == "blackout":
            self.screen.fill((14, 16, 20))
            grid_color = (24, 28, 36)
            border_color = (50, 58, 72)
        else:
            self.screen.fill((25, 28, 34))
            grid_color = (36, 40, 48)
            border_color = (70, 75, 86)

        view = self.camera.view_rect
        step = 120

        # Draw vertical grid lines for depth and movement readability.
        start_x = (view.left // step) * step
        end_x = view.right + step
        for x in range(start_x, end_x, step):
            world_start = pygame.Vector2(x, view.top - step)
            world_end = pygame.Vector2(x, view.bottom + step)
            start = self.camera.world_to_screen(world_start)
            end = self.camera.world_to_screen(world_end)
            pygame.draw.line(
                self.screen,
                grid_color,
                (int(start.x), int(start.y)),
                (int(end.x), int(end.y)),
                1,
            )

        start_y = (view.top // step) * step
        end_y = view.bottom + step
        # Draw horizontal grid lines on the same spacing as vertical lines.
        for y in range(start_y, end_y, step):
            world_start = pygame.Vector2(view.left - step, y)
            world_end = pygame.Vector2(view.right + step, y)
            start = self.camera.world_to_screen(world_start)
            end = self.camera.world_to_screen(world_end)
            pygame.draw.line(
                self.screen,
                grid_color,
                (int(start.x), int(start.y)),
                (int(end.x), int(end.y)),
                1,
            )

        top_left = self.camera.world_to_screen(pygame.Vector2(self.world_rect.topleft))
        # Border rectangle marks absolute world limits for player orientation.
        border_rect = pygame.Rect(int(top_left.x), int(top_left.y), self.world_rect.width, self.world_rect.height)
        pygame.draw.rect(self.screen, border_color, border_rect, 5)

    def draw_pickup_marker(self, pickup: object) -> None:
        """Draw one pickup with shape cues so each effect is readable at a glance."""
        if not hasattr(pickup, "position") or not hasattr(pickup, "radius") or not hasattr(pickup, "kind"):
            return
        pickup_screen = self.camera.world_to_screen(pickup.position)
        center = (int(pickup_screen.x), int(pickup_screen.y))
        radius = max(2, int(getattr(pickup, "radius", 8)))
        color = self.powerups.pickup_color(pickup.kind)
        pygame.draw.circle(self.screen, color, center, radius)
        pygame.draw.circle(self.screen, (250, 250, 250), center, radius, 2)

        # Shape overlays provide quick type recognition without reading text.
        if pickup.kind == PowerUpType.AMMO_CACHE:
            box = pygame.Rect(0, 0, radius, radius - 2)
            box.center = center
            pygame.draw.rect(self.screen, (36, 50, 84), box, 2, border_radius=2)
            pygame.draw.line(self.screen, (36, 50, 84), (box.left + 2, box.centery), (box.right - 2, box.centery), 2)
            return

        if pickup.kind == PowerUpType.FREEZE_BLAST:
            pygame.draw.line(self.screen, (30, 62, 86), (center[0] - radius + 3, center[1]), (center[0] + radius - 3, center[1]), 2)
            pygame.draw.line(self.screen, (30, 62, 86), (center[0], center[1] - radius + 3), (center[0], center[1] + radius - 3), 2)
            pygame.draw.line(
                self.screen,
                (30, 62, 86),
                (center[0] - radius + 4, center[1] - radius + 4),
                (center[0] + radius - 4, center[1] + radius - 4),
                2,
            )
            pygame.draw.line(
                self.screen,
                (30, 62, 86),
                (center[0] + radius - 4, center[1] - radius + 4),
                (center[0] - radius + 4, center[1] + radius - 4),
                2,
            )
            return

        if pickup.kind == PowerUpType.FORTIFY_FIELD:
            points = [
                (center[0], center[1] - radius + 3),
                (center[0] + radius - 4, center[1] - 2),
                (center[0] + radius // 2, center[1] + radius - 3),
                (center[0] - radius // 2, center[1] + radius - 3),
                (center[0] - radius + 4, center[1] - 2),
            ]
            pygame.draw.polygon(self.screen, (82, 36, 32), points, 2)
            return

        if pickup.kind == PowerUpType.SCRAP_MAGNET:
            pygame.draw.arc(
                self.screen,
                (28, 76, 58),
                pygame.Rect(center[0] - radius + 3, center[1] - radius + 2, (radius - 3) * 2, (radius - 3) * 2),
                3.14,
                6.26,
                3,
            )
            pygame.draw.rect(self.screen, (28, 76, 58), (center[0] - radius + 3, center[1] + 1, 4, radius - 5))
            pygame.draw.rect(self.screen, (28, 76, 58), (center[0] + radius - 7, center[1] + 1, 4, radius - 5))

    def render_world_entities(self, draw_barrel: bool) -> pygame.Vector2:
        """Draw projectiles, zombies, pickups and player in camera space."""
        # World entities are rendered in camera space; HUD overlays are drawn afterward.
        for hazard in list(getattr(self, "active_boss_hazards", [])):
            center = pygame.Vector2(hazard.get("center", self.player.position))
            radius = max(8, int(float(hazard.get("radius", 0.0))))
            arm_time = max(0.0, float(hazard.get("arm_time", 0.0)))
            active_time = max(0.0, float(hazard.get("active_time", 0.0)))
            center_screen = self.camera.world_to_screen(center)
            if arm_time > 0.0:
                pulse = 0.65 + 0.35 * abs((arm_time * 6.0) % 2.0 - 1.0)
                alpha = max(40, min(180, int(170 * pulse)))
                ring = pygame.Surface((radius * 2 + 8, radius * 2 + 8), pygame.SRCALPHA)
                pygame.draw.circle(
                    ring,
                    (255, 188, 82, alpha),
                    (ring.get_width() // 2, ring.get_height() // 2),
                    radius,
                    3,
                )
                ring_rect = ring.get_rect(center=(int(center_screen.x), int(center_screen.y)))
                self.screen.blit(ring, ring_rect.topleft)
            elif active_time > 0.0:
                fill_alpha = max(30, min(120, int(96 + 30 * active_time)))
                fill = pygame.Surface((radius * 2 + 8, radius * 2 + 8), pygame.SRCALPHA)
                pygame.draw.circle(
                    fill,
                    (255, 92, 72, fill_alpha),
                    (fill.get_width() // 2, fill.get_height() // 2),
                    radius,
                )
                pygame.draw.circle(
                    fill,
                    (255, 138, 110, min(220, fill_alpha + 70)),
                    (fill.get_width() // 2, fill.get_height() // 2),
                    radius,
                    3,
                )
                fill_rect = fill.get_rect(center=(int(center_screen.x), int(center_screen.y)))
                self.screen.blit(fill, fill_rect.topleft)

        for pickup in self.powerups.pickups:
            self.draw_pickup_marker(pickup)

        for projectile in self.projectiles:
            projectile.draw(self.screen, self.camera.world_to_screen(projectile.position))

        player_screen = self.camera.world_to_screen(self.player.position)
        mode = str(getattr(self, "visual_mode", "night")).lower()
        nightmare_fog = str(getattr(self, "active_wave_mutator", "")) == "nightmare_fog"
        if mode == "blackout" or nightmare_fog:
            # In low-visibility modes zombies are rendered through a cone visibility mask.
            mouse_pos = self.get_mouse_logical_pos(clamp=True)
            if mouse_pos is None:
                mouse_pos = pygame.Vector2(self.width / 2, self.height / 2)

            mouse_world = self.camera.screen_to_world(mouse_pos)
            aim_direction = mouse_world - self.player.position
            if aim_direction.length_squared() == 0:
                aim_direction = self.last_aim_direction

            cone_points = get_flashlight_cone_points(
                player_screen,
                aim_direction,
                cone_length=240,
                cone_angle_deg=46,
            )
            zombie_layer = pygame.Surface(self.screen.get_size(), pygame.SRCALPHA)
            for zombie in self.zombies:
                zombie.draw(zombie_layer, self.camera.world_to_screen(zombie.position))
            visible_zombies = apply_cone_visibility_mask(zombie_layer, cone_points)
            self.screen.blit(visible_zombies, (0, 0))
        else:
            for zombie in self.zombies:
                zombie.draw(self.screen, self.camera.world_to_screen(zombie.position))

        self.player.draw(self.screen, player_screen)
        if float(getattr(self, "safe_zone_pulse_flash_timer", 0.0)) > 0.0:
            # Brief ring effect signals safe-zone pulse activation.
            alpha = min(180, int(420 * float(self.safe_zone_pulse_flash_timer)))
            pulse_radius = int(126 + 80 * float(self.safe_zone_pulse_flash_timer))
            ring_surface = pygame.Surface((pulse_radius * 2 + 6, pulse_radius * 2 + 6), pygame.SRCALPHA)
            pygame.draw.circle(
                ring_surface,
                (110, 226, 190, alpha),
                (ring_surface.get_width() // 2, ring_surface.get_height() // 2),
                pulse_radius,
                4,
            )
            ring_rect = ring_surface.get_rect(center=(int(player_screen.x), int(player_screen.y)))
            self.screen.blit(ring_surface, ring_rect.topleft)

        if draw_barrel:
            # Barrel draw uses latest cursor direction for immediate aim feedback.
            mouse_pos = self.get_mouse_logical_pos(clamp=True)
            if mouse_pos is None:
                mouse_pos = pygame.Vector2(self.width / 2, self.height / 2)

            mouse_world = self.camera.screen_to_world(mouse_pos)
            aim_direction = mouse_world - self.player.position
            if aim_direction.length_squared() == 0:
                aim_direction = self.last_aim_direction
            self.player.draw_barrel(self.screen, aim_direction, player_screen)

        return player_screen

    def weapon_hud_data(self) -> tuple[str, str, str, str, list[str]]:
        """Build HUD strings for active weapon, main slots and fallback pistol."""
        active_state = self.weapon_inventory.active_state
        active_spec = self.weapon_inventory.active_spec
        if active_state is None or active_spec is None:
            return "unknown", "None", "0/0", "", ["1: Empty", "2: Empty", "Fallback [0/4]: Pistol (INF)"]

        # Ammo label keeps infinite-reserve weapons readable in same format.
        reserve_label = "INF" if active_state.reserve_ammo is None else str(active_state.reserve_ammo)
        ammo_label = f"{active_state.ammo_in_mag}/{reserve_label}"
        reload_label = f"Reloading {active_state.reload_timer:0.1f}s" if active_state.is_reloading else ""

        slot_labels: list[str] = []
        unlocked_indices = self.weapon_inventory.unlocked_main_slot_indices()
        # HUD slot list follows unlocked index order, not owned weapon order.
        for display_slot, slot_index in enumerate(unlocked_indices, start=1):
            slot_state = self.weapon_inventory.slots[slot_index]
            marker = "*" if slot_index == self.weapon_inventory.active_slot else " "
            if slot_state is None:
                label = f"{marker}{display_slot}: Empty"
            else:
                spec = self.weapon_inventory.catalog[slot_state.spec_key]
                label = f"{marker}{display_slot}: {spec.display_name}"
            slot_labels.append(label)

        fallback_marker = "*" if int(getattr(self.weapon_inventory, "active_slot", 0)) == 0 else " "
        slot_labels.append(f"{fallback_marker}Fallback [0/4]: Pistol (INF)")

        return active_spec.key, active_spec.display_name, ammo_label, reload_label, slot_labels

    def render_lighting_overlay(self, player_screen: pygame.Vector2, aim_direction: pygame.Vector2) -> None:
        """Render directional darkness overlay for night-style visual modes."""
        mode = str(getattr(self, "visual_mode", "night")).lower()
        nightmare_fog = str(getattr(self, "active_wave_mutator", "")) == "nightmare_fog"
        if nightmare_fog:
            # Nightmare Fog is the harshest visibility preset.
            render_darkness_overlay(
                self.screen,
                player_screen,
                aim_direction,
                cone_length=206,
                cone_angle_deg=46,
                darkness_alpha=244,
            )
            return
        if mode == "night":
            # Night mode keeps broad cone and medium darkness for standard gameplay.
            render_darkness_overlay(
                self.screen,
                player_screen,
                aim_direction,
                cone_length=280,
                cone_angle_deg=60,
                darkness_alpha=190,
            )
            return
        if mode == "blackout":
            # Blackout mode narrows cone and increases darkness pressure.
            render_darkness_overlay(
                self.screen,
                player_screen,
                aim_direction,
                cone_length=240,
                cone_angle_deg=46,
                darkness_alpha=228,
            )
            return

    def render_play_scene(self) -> None:
        """Render active gameplay world, HUD and intermission overlays."""
        self.draw_world_background()
        player_screen = self.render_world_entities(draw_barrel=True)

        mouse_pos = self.get_mouse_logical_pos(clamp=True)
        if mouse_pos is None:
            mouse_pos = pygame.Vector2(self.width / 2, self.height / 2)

        mouse_world = self.camera.screen_to_world(mouse_pos)
        aim_direction = mouse_world - self.player.position
        if aim_direction.length_squared() == 0:
            aim_direction = self.last_aim_direction
        self.render_lighting_overlay(player_screen, aim_direction)

        intermission_remaining = self.wave_manager.intermission_remaining if self.wave_manager.is_intermission() else 0.0
        weapon_key, weapon_name, ammo_label, reload_label, slot_labels = self.weapon_hud_data()
        temporary_effects = self.powerups.active_effect_labels()
        active_effects = temporary_effects + self.run_perk_labels()
        perk_drawer_lines = self.run_perk_drawer_lines()
        perk_choice_open = bool(getattr(self, "perk_choice_open", False))
        armory_open = bool(getattr(self, "armory_open", False))
        pause_open = bool(getattr(self, "pause_open", False))
        mutation_drawer_open = bool(getattr(self, "mutation_drawer_open", False))
        intermission_hint = ""
        armory_button_text = ""
        armory_button_active = False
        mutation_button_text = "Close Mutations [P]" if mutation_drawer_open else "Mutations [P]"
        mutation_button_active = mutation_drawer_open
        wave_rule_text = self.wave_rule_label()
        if self.wave_manager.is_intermission():
            if not perk_choice_open and not armory_open and not pause_open:
                intermission_hint = "INTERMISSION: Click ARMORY or press TAB"

            if not perk_choice_open:
                armory_button_active = armory_open
                armory_button_text = "Close Armory [TAB]" if armory_open else "Armory [TAB]"

        draw_hud(
            self.screen,
            self.score,
            self.kills,
            self.survival_time,
            self.player.health,
            self.player.max_health,
            self.wave_manager.current_wave,
            intermission_remaining,
            self.player_coins,
            self.run_scrap,
            weapon_key,
            weapon_name,
            ammo_label,
            reload_label,
            slot_labels,
            active_effects,
            intermission_hint,
            armory_button_text,
            armory_button_active,
            mutation_button_text,
            mutation_button_active,
            self.visual_mode_label(),
            wave_rule_text,
        )

        if mutation_drawer_open:
            draw_mutation_drawer(
                self.screen,
                self.width,
                self.height,
                temporary_effects,
                perk_drawer_lines,
                scroll_offset=int(getattr(self, "mutation_drawer_scroll", 0)),
            )

        if self.wave_banner_timer > 0:
            draw_wave_banner(
                self.screen,
                self.wave_banner_wave,
                self.wave_banner_timer,
                self.wave_banner_duration,
                is_boss=self.wave_banner_is_boss,
                subtitle=str(getattr(self, "wave_banner_subtitle", "")),
            )

        if self.wave_manager.is_intermission() and armory_open and not perk_choice_open:
            armory_rows = self.armory_specs()
            self.ensure_armory_selection_visible(len(armory_rows))
            draw_armory_overlay(
                self.screen,
                self.width,
                self.height,
                self.wave_manager.current_wave,
                self.run_scrap,
                self.armory_tab,
                armory_rows,
                int(getattr(self, "armory_selection", 0)),
                row_offset=int(getattr(self, "armory_scroll_offset", 0)),
                max_visible_rows=int(self.armory_visible_row_count()),
                message=str(getattr(self, "armory_message", "")),
            )

        if perk_choice_open:
            choices: list[dict[str, object]] = []
            for perk_key in self.pending_perk_choices:
                perk = RUN_PERK_DEFINITIONS.get(perk_key, {})
                choices.append(
                    {
                        "name": str(perk.get("name", perk_key)),
                        "description": str(perk.get("description", "")),
                        "is_active": perk_key in self.active_run_perks,
                    }
                )
            draw_perk_draft_overlay(
                self.screen,
                self.width,
                self.height,
                choices,
                int(getattr(self, "perk_selection", 0)),
            )

        if pause_open:
            draw_pause_overlay(
                self.screen,
                self.width,
                self.height,
                int(getattr(self, "pause_selection", 0)),
                settings_open=bool(getattr(self, "pause_settings_open", False)),
                settings_selected_index=int(getattr(self, "pause_settings_selection", 0)),
                is_fullscreen=bool(getattr(self, "is_fullscreen", False)),
            )

    def render(self) -> None:
        """Draw current state to display."""
        self.screen.fill((25, 28, 34))

        if self.state == GameState.MENU:
            draw_menu(
                self.screen,
                self.width,
                self.height,
                self.menu_selection,
                self.player_name,
                self.player_coins,
                self.leaderboard_lines,
                self.is_authenticated(),
                self.menu_message,
            )

        elif self.state == GameState.VISUAL_MODE_SELECT:
            draw_visual_mode_select(
                self.screen,
                self.width,
                self.height,
                int(getattr(self, "visual_mode_selection", 0)),
                self.visual_mode_options(),
            )

        elif self.state == GameState.SHOP:
            draw_shop(
                self.screen,
                self.width,
                self.height,
                self.player_name,
                self.player_coins,
                self.shop_items,
                self.shop_selection,
            )

        elif self.state == GameState.LOGIN:
            draw_login_input(
                self.screen,
                self.width,
                self.height,
                self.login_username_input,
                self.login_password_input,
                self.login_active_field,
                self.login_error,
            )

        elif self.state == GameState.GUIDE:
            sections = self.guide_sections()
            self.guide_scroll_offset = draw_howto_screen(
                self.screen,
                self.width,
                self.height,
                sections,
                selected_section_index=int(getattr(self, "guide_section_index", 0)),
                scroll_offset=int(getattr(self, "guide_scroll_offset", 0)),
            )

        elif self.state == GameState.PLAYING:
            self.render_play_scene()

        elif self.state == GameState.GAME_OVER:
            self.draw_world_background()
            self.render_world_entities(draw_barrel=False)
            draw_game_over(
                self.screen,
                self.width,
                self.height,
                self.score,
                self.kills,
                self.survival_time,
                self.coins_earned_run,
            )

        self.present_frame()

    def present_frame(self) -> None:
        """Scale logical frame to viewport and present it on display surface."""
        if self.display_surface is None:
            return

        self.display_surface.fill((0, 0, 0))
        if self.viewport_rect.size == self.screen.get_size():
            frame = self.screen
        else:
            frame = pygame.transform.smoothscale(self.screen, self.viewport_rect.size)

        self.display_surface.blit(frame, self.viewport_rect.topleft)
        pygame.display.flip()

    def quit_game(self) -> None:
        """Quit pygame and terminate process."""
        self.flush_pending_coins(force=True)
        pygame.quit()
        sys.exit()


if __name__ == "__main__":
    Game().run()

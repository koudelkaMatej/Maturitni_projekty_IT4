﻿"""Optional game audio wrapper with graceful fallbacks."""

from __future__ import annotations

from pathlib import Path

import pygame


class AudioManager:
    """Load and play optional sounds without crashing when unavailable."""

    def __init__(self):
        """Initialize AudioManager runtime state."""
        self.enabled = False
        self.wave_complete_sound = None
        self._warned_missing = False

        try:
            # Audio is optional; keep the game playable even when mixer init fails.
            if not pygame.mixer.get_init():
                pygame.mixer.init()
            self.enabled = True
        except pygame.error:
            self.enabled = False

    def load_optional(self, relative_path: str) -> None:
        """Load optional sound file from project root."""
        if not self.enabled:
            return

        base_dir = Path(__file__).resolve().parent.parent
        sound_path = base_dir / relative_path
        if not sound_path.exists():
            # Missing optional assets should only warn once.
            if not self._warned_missing:
                print(f"[audio] optional sound missing: {sound_path}")
                self._warned_missing = True
            return

        try:
            self.wave_complete_sound = pygame.mixer.Sound(str(sound_path))
        except pygame.error:
            self.wave_complete_sound = None

    def play_wave_complete(self) -> None:
        """Play wave completion sound if available."""
        if self.wave_complete_sound is not None:
            self.wave_complete_sound.play()

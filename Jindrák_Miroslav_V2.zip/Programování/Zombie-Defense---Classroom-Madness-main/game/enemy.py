﻿"""Enemy entities (zombies) and spawn helpers."""

from __future__ import annotations

import random
from dataclasses import dataclass
from enum import Enum, auto

import pygame


class ZombieType(Enum):
    """Available zombie archetypes."""

    WALKER = auto()
    RUNNER = auto()
    TANK = auto()
    BOSS = auto()


class BossArchetype(Enum):
    """Boss archetype variants used for encounter diversity."""

    WARDEN = "warden"
    RAVAGER = "ravager"
    BROODLORD = "broodlord"
    PHANTOM = "phantom"
    ZONE_CASTER = "zone_caster"
    STEALTH_ASSASSIN = "stealth_assassin"


@dataclass(frozen=True)
class ZombieStats:
    """Tunable parameters for each zombie type."""

    speed: float
    radius: int
    max_health: int
    damage: int
    color: tuple[int, int, int]
    score_value: int
    coin_value: int


ZOMBIE_STATS: dict[ZombieType, ZombieStats] = {
    # Base stat table used by all per-zombie runtime instances.
    ZombieType.WALKER: ZombieStats(
        speed=115,
        radius=16,
        max_health=40,
        damage=12,
        color=(70, 200, 110),
        score_value=10,
        coin_value=2,
    ),
    ZombieType.RUNNER: ZombieStats(
        speed=185,
        radius=14,
        max_health=28,
        damage=9,
        color=(240, 170, 70),
        score_value=14,
        coin_value=3,
    ),
    ZombieType.TANK: ZombieStats(
        speed=70,
        radius=20,
        max_health=120,
        damage=18,
        color=(170, 80, 70),
        score_value=25,
        coin_value=5,
    ),
    ZombieType.BOSS: ZombieStats(
        speed=82,
        radius=32,
        max_health=900,
        damage=36,
        color=(120, 40, 40),
        score_value=180,
        coin_value=35,
    ),
}

ROLE_CHASE = "chase"
ROLE_CUTTER_LEFT = "cutter_left"
ROLE_CUTTER_RIGHT = "cutter_right"
ROLE_FLANK_LEFT = "flank_left"
ROLE_FLANK_RIGHT = "flank_right"

INTERCEPT_MIN_LEAD = 0.10
INTERCEPT_MAX_LEAD = 0.48
ROLE_INTERCEPT_WEIGHT = 0.48

CUTTER_AHEAD_DISTANCE = 196.0
CUTTER_LATERAL_DISTANCE = 142.0
FLANK_AHEAD_DISTANCE = 104.0
FLANK_LATERAL_DISTANCE = 182.0

MICRO_OVERLAP_FACTOR = 0.22
MICRO_OVERLAP_WEIGHT = 0.70

BURST_DURATION = 0.36
BURST_COOLDOWN = 1.95
BURST_SPEED_MULT = 1.72
BURST_PRESSURE_SPEED_BONUS = 0.36
BURST_TRIGGER_MIN_DISTANCE = 74.0
BURST_TRIGGER_MAX_DISTANCE = 460.0
BURST_TRIGGER_PLAYER_SPEED = 95.0

BOSS_CHARGE_COOLDOWN_BASE = 4.2
BOSS_CHARGE_DURATION = 0.62
BOSS_CHARGE_SPEED_MULT = 2.05
BOSS_CHARGE_WINDUP = 0.24
BOSS_CHARGE_RECOVERY_DURATION = 0.70
BOSS_CHARGE_DODGE_DISTANCE = 54.0
BOSS_LEAP_COOLDOWN_BASE = 6.1
BOSS_LEAP_DURATION = 0.34
BOSS_LEAP_SPEED_MULT = 2.55
BOSS_LEAP_WINDUP = 0.44
BOSS_LEAP_DODGE_CORE_RATIO = 0.55
BOSS_COMMANDER_COOLDOWN_BASE = 8.0
BOSS_COMMANDER_CAST_DURATION = 0.68
BOSS_AMBUSH_COOLDOWN_BASE = 4.8
BOSS_AMBUSH_WINDUP = 0.24
BOSS_AMBUSH_LENGTH = 210.0
BOSS_AMBUSH_HALF_WIDTH = 38.0
BOSS_AMBUSH_CONTACT_LOCKOUT = 0.25
BOSS_ZONE_CAST_RADIUS = 104.0
BOSS_ZONE_CAST_DAMAGE = 22
BOSS_ZONE_CAST_ARM_TIME = 0.65
BOSS_ZONE_CAST_ACTIVE_TIME = 1.25
BOSS_ZONE_CAST_TICK_INTERVAL = 0.30


class Zombie:
    """Zombie unit that follows player and can take damage."""

    def __init__(self, x: float, y: float, kind: ZombieType = ZombieType.WALKER):
        """Initialize Zombie runtime state."""
        self.position = pygame.Vector2(x, y)
        self.kind = kind
        stats = ZOMBIE_STATS[kind]

        # Core combat values copied from static archetype stats.
        self.base_speed = stats.speed
        self.speed = stats.speed
        self.radius = stats.radius
        self.max_health = stats.max_health
        self.health = stats.max_health
        self.damage = stats.damage
        self.color = stats.color
        self.score_value = stats.score_value
        self.coin_value = stats.coin_value
        self.flank_bias = random.choice((-1.0, 1.0))
        self.burst_timer = 0.0
        self.burst_cooldown = random.uniform(0.0, BURST_COOLDOWN * 0.35)
        self.boss_phase = 1
        self.boss_charge_timer = 0.0
        self.boss_charge_cooldown = random.uniform(0.0, BOSS_CHARGE_COOLDOWN_BASE * 0.4)
        self.boss_leap_timer = 0.0
        self.boss_leap_cooldown = random.uniform(0.0, BOSS_LEAP_COOLDOWN_BASE * 0.4)
        self.boss_commander_cooldown = random.uniform(2.0, BOSS_COMMANDER_COOLDOWN_BASE * 0.7)
        self.commander_call_pending = False
        self.slam_pulse_pending = False
        self.zone_cast_pending = False
        self.ambush_pulse_pending = False
        self.slam_radius = 0.0
        self.slam_damage = 0
        self.zone_cast_centers: list[pygame.Vector2] = []
        self.zone_cast_radius = BOSS_ZONE_CAST_RADIUS
        self.zone_cast_damage = BOSS_ZONE_CAST_DAMAGE
        self.zone_cast_arm_time = BOSS_ZONE_CAST_ARM_TIME
        self.zone_cast_active_time = BOSS_ZONE_CAST_ACTIVE_TIME
        self.zone_cast_tick_interval = BOSS_ZONE_CAST_TICK_INTERVAL
        self.ambush_origin = pygame.Vector2(self.position)
        self.ambush_direction = pygame.Vector2(1, 0)
        self.ambush_length = BOSS_AMBUSH_LENGTH
        self.ambush_half_width = BOSS_AMBUSH_HALF_WIDTH
        self.ambush_damage = 0
        self.ambush_contact_lockout = BOSS_AMBUSH_CONTACT_LOCKOUT
        self.boss_archetype = BossArchetype.WARDEN.value
        self.boss_speed_multiplier = 1.0
        self.boss_charge_cooldown_mult = 1.0
        self.boss_leap_cooldown_mult = 1.0
        self.boss_commander_cooldown_mult = 1.0
        self.boss_escort_count_scale = 1.0
        self.boss_escort_runner_bias = 0.0
        self.boss_slam_radius_mult = 1.0
        self.boss_slam_damage_mult = 1.0
        self.boss_commander_cast_interrupted = False
        self.boss_charge_windup_timer = 0.0
        self.boss_charge_windup_dir = pygame.Vector2()
        self.boss_charge_recovery_timer = 0.0
        self.boss_leap_windup_timer = 0.0
        self.boss_leap_target = pygame.Vector2(self.position)
        self.boss_leap_preview_radius = 0.0
        self.boss_leap_core_radius = 0.0
        self.boss_leap_commit_player_pos = pygame.Vector2(self.position)
        self.boss_leap_axis = pygame.Vector2()
        self.boss_commander_cast_timer = 0.0
        self.boss_commander_interrupt_progress = 0
        self.boss_commander_interrupt_threshold = 0
        self.boss_stagger_timer = 0.0
        self.boss_zone_commit_player_pos = pygame.Vector2(self.position)
        self.boss_zone_commit_player_velocity = pygame.Vector2()
        self.boss_ambush_cooldown = random.uniform(1.0, BOSS_AMBUSH_COOLDOWN_BASE * 0.45)
        self.boss_ambush_windup_timer = 0.0
        self.boss_ambush_commit_player_pos = pygame.Vector2(self.position)
        self.boss_ambush_commit_player_velocity = pygame.Vector2()

    @staticmethod
    def role_side(role: str) -> float:
        """Return -1/1 side multiplier for role variants."""
        token = str(role or ROLE_CHASE).strip().lower()
        if token.endswith("_left"):
            return -1.0
        if token.endswith("_right"):
            return 1.0
        return 0.0

    def consume_commander_call(self) -> bool:
        """Return True once when boss commander call is queued."""
        # Pending flag is consumed exactly once per emitted call.
        if not bool(getattr(self, "commander_call_pending", False)):
            return False
        self.commander_call_pending = False
        return True

    def consume_slam_pulse(self) -> tuple[float, int] | None:
        """Return (radius, damage) once when boss leap slam pulse triggers."""
        # Pulse is single-use to avoid repeated damage from one leap.
        if not bool(getattr(self, "slam_pulse_pending", False)):
            return None
        self.slam_pulse_pending = False
        return (float(getattr(self, "slam_radius", 0.0)), int(getattr(self, "slam_damage", 0)))

    def consume_zone_cast(self) -> tuple[list[pygame.Vector2], float, int, float, float, float] | None:
        """Return queued zone-cast payload once when boss caster resolves."""
        if not bool(getattr(self, "zone_cast_pending", False)):
            return None
        self.zone_cast_pending = False
        centers = [pygame.Vector2(center) for center in list(getattr(self, "zone_cast_centers", []))]
        return (
            centers,
            float(getattr(self, "zone_cast_radius", BOSS_ZONE_CAST_RADIUS)),
            int(getattr(self, "zone_cast_damage", BOSS_ZONE_CAST_DAMAGE)),
            float(getattr(self, "zone_cast_arm_time", BOSS_ZONE_CAST_ARM_TIME)),
            float(getattr(self, "zone_cast_active_time", BOSS_ZONE_CAST_ACTIVE_TIME)),
            float(getattr(self, "zone_cast_tick_interval", BOSS_ZONE_CAST_TICK_INTERVAL)),
        )

    def consume_ambush_pulse(self) -> tuple[pygame.Vector2, pygame.Vector2, float, float, int, float] | None:
        """Return queued stealth ambush payload once when strike commits."""
        if not bool(getattr(self, "ambush_pulse_pending", False)):
            return None
        self.ambush_pulse_pending = False
        return (
            pygame.Vector2(getattr(self, "ambush_origin", self.position)),
            pygame.Vector2(getattr(self, "ambush_direction", pygame.Vector2(1, 0))),
            float(getattr(self, "ambush_length", BOSS_AMBUSH_LENGTH)),
            float(getattr(self, "ambush_half_width", BOSS_AMBUSH_HALF_WIDTH)),
            int(getattr(self, "ambush_damage", 0)),
            float(getattr(self, "ambush_contact_lockout", BOSS_AMBUSH_CONTACT_LOCKOUT)),
        )

    def _boss_slam_radius_for_phase(self, phase: int) -> float:
        """Return phase-scaled leap slam radius used by telegraph and impact."""
        base_radius = 92.0 + max(1, int(phase)) * 18.0
        return float(base_radius) * float(getattr(self, "boss_slam_radius_mult", 1.0))

    def set_boss_archetype(self, archetype: str | BossArchetype | None) -> None:
        """Apply boss-archetype runtime multipliers and cooldown profiles."""
        if self.kind != ZombieType.BOSS:
            return

        # Normalize external value into known internal archetype token.
        token = archetype.value if isinstance(archetype, BossArchetype) else str(archetype or "").strip().lower()
        if token not in {
            BossArchetype.WARDEN.value,
            BossArchetype.RAVAGER.value,
            BossArchetype.BROODLORD.value,
            BossArchetype.PHANTOM.value,
            BossArchetype.ZONE_CASTER.value,
            BossArchetype.STEALTH_ASSASSIN.value,
        }:
            token = BossArchetype.WARDEN.value
        self.boss_archetype = token

        self.boss_speed_multiplier = 1.0
        self.boss_charge_cooldown_mult = 1.0
        self.boss_leap_cooldown_mult = 1.0
        self.boss_commander_cooldown_mult = 1.0
        self.boss_escort_count_scale = 1.0
        self.boss_escort_runner_bias = 0.0
        self.boss_slam_radius_mult = 1.0
        self.boss_slam_damage_mult = 1.0
        self.zone_cast_radius = BOSS_ZONE_CAST_RADIUS
        self.zone_cast_damage = BOSS_ZONE_CAST_DAMAGE
        self.zone_cast_arm_time = BOSS_ZONE_CAST_ARM_TIME
        self.zone_cast_active_time = BOSS_ZONE_CAST_ACTIVE_TIME
        self.zone_cast_tick_interval = BOSS_ZONE_CAST_TICK_INTERVAL
        self.ambush_length = BOSS_AMBUSH_LENGTH
        self.ambush_half_width = BOSS_AMBUSH_HALF_WIDTH
        self.ambush_contact_lockout = BOSS_AMBUSH_CONTACT_LOCKOUT

        # Each archetype branch applies flavor identity through stat multipliers.
        if token == BossArchetype.WARDEN.value:
            self.max_health = max(1, int(round(self.max_health * 1.30)))
            self.health = self.max_health
            self.base_speed *= 0.88
            self.speed = self.base_speed
            self.boss_escort_count_scale = 0.72
            self.boss_slam_radius_mult = 1.25
            self.boss_slam_damage_mult = 1.20
        elif token == BossArchetype.RAVAGER.value:
            self.max_health = max(1, int(round(self.max_health * 0.90)))
            self.health = self.max_health
            self.base_speed *= 1.22
            self.speed = self.base_speed
            self.boss_charge_cooldown_mult = 0.75
            self.boss_leap_cooldown_mult = 0.75
            self.boss_commander_cooldown_mult = 1.30
            self.boss_escort_count_scale = 0.84
        elif token == BossArchetype.BROODLORD.value:
            # Broodlord.
            self.damage = max(1, int(round(self.damage * 0.92)))
            self.base_speed *= 0.95
            self.speed = self.base_speed
            self.boss_commander_cooldown_mult = 0.65
            self.boss_escort_runner_bias = 0.24
        elif token == BossArchetype.PHANTOM.value:
            # Phantom.
            self.max_health = max(1, int(round(self.max_health * 0.82)))
            self.health = self.max_health
            self.base_speed *= 1.12
            self.speed = self.base_speed
            self.boss_charge_cooldown_mult = 1.18
            self.boss_leap_cooldown_mult = 0.58
            self.boss_commander_cooldown_mult = 1.08
            self.boss_escort_count_scale = 0.66
            self.boss_escort_runner_bias = 0.08
            self.boss_slam_radius_mult = 0.90
            self.boss_slam_damage_mult = 0.88
        elif token == BossArchetype.ZONE_CASTER.value:
            self.max_health = max(1, int(round(self.max_health * 1.08)))
            self.health = self.max_health
            self.damage = max(1, int(round(self.damage * 0.90)))
            self.base_speed *= 0.90
            self.speed = self.base_speed
            self.boss_charge_cooldown_mult = 1.35
            self.boss_leap_cooldown_mult = 1.25
            self.boss_commander_cooldown_mult = 0.70
            self.boss_escort_count_scale = 0.70
        else:
            # Stealth Assassin.
            self.max_health = max(1, int(round(self.max_health * 0.78)))
            self.health = self.max_health
            self.damage = max(1, int(round(self.damage * 1.05)))
            self.base_speed *= 1.28
            self.speed = self.base_speed
            self.boss_charge_cooldown_mult = 1.40
            self.boss_leap_cooldown_mult = 1.35
            self.boss_commander_cooldown_mult = 1.50
            self.boss_escort_count_scale = 0.62

        self.boss_commander_interrupt_threshold = max(24, int(round(self.max_health * 0.05)))

    def register_channel_damage(self, damage: int) -> bool:
        """Apply damage toward commander-channel interrupt; return True when interrupted."""
        if self.kind != ZombieType.BOSS:
            return False
        if float(getattr(self, "boss_commander_cast_timer", 0.0)) <= 0.0:
            return False

        self.boss_commander_interrupt_progress = int(getattr(self, "boss_commander_interrupt_progress", 0)) + max(0, int(damage))
        threshold = max(1, int(getattr(self, "boss_commander_interrupt_threshold", 1)))
        if self.boss_commander_interrupt_progress < threshold:
            return False

        # Interrupt cancels cast and applies stagger/cooldown penalties.
        self.boss_commander_cast_timer = 0.0
        self.boss_commander_cast_interrupted = True
        self.commander_call_pending = False
        self.boss_commander_interrupt_progress = 0
        self.boss_stagger_timer = max(0.6, float(getattr(self, "boss_stagger_timer", 0.0)))
        self.boss_commander_cooldown = max(2.2, float(getattr(self, "boss_commander_cooldown", 0.0)))
        return True

    def _update_boss_phase_from_health(self) -> None:
        """Update boss phase based on remaining health thresholds."""
        if self.kind != ZombieType.BOSS:
            return
        if self.max_health <= 0:
            self.boss_phase = 1
            return
        ratio = self.health / self.max_health
        # Lower health phases unlock higher aggression windows.
        if ratio <= 0.35:
            self.boss_phase = 3
        elif ratio <= 0.70:
            self.boss_phase = 2
        else:
            self.boss_phase = 1

    @staticmethod
    def spawn_near_view(world_rect: pygame.Rect, view_rect: pygame.Rect, kind: ZombieType) -> "Zombie":
        """Spawn just outside current camera view while respecting world bounds."""
        margin = 40
        left = max(world_rect.left + 20, view_rect.left - margin)
        right = min(world_rect.right - 20, view_rect.right + margin)
        top = max(world_rect.top + 20, view_rect.top - margin)
        bottom = min(world_rect.bottom - 20, view_rect.bottom + margin)

        side = random.choice(["top", "bottom", "left", "right"])
        # Randomize spawn side to reduce predictable approach patterns.
        if side == "top":
            x = random.uniform(left, right)
            y = top
        elif side == "bottom":
            x = random.uniform(left, right)
            y = bottom
        elif side == "left":
            x = left
            y = random.uniform(top, bottom)
        else:
            x = right
            y = random.uniform(top, bottom)

        return Zombie(x, y, kind=kind)

    def update(
        self,
        dt: float,
        player_position: pygame.Vector2,
        speed_multiplier: float = 1.0,
        *,
        player_velocity: pygame.Vector2 | None = None,
        nearby_zombies: list["Zombie"] | None = None,
        surround_strength: float = 0.0,
        role: str = ROLE_CHASE,
        pack_pressure: float = 0.0,
    ) -> None:
        """Move zombie using role-driven pack pressure and micro overlap correction."""
        to_player = player_position - self.position
        distance = to_player.length()
        base_dir = pygame.Vector2()
        if distance > 0:
            base_dir = to_player.normalize()

        safe_pressure = max(0.0, min(1.0, max(float(surround_strength), float(pack_pressure))))
        role_token = str(role or ROLE_CHASE).strip().lower()
        if role_token not in {ROLE_CHASE, ROLE_CUTTER_LEFT, ROLE_CUTTER_RIGHT, ROLE_FLANK_LEFT, ROLE_FLANK_RIGHT}:
            role_token = ROLE_CHASE

        velocity = pygame.Vector2(player_velocity) if player_velocity is not None else pygame.Vector2()
        player_speed = velocity.length()
        # Movement direction fallback keeps steering stable when player is stationary.
        if player_speed > 0:
            player_move_dir = velocity.normalize()
        elif base_dir.length_squared() > 0:
            player_move_dir = pygame.Vector2(base_dir)
        else:
            player_move_dir = pygame.Vector2(1, 0)

        lateral = pygame.Vector2(-player_move_dir.y, player_move_dir.x)
        intercept_lead = min(
            INTERCEPT_MAX_LEAD,
            max(INTERCEPT_MIN_LEAD, distance / max(130.0, self.base_speed * 2.0)),
        )
        intercept_lead *= 1.0 + safe_pressure * 0.65
        intercept_target = player_position + velocity * intercept_lead

        role_target = pygame.Vector2(intercept_target)
        side = self.role_side(role_token)
        if side == 0.0 and role_token != ROLE_CHASE:
            side = float(self.flank_bias)

        if role_token in {ROLE_CUTTER_LEFT, ROLE_CUTTER_RIGHT}:
            ahead = CUTTER_AHEAD_DISTANCE * (0.74 + safe_pressure * 0.78)
            side_dist = CUTTER_LATERAL_DISTANCE * (0.55 + safe_pressure * 0.70)
            role_target = player_position + player_move_dir * ahead + lateral * side * side_dist
        elif role_token in {ROLE_FLANK_LEFT, ROLE_FLANK_RIGHT}:
            ahead = FLANK_AHEAD_DISTANCE * (0.72 + safe_pressure * 0.50)
            side_dist = FLANK_LATERAL_DISTANCE * (0.60 + safe_pressure * 0.62)
            role_target = player_position + player_move_dir * ahead + lateral * side * side_dist

        intercept_vec = intercept_target - self.position
        role_vec = role_target - self.position
        steer_vec = pygame.Vector2(intercept_vec)
        if role_token != ROLE_CHASE and role_vec.length_squared() > 0:
            role_weight = 0.78 + safe_pressure * 0.20
            if player_speed < 62.0:
                role_weight *= 0.28
            role_weight = max(0.0, min(1.0, role_weight))
            steer_vec = intercept_vec * (1.0 - role_weight * ROLE_INTERCEPT_WEIGHT) + role_vec * (role_weight * ROLE_INTERCEPT_WEIGHT)

        overlap_push = pygame.Vector2()
        if nearby_zombies:
            # Local separation avoids identical-position clumps in dense packs.
            for other in nearby_zombies:
                if other is self:
                    continue
                offset = self.position - other.position
                dist_sq = offset.length_squared()
                overlap_distance = max(5.0, (self.radius + other.radius) * MICRO_OVERLAP_FACTOR)
                if dist_sq <= 0.0:
                    overlap_push += pygame.Vector2(self.flank_bias, 0.35)
                    continue
                dist = dist_sq**0.5
                if dist >= overlap_distance:
                    continue
                intensity = (overlap_distance - dist) / overlap_distance
                overlap_push += (offset / dist) * intensity

        if overlap_push.length_squared() > 0:
            steer_vec += overlap_push.normalize() * MICRO_OVERLAP_WEIGHT

        if steer_vec.length_squared() > 0:
            steer = steer_vec.normalize()
        else:
            steer = base_dir

        if self.kind == ZombieType.BOSS:
            # Boss update branch handles phased abilities and special movement.
            self._update_boss_phase_from_health()
            phase = max(1, int(getattr(self, "boss_phase", 1)))
            prev_leap_timer = float(getattr(self, "boss_leap_timer", 0.0))
            prev_charge_windup = float(getattr(self, "boss_charge_windup_timer", 0.0))
            prev_leap_windup = float(getattr(self, "boss_leap_windup_timer", 0.0))
            prev_ambush_windup = float(getattr(self, "boss_ambush_windup_timer", 0.0))
            prev_commander_cast = float(getattr(self, "boss_commander_cast_timer", 0.0))
            self.boss_charge_timer = max(0.0, float(getattr(self, "boss_charge_timer", 0.0)) - dt)
            self.boss_charge_cooldown = max(0.0, float(getattr(self, "boss_charge_cooldown", 0.0)) - dt)
            self.boss_leap_timer = max(0.0, prev_leap_timer - dt)
            self.boss_leap_cooldown = max(0.0, float(getattr(self, "boss_leap_cooldown", 0.0)) - dt)
            self.boss_ambush_cooldown = max(0.0, float(getattr(self, "boss_ambush_cooldown", 0.0)) - dt)
            self.boss_commander_cooldown = max(0.0, float(getattr(self, "boss_commander_cooldown", 0.0)) - dt)
            self.boss_charge_windup_timer = max(0.0, prev_charge_windup - dt)
            self.boss_leap_windup_timer = max(0.0, prev_leap_windup - dt)
            self.boss_ambush_windup_timer = max(0.0, prev_ambush_windup - dt)
            self.boss_charge_recovery_timer = max(0.0, float(getattr(self, "boss_charge_recovery_timer", 0.0)) - dt)
            self.boss_stagger_timer = max(0.0, float(getattr(self, "boss_stagger_timer", 0.0)) - dt)
            self.boss_commander_cast_timer = max(0.0, prev_commander_cast - dt)

            if prev_leap_timer > 0.0 and self.boss_leap_timer == 0.0:
                # Leap impact resolves as one deferred slam pulse consumed by Game logic.
                self.slam_pulse_pending = True
                self.slam_radius = float(getattr(self, "boss_leap_preview_radius", 0.0))
                if self.slam_radius <= 0.0:
                    self.slam_radius = self._boss_slam_radius_for_phase(phase)
                self.boss_leap_core_radius = self.slam_radius * BOSS_LEAP_DODGE_CORE_RATIO
                base_slam_damage = self.damage * (0.52 + phase * 0.20)
                self.slam_damage = max(1, int(round(base_slam_damage * float(getattr(self, "boss_slam_damage_mult", 1.0)))))
                self.position = pygame.Vector2(getattr(self, "boss_leap_target", self.position))

            if prev_commander_cast > 0.0 and self.boss_commander_cast_timer == 0.0:
                if bool(getattr(self, "boss_commander_cast_interrupted", False)):
                    self.commander_call_pending = False
                    self.zone_cast_pending = False
                    self.boss_commander_cast_interrupted = False
                else:
                    # Successful cast completion queues archetype-specific payload.
                    if str(getattr(self, "boss_archetype", "")) == BossArchetype.ZONE_CASTER.value:
                        commit_pos = pygame.Vector2(getattr(self, "boss_zone_commit_player_pos", player_position))
                        commit_velocity = pygame.Vector2(getattr(self, "boss_zone_commit_player_velocity", pygame.Vector2()))
                        move_dir = pygame.Vector2(commit_velocity)
                        if move_dir.length_squared() == 0.0:
                            move_dir = commit_pos - self.position
                        if move_dir.length_squared() == 0.0:
                            move_dir = pygame.Vector2(base_dir if base_dir.length_squared() > 0.0 else steer)
                        if move_dir.length_squared() == 0.0:
                            move_dir = pygame.Vector2(1, 0)
                        move_dir = move_dir.normalize()
                        lateral = pygame.Vector2(-move_dir.y, move_dir.x)
                        self.zone_cast_centers = [
                            pygame.Vector2(commit_pos),
                            pygame.Vector2(commit_pos + lateral * 120.0),
                            pygame.Vector2(commit_pos - lateral * 120.0),
                        ]
                        self.zone_cast_pending = True
                        self.commander_call_pending = False
                    else:
                        self.commander_call_pending = True
                        self.zone_cast_pending = False
                    self.boss_commander_interrupt_progress = 0
                    commander_cd = max(3.0, BOSS_COMMANDER_COOLDOWN_BASE - (phase - 1) * 1.4)
                    commander_cd *= float(getattr(self, "boss_commander_cooldown_mult", 1.0))
                    self.boss_commander_cooldown = max(float(getattr(self, "boss_commander_cooldown", 0.0)), commander_cd)

            if prev_charge_windup > 0.0 and self.boss_charge_windup_timer == 0.0:
                charge_cd = max(1.4, BOSS_CHARGE_COOLDOWN_BASE - (phase - 1) * 0.85)
                charge_cd *= float(getattr(self, "boss_charge_cooldown_mult", 1.0))
                dodge_success = False
                windup_dir = pygame.Vector2(getattr(self, "boss_charge_windup_dir", pygame.Vector2()))
                if windup_dir.length_squared() > 0.0:
                    windup_dir = windup_dir.normalize()
                    offset = player_position - self.position
                    # Cross-product magnitude gives lateral distance from charge axis.
                    lateral = abs((offset.x * windup_dir.y) - (offset.y * windup_dir.x))
                    dodge_success = lateral >= BOSS_CHARGE_DODGE_DISTANCE
                if dodge_success:
                    self.boss_charge_recovery_timer = max(
                        float(getattr(self, "boss_charge_recovery_timer", 0.0)),
                        BOSS_CHARGE_RECOVERY_DURATION,
                    )
                    self.boss_charge_cooldown = max(float(getattr(self, "boss_charge_cooldown", 0.0)), charge_cd * 0.82)
                else:
                    self.boss_charge_timer = BOSS_CHARGE_DURATION * (1.0 + (phase - 1) * 0.16)
                    self.boss_charge_cooldown = max(float(getattr(self, "boss_charge_cooldown", 0.0)), charge_cd)

            if prev_leap_windup > 0.0 and self.boss_leap_windup_timer == 0.0:
                leap_cd = max(1.8, BOSS_LEAP_COOLDOWN_BASE - (phase - 1) * 1.15)
                leap_cd *= float(getattr(self, "boss_leap_cooldown_mult", 1.0))
                self.boss_leap_timer = BOSS_LEAP_DURATION * (1.0 + (phase - 1) * 0.20)
                self.boss_leap_cooldown = max(float(getattr(self, "boss_leap_cooldown", 0.0)), leap_cd)
                self.boss_leap_target = pygame.Vector2(player_position)
                # Snapshot player state at commit so slam dodge can be skill-evaluated later.
                self.boss_leap_preview_radius = self._boss_slam_radius_for_phase(phase)
                self.boss_leap_core_radius = self.boss_leap_preview_radius * BOSS_LEAP_DODGE_CORE_RATIO
                self.boss_leap_commit_player_pos = pygame.Vector2(player_position)
                leap_axis = self.boss_leap_target - self.position
                if leap_axis.length_squared() == 0.0:
                    leap_axis = pygame.Vector2(base_dir if base_dir.length_squared() > 0.0 else steer)
                if leap_axis.length_squared() == 0.0:
                    leap_axis = pygame.Vector2(1, 0)
                self.boss_leap_axis = leap_axis.normalize()

            if prev_ambush_windup > 0.0 and self.boss_ambush_windup_timer == 0.0:
                ambush_cd = max(1.8, BOSS_AMBUSH_COOLDOWN_BASE - (phase - 1) * 1.0)
                self.boss_ambush_cooldown = max(float(getattr(self, "boss_ambush_cooldown", 0.0)), ambush_cd)
                commit_pos = pygame.Vector2(getattr(self, "boss_ambush_commit_player_pos", player_position))
                commit_velocity = pygame.Vector2(getattr(self, "boss_ambush_commit_player_velocity", pygame.Vector2()))
                move_dir = pygame.Vector2(commit_velocity)
                if move_dir.length_squared() == 0.0:
                    move_dir = commit_pos - self.position
                if move_dir.length_squared() == 0.0:
                    move_dir = pygame.Vector2(base_dir if base_dir.length_squared() > 0.0 else steer)
                if move_dir.length_squared() == 0.0:
                    move_dir = pygame.Vector2(1, 0)
                move_dir = move_dir.normalize()
                lateral = pygame.Vector2(-move_dir.y, move_dir.x)
                side = -1.0 if float(getattr(self, "flank_bias", 1.0)) < 0.0 else 1.0
                self.position = pygame.Vector2(commit_pos + lateral * (side * 136.0) - move_dir * 44.0)
                strike_dir = commit_pos - self.position
                if strike_dir.length_squared() == 0.0:
                    strike_dir = pygame.Vector2(move_dir)
                if strike_dir.length_squared() == 0.0:
                    strike_dir = pygame.Vector2(1, 0)
                self.ambush_origin = pygame.Vector2(self.position)
                self.ambush_direction = strike_dir.normalize()
                self.ambush_length = BOSS_AMBUSH_LENGTH
                self.ambush_half_width = BOSS_AMBUSH_HALF_WIDTH
                base_ambush_damage = self.damage * (0.46 + phase * 0.16)
                self.ambush_damage = max(1, int(round(base_ambush_damage)))
                self.ambush_contact_lockout = BOSS_AMBUSH_CONTACT_LOCKOUT
                self.ambush_pulse_pending = True

            if (
                self.boss_charge_timer == 0.0
                and self.boss_leap_timer == 0.0
                and self.boss_ambush_windup_timer == 0.0
                and self.boss_charge_windup_timer == 0.0
                and self.boss_leap_windup_timer == 0.0
                and self.boss_commander_cast_timer == 0.0
                and self.boss_charge_recovery_timer == 0.0
                and self.boss_stagger_timer == 0.0
            ):
                # Ability selection order biases charge > leap > commander when all ready.
                archetype = str(getattr(self, "boss_archetype", ""))
                if archetype == BossArchetype.STEALTH_ASSASSIN.value and self.boss_ambush_cooldown == 0.0 and 90.0 < distance < 520.0:
                    self.boss_ambush_windup_timer = BOSS_AMBUSH_WINDUP * (1.0 + (phase - 1) * 0.06)
                    self.boss_ambush_commit_player_pos = pygame.Vector2(player_position)
                    self.boss_ambush_commit_player_velocity = pygame.Vector2(velocity)
                elif self.boss_charge_cooldown == 0.0 and 170.0 < distance < 620.0:
                    self.boss_charge_windup_timer = BOSS_CHARGE_WINDUP * (1.0 + (phase - 1) * 0.05)
                    windup_direction = pygame.Vector2(base_dir if base_dir.length_squared() > 0.0 else steer)
                    if windup_direction.length_squared() == 0.0:
                        windup_direction = pygame.Vector2(1, 0)
                    self.boss_charge_windup_dir = windup_direction.normalize()
                elif archetype != BossArchetype.STEALTH_ASSASSIN.value and self.boss_leap_cooldown == 0.0 and 96.0 < distance < 360.0:
                    self.boss_leap_windup_timer = BOSS_LEAP_WINDUP * (1.0 + (phase - 1) * 0.05)
                    self.boss_leap_target = pygame.Vector2(player_position)
                    self.boss_leap_preview_radius = self._boss_slam_radius_for_phase(phase)
                    self.boss_leap_core_radius = self.boss_leap_preview_radius * BOSS_LEAP_DODGE_CORE_RATIO
                elif self.boss_commander_cooldown == 0.0 and distance < 760.0:
                    self.boss_commander_cast_timer = BOSS_COMMANDER_CAST_DURATION * (1.0 + (phase - 1) * 0.04)
                    self.boss_commander_cast_interrupted = False
                    self.boss_commander_interrupt_progress = 0
                    self.boss_commander_interrupt_threshold = max(20, int(round(self.max_health * 0.05)))
                    self.boss_zone_commit_player_pos = pygame.Vector2(player_position)
                    self.boss_zone_commit_player_velocity = pygame.Vector2(velocity)

            if self.boss_leap_windup_timer > 0.0:
                # Keep telegraph radius synced with live phase scaling while windup is active.
                self.boss_leap_preview_radius = self._boss_slam_radius_for_phase(phase)
                self.boss_leap_core_radius = self.boss_leap_preview_radius * BOSS_LEAP_DODGE_CORE_RATIO

            speed = self.base_speed * speed_multiplier * float(getattr(self, "boss_speed_multiplier", 1.0))
            speed *= 1.08 + (phase - 1) * 0.16
            # Animation-like speed dampening during windups/recovery states.
            if self.boss_stagger_timer > 0.0:
                speed *= 0.45
            elif self.boss_charge_recovery_timer > 0.0:
                speed *= 0.58
            elif self.boss_commander_cast_timer > 0.0:
                speed *= 0.64
            elif self.boss_charge_windup_timer > 0.0 or self.boss_leap_windup_timer > 0.0 or self.boss_ambush_windup_timer > 0.0:
                speed *= 0.72

            if self.boss_charge_timer > 0.0:
                dash_dir = pygame.Vector2(getattr(self, "boss_charge_windup_dir", steer))
                if dash_dir.length_squared() > 0.0:
                    steer = dash_dir.normalize()
                speed *= BOSS_CHARGE_SPEED_MULT + (phase - 1) * 0.08
            elif self.boss_leap_timer > 0.0:
                leap_vec = pygame.Vector2(getattr(self, "boss_leap_target", self.position)) - self.position
                if leap_vec.length_squared() > 0.0:
                    steer = leap_vec.normalize()
                speed *= BOSS_LEAP_SPEED_MULT + (phase - 1) * 0.06

            self.speed = speed
            self.position += steer * self.speed * dt
            return

        self.burst_timer = max(0.0, float(getattr(self, "burst_timer", 0.0)) - dt)
        self.burst_cooldown = max(0.0, float(getattr(self, "burst_cooldown", 0.0)) - dt)
        role_is_pressure = role_token in {ROLE_CUTTER_LEFT, ROLE_CUTTER_RIGHT, ROLE_FLANK_LEFT, ROLE_FLANK_RIGHT}
        if (
            role_is_pressure
            and self.burst_timer == 0.0
            and self.burst_cooldown == 0.0
            and BURST_TRIGGER_MIN_DISTANCE < distance < BURST_TRIGGER_MAX_DISTANCE
            and (player_speed >= BURST_TRIGGER_PLAYER_SPEED or safe_pressure >= 0.42)
        ):
            self.burst_timer = BURST_DURATION * (1.0 + safe_pressure * 0.35)
            self.burst_cooldown = BURST_COOLDOWN * max(0.65, 1.0 - safe_pressure * 0.20)

        speed = self.base_speed * speed_multiplier
        if self.burst_timer > 0.0:
            # Temporary burst gives pressure roles a short engage spike.
            speed *= BURST_SPEED_MULT + safe_pressure * BURST_PRESSURE_SPEED_BONUS
            if role_token in {ROLE_CUTTER_LEFT, ROLE_CUTTER_RIGHT}:
                speed *= 1.06
        self.speed = speed
        self.position += steer * self.speed * dt

    def take_damage(self, amount: int) -> bool:
        """Apply damage and return True if this zombie died."""
        self.health = max(0, self.health - int(amount))
        self._update_boss_phase_from_health()
        return self.health <= 0

    def draw(self, screen: pygame.Surface, screen_position: pygame.Vector2 | None = None) -> None:
        """Render zombie body and small health bar for tougher units."""
        position = screen_position or self.position
        center = (int(position.x), int(position.y))
        if self.kind == ZombieType.BOSS:
            # Telegraph overlays expose boss intent before attack commits.
            if float(getattr(self, "boss_charge_windup_timer", 0.0)) > 0.0:
                direction = pygame.Vector2(getattr(self, "boss_charge_windup_dir", pygame.Vector2()))
                if direction.length_squared() > 0.0:
                    tip = position + direction.normalize() * 138.0
                    pygame.draw.line(
                        screen,
                        (255, 154, 96),
                        center,
                        (int(tip.x), int(tip.y)),
                        4,
                    )
            if float(getattr(self, "boss_leap_windup_timer", 0.0)) > 0.0:
                target = position + (pygame.Vector2(getattr(self, "boss_leap_target", self.position)) - self.position)
                outer_radius = int(max(28.0, float(getattr(self, "boss_leap_preview_radius", 0.0))))
                inner_radius = int(max(14.0, float(getattr(self, "boss_leap_core_radius", 0.0))))
                pygame.draw.circle(screen, (255, 126, 126), (int(target.x), int(target.y)), outer_radius, 3)
                pygame.draw.circle(screen, (255, 88, 88), (int(target.x), int(target.y)), inner_radius, 2)
            if float(getattr(self, "boss_ambush_windup_timer", 0.0)) > 0.0:
                target = pygame.Vector2(getattr(self, "boss_ambush_commit_player_pos", self.position))
                strike_dir = target - position
                if strike_dir.length_squared() == 0.0:
                    strike_dir = pygame.Vector2(getattr(self, "ambush_direction", pygame.Vector2(1, 0)))
                if strike_dir.length_squared() == 0.0:
                    strike_dir = pygame.Vector2(1, 0)
                strike_dir = strike_dir.normalize()
                lane_tip = position + strike_dir * float(getattr(self, "ambush_length", BOSS_AMBUSH_LENGTH))
                pygame.draw.line(
                    screen,
                    (180, 242, 255),
                    center,
                    (int(lane_tip.x), int(lane_tip.y)),
                    3,
                )
                pygame.draw.circle(screen, (116, 224, 248), (int(target.x), int(target.y)), 22, 2)
            if float(getattr(self, "boss_commander_cast_timer", 0.0)) > 0.0:
                ring_radius = int(self.radius + 16 + self.boss_commander_cast_timer * 14.0)
                pygame.draw.circle(screen, (196, 140, 255), center, ring_radius, 3)

        pygame.draw.circle(screen, self.color, center, self.radius)

        if self.max_health > 35:
            # Render health bar only for units durable enough to justify UI space.
            bar_width = self.radius * 2
            bar_height = 5
            ratio = 0 if self.max_health == 0 else self.health / self.max_health
            top_left_x = int(position.x - self.radius)
            top_left_y = int(position.y - self.radius - 10)
            pygame.draw.rect(screen, (50, 25, 25), (top_left_x, top_left_y, bar_width, bar_height))
            pygame.draw.rect(screen, (220, 70, 70), (top_left_x, top_left_y, int(bar_width * ratio), bar_height))

"""Weapon catalog and runtime inventory/combat state."""

from __future__ import annotations

from dataclasses import dataclass
import math
import random
from typing import Literal

import pygame

FireMode = Literal["single", "auto", "burst"]


@dataclass(frozen=True)
class WeaponSpec:
    """Immutable gameplay tuning for one weapon type."""

    key: str
    display_name: str
    price_points: int
    damage: int
    fire_mode: FireMode
    cooldown: float
    magazine_size: int
    reserve_ammo: int | None
    reload_time: float
    projectile_speed: float
    required_area: str
    unlock_wave: int
    pellet_count: int = 1
    pellet_spread_degrees: float = 0.0
    burst_count: int = 1
    burst_interval: float = 0.0
    projectile_radius: int = 4


@dataclass
class WeaponState:
    """Mutable runtime state for one equipped weapon."""

    spec_key: str
    ammo_in_mag: int
    reserve_ammo: int | None
    cooldown_timer: float = 0.0
    reload_timer: float = 0.0
    is_reloading: bool = False
    pending_burst_shots: int = 0
    burst_interval_timer: float = 0.0


@dataclass(frozen=True)
class ProjectileSpawn:
    """Parameters needed to spawn one projectile in the world."""

    direction: pygame.Vector2
    speed: float
    radius: int
    damage: int


WEAPON_CATALOG: dict[str, WeaponSpec] = {
    # Catalog rows are static tuning data; runtime state lives in WeaponState objects.
    "pistol": WeaponSpec(
        key="pistol",
        display_name="Pistol",
        price_points=0,
        damage=16,
        fire_mode="single",
        cooldown=0.30,
        magazine_size=12,
        reserve_ammo=None,
        reload_time=1.10,
        projectile_speed=560.0,
        required_area="spawn",
        unlock_wave=1,
    ),
    "shotgun": WeaponSpec(
        key="shotgun",
        display_name="Shotgun",
        price_points=280,
        damage=13,
        fire_mode="single",
        cooldown=0.78,
        magazine_size=6,
        reserve_ammo=36,
        reload_time=2.00,
        projectile_speed=520.0,
        required_area="hall_a",
        unlock_wave=2,
        pellet_count=6,
        pellet_spread_degrees=16.0,
        projectile_radius=3,
    ),
    "auto_rifle": WeaponSpec(
        key="auto_rifle",
        display_name="Auto Rifle",
        price_points=620,
        damage=12,
        fire_mode="auto",
        cooldown=0.125,
        magazine_size=26,
        reserve_ammo=156,
        reload_time=2.10,
        projectile_speed=620.0,
        required_area="gym",
        unlock_wave=5,
    ),
    "burst_rifle": WeaponSpec(
        key="burst_rifle",
        display_name="Burst Rifle",
        price_points=520,
        damage=18,
        fire_mode="burst",
        cooldown=0.32,
        magazine_size=24,
        reserve_ammo=144,
        reload_time=2.10,
        projectile_speed=640.0,
        required_area="lab",
        unlock_wave=4,
        burst_count=3,
        burst_interval=0.06,
    ),
    "sniper": WeaponSpec(
        key="sniper",
        display_name="Sniper Rifle",
        price_points=1180,
        damage=125,
        fire_mode="single",
        cooldown=0.88,
        magazine_size=6,
        reserve_ammo=36,
        reload_time=2.25,
        projectile_speed=920.0,
        required_area="roof",
        unlock_wave=7,
    ),
}


class WeaponInventory:
    """Fallback-pistol inventory with 2..3 unlocked main weapon slots."""

    def __init__(self, catalog: dict[str, WeaponSpec] | None = None):
        """Initialize WeaponInventory runtime state."""
        self.catalog = catalog or WEAPON_CATALOG
        self.slots: list[WeaponState | None] = [None, None, None, None]
        self.main_slot_capacity = 2
        self._owned_states: dict[str, WeaponState] = {}
        self.active_slot = 0
        self.reload_time_multiplier = 1.0
        self.reset_for_new_run()

    def reset_for_new_run(self) -> None:
        """Start run with fallback pistol and two unlocked main slots."""
        pistol_state = self._new_weapon_state("pistol")
        self._owned_states = {"pistol": pistol_state}
        self.main_slot_capacity = 2
        self.slots = [pistol_state, None, None, None]
        self.active_slot = 0
        self.reload_time_multiplier = 1.0

    def unlocked_main_slot_indices(self) -> list[int]:
        """Return currently unlocked main-slot indices (pistol not included)."""
        return list(range(1, 1 + max(0, int(getattr(self, "main_slot_capacity", 2)))))

    def unlock_extra_slot(self) -> bool:
        """Unlock third main weapon slot for current run."""
        if int(getattr(self, "main_slot_capacity", 2)) >= 3:
            return False
        self.main_slot_capacity = 3
        return True

    def has_extra_slot(self) -> bool:
        """Return whether third main slot is unlocked."""
        return int(getattr(self, "main_slot_capacity", 2)) >= 3

    @property
    def active_state(self) -> WeaponState | None:
        """Return currently active weapon state or None."""
        state = self.slots[self.active_slot]
        if state is not None:
            return state

        for index, candidate in enumerate(self.slots):
            if candidate is not None:
                self.active_slot = index
                return candidate
        return None

    @property
    def active_spec(self) -> WeaponSpec | None:
        """Return currently active weapon specification or None."""
        state = self.active_state
        if state is None:
            return None
        return self.catalog[state.spec_key]

    def _new_weapon_state(self, spec_key: str) -> WeaponState:
        """Create fresh runtime state for one weapon key."""
        spec = self.catalog[spec_key]
        return WeaponState(
            spec_key=spec.key,
            ammo_in_mag=spec.magazine_size,
            reserve_ammo=None if spec.reserve_ammo is None else int(spec.reserve_ammo),
        )

    def weapon_shop_specs(self) -> list[WeaponSpec]:
        """Return purchasable non-pistol weapons sorted by price."""
        return sorted(
            (spec for spec in self.catalog.values() if spec.key != "pistol"),
            key=lambda spec: spec.price_points,
        )

    def unlocked_weapon_specs(self, wave: int) -> list[WeaponSpec]:
        """Return currently unlocked purchasable weapons for provided wave."""
        current_wave = max(1, int(wave))
        return [spec for spec in self.weapon_shop_specs() if spec.unlock_wave <= current_wave]

    def get_owned_weapon_state(self, spec_key: str) -> WeaponState | None:
        """Return one owned weapon state by key."""
        return self._owned_states.get(spec_key)

    def owned_finite_weapon_states(self) -> list[WeaponState]:
        """Return owned finite-ammo weapon states sorted by shop price."""
        states: list[WeaponState] = []
        for spec in self.weapon_shop_specs():
            state = self._owned_states.get(spec.key)
            if state is None:
                continue
            if spec.reserve_ammo is None:
                continue
            states.append(state)
        return states

    def buy_weapon(self, spec_key: str) -> WeaponState:
        """Equip purchased weapon into unlocked main slots while keeping pistol as fallback."""
        if spec_key not in self.catalog:
            raise KeyError(f"Unknown weapon key '{spec_key}'.")

        if spec_key == "pistol":
            self.active_slot = 0
            pistol_state = self._owned_states.get("pistol")
            if pistol_state is None:
                pistol_state = self._new_weapon_state("pistol")
                self._owned_states["pistol"] = pistol_state
            self.slots[0] = pistol_state
            return pistol_state

        state = self._owned_states.get(spec_key)
        if state is None:
            state = self._new_weapon_state(spec_key)
            self._owned_states[spec_key] = state

        unlocked_indices = self.unlocked_main_slot_indices()
        # Re-select owned weapon without disturbing slot layout when already equipped.
        for index in unlocked_indices:
            if self.slots[index] is state:
                self.active_slot = index
                return state

        target = -1
        for index in unlocked_indices:
            if self.slots[index] is None:
                target = index
                break

        if target < 0:
            if self.active_slot in unlocked_indices:
                target = int(self.active_slot)
            else:
                target = unlocked_indices[-1]

        if 0 <= int(getattr(self, "active_slot", 0)) < len(self.slots):
            self._cancel_reload(self.slots[int(self.active_slot)])

        self.slots[target] = state
        self.active_slot = target
        return state

    def ammo_refill_cost(self, spec_key: str) -> int:
        """Return scrap price for a full finite-ammo refill of given weapon."""
        spec = self.catalog[spec_key]
        if spec.price_points <= 0:
            return 0
        return max(1, int(math.ceil(spec.price_points * 0.55)))

    def is_ammo_full(self, state: WeaponState | None) -> bool:
        """Return True when weapon has full magazine and default reserve."""
        if state is None:
            return True

        spec = self.catalog[state.spec_key]
        if state.ammo_in_mag < spec.magazine_size:
            return False
        if spec.reserve_ammo is None:
            return True
        return (state.reserve_ammo or 0) >= int(spec.reserve_ammo)

    def refill_weapon_ammo(self, state: WeaponState | None) -> bool:
        """Reset finite-ammo weapon to full magazine and reserve."""
        if state is None:
            return False

        spec = self.catalog[state.spec_key]
        if spec.reserve_ammo is None:
            return False

        self._cancel_reload(state)
        state.ammo_in_mag = spec.magazine_size
        state.reserve_ammo = int(spec.reserve_ammo)
        return True

    def apply_ammo_pickup(self, mag_fraction: float = 0.45, reserve_fraction: float = 0.25) -> bool:
        """Refill a portion of finite weapon ammo; return True when any ammo was restored."""
        finite_candidates: list[WeaponState] = []
        for state in self.slots:
            if state is None:
                continue
            spec = self.catalog[state.spec_key]
            if spec.reserve_ammo is None:
                continue
            if not self.is_ammo_full(state):
                finite_candidates.append(state)

        if not finite_candidates:
            return False

        active = self.active_state
        if active in finite_candidates:
            target = active
        else:
            target = finite_candidates[0]

        spec = self.catalog[target.spec_key]
        restored = False

        mag_add = max(1, int(math.ceil(spec.magazine_size * max(0.05, float(mag_fraction)))))
        new_mag = min(spec.magazine_size, target.ammo_in_mag + mag_add)
        if new_mag > target.ammo_in_mag:
            target.ammo_in_mag = new_mag
            restored = True

        if spec.reserve_ammo is not None:
            reserve_base = max(2, int(math.ceil(spec.reserve_ammo * max(0.05, float(reserve_fraction)))))
            new_reserve = min(spec.reserve_ammo, int(target.reserve_ammo or 0) + reserve_base)
            if new_reserve > int(target.reserve_ammo or 0):
                target.reserve_ammo = new_reserve
                restored = True

        return restored

    def switch_to_slot(self, index: int) -> bool:
        """Switch active weapon to a specific slot when occupied."""
        safe_index = int(index)
        if safe_index < 0 or safe_index >= len(self.slots):
            return False

        unlocked = set(self.unlocked_main_slot_indices())
        if safe_index != 0 and safe_index not in unlocked:
            return False

        if self.slots[safe_index] is None:
            return False

        if safe_index != int(getattr(self, "active_slot", 0)):
            self._cancel_reload(self.slots[int(getattr(self, "active_slot", 0))])
            self.active_slot = safe_index
        return True

    def cycle_slot(self) -> bool:
        """Cycle through occupied unlocked main slots only."""
        unlocked = self.unlocked_main_slot_indices()
        occupied = [index for index in unlocked if self.slots[index] is not None]
        if not occupied:
            return False

        current = int(getattr(self, "active_slot", 0))
        if current not in occupied:
            self.active_slot = occupied[0]
            return True

        next_index = occupied[(occupied.index(current) + 1) % len(occupied)]
        self.active_slot = next_index
        return True

    def start_reload_active(self) -> bool:
        """Attempt to reload currently active weapon."""
        return self.start_reload(self.active_state)

    def start_reload(self, state: WeaponState | None) -> bool:
        """Start reload for provided weapon state if possible."""
        if state is None:
            return False

        spec = self.catalog[state.spec_key]
        if state.is_reloading:
            return False
        if state.ammo_in_mag >= spec.magazine_size:
            return False
        if state.reserve_ammo is not None and state.reserve_ammo <= 0:
            return False

        state.is_reloading = True
        state.reload_timer = spec.reload_time * max(0.1, float(self.reload_time_multiplier))
        state.pending_burst_shots = 0
        state.burst_interval_timer = 0.0
        return True

    def update_timers(self, dt: float) -> None:
        """Advance cooldown/reload timers for all equipped weapons."""
        # All slots tick in parallel so inactive weapons can finish reloads in background.
        for state in self.slots:
            if state is None:
                continue

            state.cooldown_timer = max(0.0, state.cooldown_timer - dt)
            state.burst_interval_timer = max(0.0, state.burst_interval_timer - dt)

            if not state.is_reloading:
                continue

            state.reload_timer = max(0.0, state.reload_timer - dt)
            if state.reload_timer == 0.0:
                self._finish_reload(state)

    def step_fire(
        self,
        trigger_down: bool,
        trigger_pressed: bool,
        aim_direction: pygame.Vector2,
        cooldown_multiplier: float = 1.0,
        ammo_preserve_chance: float = 0.0,
    ) -> list[ProjectileSpawn]:
        """Process one frame of firing logic and return projectiles to spawn."""
        state = self.active_state
        if state is None:
            return []

        spec = self.catalog[state.spec_key]
        if state.is_reloading:
            return []

        if aim_direction.length_squared() == 0:
            aim_direction = pygame.Vector2(1, 0)
        else:
            aim_direction = aim_direction.normalize()

        # Burst mode reserves follow-up shots once the initial trigger commit succeeds.
        if state.pending_burst_shots > 0:
            return self._continue_burst(
                state,
                spec,
                aim_direction,
                cooldown_multiplier,
                ammo_preserve_chance,
            )

        wants_fire = self._wants_fire(spec.fire_mode, trigger_down, trigger_pressed)
        if not wants_fire or state.cooldown_timer > 0.0:
            return []

        if state.ammo_in_mag <= 0:
            self._start_reload_or_swap(state)
            return []

        shots = self._fire_one_trigger(state, spec, aim_direction, ammo_preserve_chance)
        if spec.fire_mode == "burst":
            remaining = min(spec.burst_count - 1, state.ammo_in_mag)
            state.pending_burst_shots = max(0, remaining)
            if state.pending_burst_shots > 0:
                state.burst_interval_timer = spec.burst_interval * cooldown_multiplier
            else:
                state.cooldown_timer = spec.cooldown * cooldown_multiplier
        else:
            state.cooldown_timer = spec.cooldown * cooldown_multiplier

        if state.ammo_in_mag == 0:
            self._start_reload_or_swap(state)

        return shots

    def _continue_burst(
        self,
        state: WeaponState,
        spec: WeaponSpec,
        aim_direction: pygame.Vector2,
        cooldown_multiplier: float,
        ammo_preserve_chance: float,
    ) -> list[ProjectileSpawn]:
        """Continue burst fire sequence when cadence timer allows."""
        if state.cooldown_timer > 0.0 or state.burst_interval_timer > 0.0:
            return []

        if state.ammo_in_mag <= 0:
            state.pending_burst_shots = 0
            self._start_reload_or_swap(state)
            return []

        shots = self._fire_one_trigger(state, spec, aim_direction, ammo_preserve_chance)
        state.pending_burst_shots -= 1

        if state.pending_burst_shots > 0:
            state.burst_interval_timer = spec.burst_interval * cooldown_multiplier
        else:
            state.cooldown_timer = spec.cooldown * cooldown_multiplier
        if state.ammo_in_mag == 0:
            self._start_reload_or_swap(state)
        return shots

    def _start_reload_or_swap(self, state: WeaponState) -> None:
        """Start reload now or queue auto-weapon swap when empty."""
        if self.start_reload(state):
            return
        self._auto_switch_to_pistol_if_dry(state)

    def _auto_switch_to_pistol_if_dry(self, state: WeaponState) -> None:
        """Switch to pistol when active weapon has no ammo."""
        if state.spec_key == "pistol":
            return
        if state.ammo_in_mag > 0:
            return
        if state.reserve_ammo is None or state.reserve_ammo > 0:
            return

        pistol_state = self.slots[0]
        if pistol_state is not None and pistol_state.spec_key == "pistol":
            self.active_slot = 0

    @staticmethod
    def _wants_fire(fire_mode: FireMode, trigger_down: bool, trigger_pressed: bool) -> bool:
        """Return whether current trigger input should fire a shot."""
        if fire_mode == "burst":
            return trigger_pressed
        if fire_mode == "auto":
            return trigger_down
        return trigger_down

    def _fire_one_trigger(
        self,
        state: WeaponState,
        spec: WeaponSpec,
        aim_direction: pygame.Vector2,
        ammo_preserve_chance: float,
    ) -> list[ProjectileSpawn]:
        """Consume ammo and emit one trigger pull projectile batch."""
        preserve_roll = random.random() < max(0.0, min(1.0, float(ammo_preserve_chance)))
        if not preserve_roll:
            state.ammo_in_mag = max(0, state.ammo_in_mag - 1)
        return self._build_projectile_spawns(spec, aim_direction)

    @staticmethod
    def _build_projectile_spawns(spec: WeaponSpec, aim_direction: pygame.Vector2) -> list[ProjectileSpawn]:
        """Build projectile spawn payload for one weapon shot."""
        shots: list[ProjectileSpawn] = []
        if spec.pellet_count <= 1:
            return [
                ProjectileSpawn(
                    direction=pygame.Vector2(aim_direction),
                    speed=spec.projectile_speed,
                    radius=spec.projectile_radius,
                    damage=spec.damage,
                )
            ]

        # Evenly distribute pellet angles across configured spread cone.
        spread = float(spec.pellet_spread_degrees)
        for pellet_index in range(spec.pellet_count):
            fraction = 0.0 if spec.pellet_count == 1 else pellet_index / (spec.pellet_count - 1)
            angle = -spread / 2.0 + spread * fraction
            direction = pygame.Vector2(aim_direction).rotate(angle)
            shots.append(
                ProjectileSpawn(
                    direction=direction,
                    speed=spec.projectile_speed,
                    radius=spec.projectile_radius,
                    damage=spec.damage,
                )
            )
        return shots

    def _finish_reload(self, state: WeaponState) -> None:
        """Finalize reload by moving reserve ammo into magazine."""
        spec = self.catalog[state.spec_key]
        needed = max(0, spec.magazine_size - state.ammo_in_mag)
        if needed <= 0:
            state.is_reloading = False
            return

        if state.reserve_ammo is None:
            state.ammo_in_mag = spec.magazine_size
            state.is_reloading = False
            return

        loaded = min(needed, state.reserve_ammo)
        state.ammo_in_mag += loaded
        state.reserve_ammo -= loaded
        state.is_reloading = False

    @staticmethod
    def _cancel_reload(state: WeaponState | None) -> None:
        """Cancel active reload timer without changing ammo counts."""
        if state is None:
            return
        state.is_reloading = False
        state.reload_timer = 0.0
        state.pending_burst_shots = 0
        state.burst_interval_timer = 0.0

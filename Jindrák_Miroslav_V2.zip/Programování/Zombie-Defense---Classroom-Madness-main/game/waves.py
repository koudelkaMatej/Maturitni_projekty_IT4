﻿"""Wave spawning and pacing logic."""

from __future__ import annotations

import random
from dataclasses import dataclass, field
from enum import Enum, auto

try:
    from .enemy import BossArchetype, ZombieType
except ImportError:  # pragma: no cover - fallback for running as script module path
    from enemy import BossArchetype, ZombieType


class WavePhase(Enum):
    """Current wave phase."""

    INTERMISSION = auto()
    ACTIVE = auto()


@dataclass
class WaveEvents:
    """Signals emitted by one wave manager update tick."""

    spawn_types: list[ZombieType] = field(default_factory=list)
    wave_started: bool = False
    wave_cleared: bool = False
    wave_kind: str = "standard"
    objective_type: str | None = None
    mutator_key: str | None = None
    boss_archetype: str | None = None


class WaveManager:
    """Track wave transitions and spawn requests."""

    OBJECTIVE_ROTATION = (
        "survive_timer",
        "kill_quota",
        "no_hit_window",
        "elite_hunt",
        "ammo_discipline",
    )
    MUTATOR_ROTATION = (
        "swarm_protocol",
        "fortified_horde",
        "hunter_pack",
        "nightmare_fog",
        "scarcity_protocol",
    )
    BOSS_ARCHETYPES = tuple(archetype.value for archetype in BossArchetype)

    def __init__(self, intermission_duration: float = 7.5):
        """Initialize WaveManager runtime state."""
        self.boss_wave_interval = 4
        self.intermission_duration = intermission_duration
        self.current_wave = 0
        self.phase = WavePhase.INTERMISSION
        self.intermission_remaining = intermission_duration
        self.to_spawn = 0
        self.boss_spawn_pending = 0
        self.spawn_cooldown = 0.0
        self.alive_target = 0
        self.active_wave_kind = "standard"
        self.active_objective_type: str | None = None
        self.active_mutator_key: str | None = None
        self.active_spawn_interval_mult = 1.0
        self.objective_completed = False
        self.last_boss_archetype: str | None = None
        self.boss_archetype_counts: dict[str, int] = {token: 0 for token in self.BOSS_ARCHETYPES}
        self.active_boss_archetype: str | None = None

    def start_first_wave(self) -> None:
        """Initialize the first wave countdown."""
        self.current_wave = 1
        self.phase = WavePhase.INTERMISSION
        self.intermission_remaining = self.intermission_duration
        self.to_spawn = 0
        self.boss_spawn_pending = 0
        self.spawn_cooldown = 0.0
        self.alive_target = 0
        self.active_wave_kind = "standard"
        self.active_objective_type = None
        self.active_mutator_key = None
        self.active_spawn_interval_mult = 1.0
        self.objective_completed = False
        self.last_boss_archetype = None
        self.boss_archetype_counts = {token: 0 for token in self.BOSS_ARCHETYPES}
        self.active_boss_archetype = None

    def notify_zombie_killed(self) -> None:
        """Count down alive zombies so wave clear can trigger."""
        self.alive_target = max(0, self.alive_target - 1)

    def update(self, dt: float, alive_count: int) -> WaveEvents:
        """Advance wave state and return spawn requests/events."""
        events = WaveEvents()

        if self.current_wave <= 0:
            self.start_first_wave()

        if self.phase == WavePhase.INTERMISSION:
            # Intermission owns all wave setup so active phase can focus on spawning.
            self.intermission_remaining = max(0.0, self.intermission_remaining - dt)
            if self.intermission_remaining == 0.0:
                self.phase = WavePhase.ACTIVE
                self.active_wave_kind = self._wave_kind_for_wave(self.current_wave)
                self.active_objective_type = self._objective_for_wave(self.current_wave)
                self.active_mutator_key = self._mutator_for_wave(self.current_wave, self.active_wave_kind)
                self.objective_completed = False

                spawn_budget = self._spawn_budget_for_wave(self.current_wave)
                budget_mult, interval_mult = self._spawn_modifiers_for_current_wave()
                spawn_budget = max(1, int(round(spawn_budget * budget_mult)))
                self.active_spawn_interval_mult = max(0.55, float(interval_mult))
                if self.is_boss_wave():
                    self.to_spawn = max(3, int(spawn_budget * 0.55))
                    self.boss_spawn_pending = 1
                    self.active_boss_archetype = self._pick_boss_archetype()
                    events.boss_archetype = self.active_boss_archetype
                else:
                    self.to_spawn = spawn_budget
                    self.boss_spawn_pending = 0
                    self.active_boss_archetype = None

                self.alive_target = self.to_spawn + self.boss_spawn_pending
                self.spawn_cooldown = 0.0
                events.wave_started = True
                events.wave_kind = self.active_wave_kind
                events.objective_type = self.active_objective_type
                events.mutator_key = self.active_mutator_key
            else:
                events.wave_kind = self.active_wave_kind
                events.objective_type = self.active_objective_type
                events.mutator_key = self.active_mutator_key
            return events

        self.spawn_cooldown = max(0.0, self.spawn_cooldown - dt)
        # Limit each tick burst to keep spawn pacing readable and fair.
        while self.spawn_cooldown == 0.0 and len(events.spawn_types) < 3:
            if self.boss_spawn_pending > 0:
                events.spawn_types.append(ZombieType.BOSS)
                self.boss_spawn_pending -= 1
                self.spawn_cooldown = max(0.55, self._spawn_interval_for_wave(self.current_wave) * self.active_spawn_interval_mult)
                continue

            if self.to_spawn <= 0:
                break

            events.spawn_types.append(self._pick_spawn_type())
            self.to_spawn -= 1
            self.spawn_cooldown = self._spawn_interval_for_wave(self.current_wave) * self.active_spawn_interval_mult

        if self.active_wave_kind == "objective":
            if self.objective_completed:
                events.wave_cleared = True
                self._advance_wave()
        elif self.to_spawn == 0 and self.boss_spawn_pending == 0 and alive_count == 0:
            events.wave_cleared = True
            self._advance_wave()

        events.wave_kind = self.active_wave_kind
        events.objective_type = self.active_objective_type
        events.mutator_key = self.active_mutator_key

        return events

    def complete_objective_wave(self) -> None:
        """Mark active objective wave as completed."""
        if self.phase != WavePhase.ACTIVE:
            return
        if self.active_wave_kind != "objective":
            return
        self.objective_completed = True

    def is_intermission(self) -> bool:
        """Return whether game is between waves."""
        return self.phase == WavePhase.INTERMISSION

    def is_boss_wave(self, wave_number: int | None = None) -> bool:
        """Return True when wave should include a boss spawn."""
        wave = self.current_wave if wave_number is None else int(wave_number)
        return wave >= self.boss_wave_interval and wave % self.boss_wave_interval == 0

    @staticmethod
    def is_objective_wave(wave_number: int) -> bool:
        """Return True when wave is an objective-wave slot."""
        wave = max(1, int(wave_number))
        return wave >= 6 and (wave - 6) % 4 == 0

    @staticmethod
    def _spawn_budget_for_wave(wave: int) -> int:
        """Return spawn budget target for the given wave number."""
        return 12 + wave * 3 + wave // 2

    @staticmethod
    def _spawn_interval_for_wave(wave: int) -> float:
        """Return enemy spawn interval for the given wave number."""
        return max(0.18, 0.72 - wave * 0.038)

    def _wave_kind_for_wave(self, wave_number: int) -> str:
        """Return standard/objective wave kind for wave number."""
        return "objective" if self.is_objective_wave(int(wave_number)) else "standard"

    def _objective_for_wave(self, wave_number: int) -> str | None:
        """Return deterministic objective type for objective wave numbers."""
        wave = int(wave_number)
        if not self.is_objective_wave(wave):
            return None
        index = ((wave - 6) // 4) % len(self.OBJECTIVE_ROTATION)
        return self.OBJECTIVE_ROTATION[index]

    def _mutator_for_wave(self, wave_number: int, wave_kind: str) -> str | None:
        """Return deterministic mutator key for non-objective waves."""
        wave = int(wave_number)
        if wave < 6 or wave_kind != "standard":
            return None
        standard_slot = 0
        for candidate in range(6, wave + 1):
            if not self.is_objective_wave(candidate):
                standard_slot += 1
        index = (standard_slot - 1) % len(self.MUTATOR_ROTATION)
        return self.MUTATOR_ROTATION[index]

    def _spawn_modifiers_for_current_wave(self) -> tuple[float, float]:
        """Return (budget_mult, interval_mult) from active objective/mutator."""
        budget_mult = 1.0
        interval_mult = 1.0

        mutator = str(self.active_mutator_key or "")
        if mutator == "swarm_protocol":
            budget_mult *= 1.30
            interval_mult *= 0.76
        elif mutator == "fortified_horde":
            budget_mult *= 0.95
            interval_mult *= 1.08
        elif mutator == "hunter_pack":
            budget_mult *= 1.12
            interval_mult *= 0.90
        elif mutator == "nightmare_fog":
            budget_mult *= 1.00
            interval_mult *= 0.95
        elif mutator == "scarcity_protocol":
            budget_mult *= 1.08
            interval_mult *= 0.88

        objective = str(self.active_objective_type or "")
        if objective == "survive_timer":
            budget_mult *= 1.45
            interval_mult *= 0.72
        elif objective == "kill_quota":
            budget_mult *= 1.24
            interval_mult *= 0.84
        elif objective == "no_hit_window":
            budget_mult *= 0.92
            interval_mult *= 1.04
        elif objective == "elite_hunt":
            budget_mult *= 0.90
            interval_mult *= 1.10
        elif objective == "ammo_discipline":
            budget_mult *= 1.02
            interval_mult *= 0.98

        return budget_mult, interval_mult

    def _advance_wave(self) -> None:
        """Transition from active wave to next intermission."""
        self.current_wave += 1
        self.phase = WavePhase.INTERMISSION
        self.intermission_remaining = self.intermission_duration
        self.spawn_cooldown = 0.0
        self.boss_spawn_pending = 0
        self.alive_target = 0
        self.objective_completed = False
        self.active_wave_kind = "standard"
        self.active_objective_type = None
        self.active_mutator_key = None
        self.active_spawn_interval_mult = 1.0
        self.active_boss_archetype = None

    def _boss_archetype_weight_table(self) -> dict[str, float]:
        """Return weighted table for next boss archetype pick."""
        # Penalize immediate repeats while favoring archetypes not yet seen this run.
        weights: dict[str, float] = {token: 1.0 for token in self.BOSS_ARCHETYPES}
        last = str(getattr(self, "last_boss_archetype", "") or "")
        seen_counts = dict(getattr(self, "boss_archetype_counts", {}))
        for token in self.BOSS_ARCHETYPES:
            weight = 1.0
            if token == last:
                weight *= 0.20
            if int(seen_counts.get(token, 0)) <= 0:
                weight *= 1.80
            weights[token] = weight
        return weights

    def _unseen_boss_archetypes(self) -> list[str]:
        """Return archetypes not yet spawned in this run."""
        counts = dict(getattr(self, "boss_archetype_counts", {}))
        return [token for token in self.BOSS_ARCHETYPES if int(counts.get(token, 0)) <= 0]

    def _pick_boss_archetype(self) -> str:
        """Pick and persist boss archetype using no-repeat-first policy."""
        weights = self._boss_archetype_weight_table()
        unseen = self._unseen_boss_archetypes()
        population = unseen if unseen else list(self.BOSS_ARCHETYPES)
        picked = random.choices(population, weights=[weights[token] for token in population], k=1)[0]
        self.last_boss_archetype = picked
        counts = dict(getattr(self, "boss_archetype_counts", {}))
        counts[picked] = int(counts.get(picked, 0)) + 1
        self.boss_archetype_counts = counts
        return picked

    def preview_next_boss_archetype(self, wave_number: int | None = None) -> str | None:
        """Return deterministic best-guess archetype for upcoming boss wave intel."""
        wave = self.current_wave if wave_number is None else int(wave_number)
        if not self.is_boss_wave(wave):
            return None

        weights = self._boss_archetype_weight_table()
        unseen = self._unseen_boss_archetypes()
        pool = unseen if unseen else list(self.BOSS_ARCHETYPES)
        best_weight = max(weights[token] for token in pool)
        candidates = [token for token in pool if weights[token] == best_weight]
        if len(candidates) == 1:
            return candidates[0]

        counts = dict(getattr(self, "boss_archetype_counts", {}))
        min_count = min(int(counts.get(token, 0)) for token in candidates)
        least_seen = [token for token in candidates if int(counts.get(token, 0)) == min_count]
        return sorted(least_seen)[0]

    def _pick_spawn_type(self) -> ZombieType:
        """Pick enemy archetype based on current wave progression."""
        if self.current_wave <= 1:
            return random.choices(
                [ZombieType.WALKER, ZombieType.RUNNER],
                weights=[0.78, 0.22],
                k=1,
            )[0]
        if self.current_wave == 2:
            return random.choices(
                [ZombieType.WALKER, ZombieType.RUNNER],
                weights=[0.62, 0.38],
                k=1,
            )[0]
        if self.current_wave <= 4:
            return random.choices(
                [ZombieType.WALKER, ZombieType.RUNNER, ZombieType.TANK],
                weights=[0.48, 0.42, 0.10],
                k=1,
            )[0]

        delta = self.current_wave - 4
        walker_weight = max(0.18, 0.46 - delta * 0.014)
        tank_weight = min(0.24, 0.09 + delta * 0.008)
        runner_weight = 1.0 - tank_weight - walker_weight
        return random.choices(
            [ZombieType.WALKER, ZombieType.RUNNER, ZombieType.TANK],
            weights=[walker_weight, runner_weight, tank_weight],
            k=1,
        )[0]

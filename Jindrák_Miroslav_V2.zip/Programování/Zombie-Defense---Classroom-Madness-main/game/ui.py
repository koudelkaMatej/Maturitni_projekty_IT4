﻿"""UI rendering helpers for menus, HUD and overlays."""

from __future__ import annotations

from pathlib import Path

import pygame

THEME_PANEL = (29, 33, 41)
THEME_PANEL_BORDER = (112, 122, 138)
THEME_ACCENT = (234, 194, 116)
THEME_TEXT = (230, 236, 242)
THEME_DANGER = (200, 64, 64)
THEME_DANGER_BG = (66, 22, 22)
THEME_MUTED = (170, 182, 196)
THEME_WEAPON_PANEL = (20, 24, 32, 196)

WEAPON_ICON_SIZE = (96, 48)
WEAPON_ICON_RENDER_SIZE = (72, 36)
# In-memory icon cache avoids repeated disk loads during gameplay.
_WEAPON_ICON_CACHE: dict[str, pygame.Surface] = {}
_WEAPON_ICON_PLACEHOLDER: pygame.Surface | None = None


def _draw_panel(screen: pygame.Surface, rect: pygame.Rect, *, alpha: int = 190) -> None:
    """Draw a rounded panel with fill and border colors."""
    surface = pygame.Surface(rect.size, pygame.SRCALPHA)
    surface.fill((*THEME_PANEL, alpha))
    pygame.draw.rect(surface, (*THEME_PANEL_BORDER, min(255, alpha + 40)), surface.get_rect(), 2, border_radius=10)
    screen.blit(surface, rect.topleft)


def _draw_text_shadow(
    screen: pygame.Surface,
    font: pygame.font.Font,
    text: str,
    pos: tuple[int, int],
    color: tuple[int, int, int],
) -> None:
    """Draw text with a simple shadow for readability."""
    shadow = font.render(text, True, (0, 0, 0))
    screen.blit(shadow, (pos[0] + 1, pos[1] + 1))
    label = font.render(text, True, color)
    screen.blit(label, pos)


def _ellipsize_text(font: pygame.font.Font, text: str, max_width: int) -> str:
    """Clamp one text line to max width using a safe ellipsis fallback."""
    clean = str(text or "")
    if max_width <= 0:
        return ""
    if font.size(clean)[0] <= max_width:
        return clean

    ellipsis = "..."
    clipped = clean
    while clipped and font.size(f"{clipped}{ellipsis}")[0] > max_width:
        clipped = clipped[:-1]
    return f"{clipped}{ellipsis}" if clipped else ellipsis


def _wrap_text(font: pygame.font.Font, text: str, max_width: int, max_lines: int) -> list[str]:
    """Wrap text by words within max width and line count."""
    if max_width <= 0 or max_lines <= 0:
        return []

    words = str(text or "").split()
    if not words:
        return []

    lines: list[str] = []
    current = ""
    # Greedy line builder keeps rendering stable for dynamic menu text.
    for word in words:
        proposal = word if not current else f"{current} {word}"
        if font.size(proposal)[0] <= max_width:
            current = proposal
            continue

        if current:
            lines.append(current)
            if len(lines) >= max_lines:
                lines[-1] = _ellipsize_text(font, lines[-1], max_width)
                return lines
            current = word
            if font.size(current)[0] > max_width:
                current = _ellipsize_text(font, current, max_width)
        else:
            lines.append(_ellipsize_text(font, word, max_width))
            if len(lines) >= max_lines:
                return lines
            current = ""

    if current and len(lines) < max_lines:
        lines.append(_ellipsize_text(font, current, max_width))
    elif current and lines:
        lines[-1] = _ellipsize_text(font, f"{lines[-1]} {current}", max_width)

    return lines[:max_lines]


def _wrap_text_strict(font: pygame.font.Font, text: str, max_width: int) -> list[str]:
    """Wrap text by words to fit width without forced truncation."""
    if max_width <= 0:
        return []

    words = str(text or "").split()
    if not words:
        return []

    lines: list[str] = []
    current = ""
    for word in words:
        proposal = word if not current else f"{current} {word}"
        if font.size(proposal)[0] <= max_width:
            current = proposal
            continue

        if current:
            lines.append(current)
            current = word
        else:
            # Unbreakable token; keep safe with ellipsis so rendering never escapes.
            lines.append(_ellipsize_text(font, word, max_width))
            current = ""

    if current:
        lines.append(current)
    return lines


def _weapon_icon_placeholder() -> pygame.Surface:
    """Draw fallback icon panel for weapons without sprite assets."""
    global _WEAPON_ICON_PLACEHOLDER
    if _WEAPON_ICON_PLACEHOLDER is not None:
        return _WEAPON_ICON_PLACEHOLDER

    surf = pygame.Surface(WEAPON_ICON_SIZE, pygame.SRCALPHA)
    surf.fill((0, 0, 0, 0))
    pygame.draw.rect(surf, (92, 104, 124), (8, 18, 80, 14), border_radius=6)
    pygame.draw.rect(surf, (178, 186, 198), (12, 22, 52, 6), border_radius=3)
    pygame.draw.rect(surf, (198, 156, 92), (55, 26, 18, 16), border_radius=4)
    _WEAPON_ICON_PLACEHOLDER = surf
    return surf


def get_weapon_icon(weapon_key: str) -> pygame.Surface:
    """Load one weapon HUD icon and cache it; fallback to placeholder when missing."""
    key = str(weapon_key or "").strip().lower()
    if key in _WEAPON_ICON_CACHE:
        return _WEAPON_ICON_CACHE[key]

    asset_path = Path(__file__).resolve().parent / "assets" / "weapons" / f"{key}.png"
    icon = _weapon_icon_placeholder()
    # Load from asset only once, then serve from cache.
    if asset_path.exists():
        try:
            loaded = pygame.image.load(str(asset_path)).convert_alpha()
            icon = pygame.transform.smoothscale(loaded, WEAPON_ICON_SIZE)
        except pygame.error:
            icon = _weapon_icon_placeholder()

    _WEAPON_ICON_CACHE[key] = icon
    return icon


def get_armory_button_rect(screen_width: int) -> pygame.Rect:
    """Return HUD rectangle of intermission armory toggle button."""
    mutation_rect = get_mutation_button_rect(screen_width)
    return pygame.Rect(mutation_rect.left, mutation_rect.bottom + 8, mutation_rect.width, 32)


def get_mutation_button_rect(screen_width: int) -> pygame.Rect:
    """Return HUD rectangle of mutation drawer toggle button."""
    return pygame.Rect(screen_width - 248, 88, 228, 34)


def get_armory_panel_rect(width: int, height: int) -> pygame.Rect:
    """Return core armory panel rectangle anchored to viewport center."""
    panel_width = min(700, max(580, width - 220))
    panel_height = min(560, max(480, height - 140))
    return pygame.Rect(width // 2 - panel_width // 2, height // 2 - panel_height // 2, panel_width, panel_height)


def get_howto_panel_rect(width: int, height: int) -> pygame.Rect:
    """Return standalone guide panel rect with minimum viewport support."""
    panel_width = min(920, max(600, width - 40))
    panel_height = min(620, max(380, height - 30))
    return pygame.Rect(width // 2 - panel_width // 2, height // 2 - panel_height // 2, panel_width, panel_height)


def get_howto_category_rects(width: int, height: int, category_count: int) -> list[pygame.Rect]:
    """Return clickable category row rectangles in guide sidebar."""
    panel = get_howto_panel_rect(width, height)
    sidebar_width = max(166, min(236, panel.width // 3))
    sidebar_left = panel.left + 20
    row_height = 34
    row_gap = 8
    start_y = panel.top + 98
    return [
        pygame.Rect(sidebar_left, start_y + idx * (row_height + row_gap), sidebar_width, row_height)
        for idx in range(max(0, int(category_count)))
    ]


def get_pause_main_option_rects(width: int, height: int) -> list[pygame.Rect]:
    """Return clickable option rectangles for pause main menu."""
    panel = pygame.Rect(width // 2 - 230, height // 2 - 190, 460, 380)
    return [
        pygame.Rect(panel.left + 56, panel.top + 112 + idx * 50, panel.width - 112, 40)
        for idx in range(4)
    ]


def get_pause_settings_option_rects(width: int, height: int) -> list[pygame.Rect]:
    """Return clickable option rectangles for pause settings menu."""
    panel = pygame.Rect(width // 2 - 230, height // 2 - 190, 460, 380)
    return [
        pygame.Rect(panel.left + 56, panel.top + 154 + idx * 56, panel.width - 112, 42)
        for idx in range(2)
    ]


def get_armory_tab_rects(width: int) -> dict[str, pygame.Rect]:
    """Return clickable rectangles for armory tabs."""
    panel_rect = get_armory_panel_rect(width, 700)
    base_y = panel_rect.top + 136
    tab_width = 164
    tab_height = 36
    gap = 12
    start_x = panel_rect.centerx - tab_width - gap // 2
    return {
        "weapons": pygame.Rect(start_x, base_y, tab_width, tab_height),
        "upgrades": pygame.Rect(start_x + tab_width + gap, base_y, tab_width, tab_height),
    }


def get_armory_row_rect(width: int, row_index: int) -> pygame.Rect:
    """Return armory row rectangle by index for rendering and mouse hit-testing."""
    panel_rect = get_armory_panel_rect(width, 700)
    row_top = panel_rect.top + 190
    row_height = 36
    row_width = panel_rect.width - 72
    row_left = panel_rect.left + 36
    return pygame.Rect(row_left, row_top + row_index * row_height, row_width, 32)


def get_perk_card_rects(width: int, height: int, choice_count: int) -> list[pygame.Rect]:
    """Return mutation card rectangles for drawing and mouse hit-testing."""
    if choice_count <= 0:
        return []

    if choice_count >= 4:
        card_width = 172
        card_height = 192
        spacing = 12
    else:
        card_width = 220
        card_height = 200
        spacing = 16
    total_width = choice_count * card_width + (choice_count - 1) * spacing
    start_x = width // 2 - total_width // 2
    y = (height // 2 - 190) + 120
    return [
        pygame.Rect(start_x + idx * (card_width + spacing), y, card_width, card_height)
        for idx in range(choice_count)
    ]


def compute_menu_layout(
    width: int,
    height: int,
    option_count: int,
    leaderboard_count: int,
    *,
    has_message: bool,
    title_height: int,
    option_height: int,
    body_height: int,
    leaderboard_row_height: int,
) -> dict[str, object]:
    """Compute non-overlapping menu block rectangles."""
    top_margin = max(24, height // 16)

    title_center_y = top_margin + title_height // 2
    name_center_y = title_center_y + title_height // 2 + 24 + body_height // 2
    coins_center_y = name_center_y + body_height + 6

    option_spacing = option_height + 10
    options_top = coins_center_y + body_height // 2 + 40
    option_rects: list[pygame.Rect] = []
    for index in range(option_count):
        option_rects.append(
            pygame.Rect(
                width // 2 - 170,
                options_top + index * option_spacing,
                340,
                option_height,
            )
        )

    cursor_y = option_rects[-1].bottom + 14 if option_rects else options_top

    message_rect: pygame.Rect | None = None
    if has_message:
        message_rect = pygame.Rect(width // 2 - 350, cursor_y, 700, body_height)
        cursor_y = message_rect.bottom + 10

    hint_rect = pygame.Rect(width // 2 - 360, cursor_y, 720, body_height)
    cursor_y = hint_rect.bottom + 16

    leaderboard_title_rect = pygame.Rect(width // 2 - 270, cursor_y, 540, body_height)
    rows_start_y = leaderboard_title_rect.bottom + 8

    row_step = max(leaderboard_row_height, 16) + 4
    usable_bottom = height - 14
    max_rows = max(0, (usable_bottom - rows_start_y) // row_step)
    rows_to_draw = max(0, min(leaderboard_count, max_rows))
    leaderboard_row_rects = [
        pygame.Rect(width // 2 - 270, rows_start_y + idx * row_step, 540, leaderboard_row_height)
        for idx in range(rows_to_draw)
    ]

    return {
        "title_center_y": title_center_y,
        "name_center_y": name_center_y,
        "coins_center_y": coins_center_y,
        "option_rects": option_rects,
        "message_rect": message_rect,
        "hint_rect": hint_rect,
        "leaderboard_title_rect": leaderboard_title_rect,
        "leaderboard_row_rects": leaderboard_row_rects,
    }


def get_menu_option_rects(width: int, height: int, *, has_message: bool = False, leaderboard_count: int = 0) -> list[pygame.Rect]:
    """Return menu option rectangles using the exact same layout as draw_menu."""
    title_font = pygame.font.SysFont("arial", 56, bold=True)
    option_font = pygame.font.SysFont("arial", 36)
    body_font = pygame.font.SysFont("consolas", 22)
    leaderboard_font = pygame.font.SysFont("consolas", 18)

    layout = compute_menu_layout(
        width,
        height,
        option_count=5,
        leaderboard_count=max(0, int(leaderboard_count)),
        has_message=bool(has_message),
        title_height=title_font.get_height(),
        option_height=option_font.get_height(),
        body_height=body_font.get_height(),
        leaderboard_row_height=leaderboard_font.get_height(),
    )
    return list(layout["option_rects"])


def get_visual_mode_option_rects(width: int, height: int) -> list[pygame.Rect]:
    """Return clickable rectangles for visual-mode selection options."""
    panel = pygame.Rect(width // 2 - 330, height // 2 - 215, 660, 430)
    row_top = panel.top + 140
    row_height = 64
    return [pygame.Rect(panel.left + 72, row_top + idx * row_height, panel.width - 144, 48) for idx in range(3)]


def compute_perk_name_layout(name: str, max_width: int) -> tuple[list[str], str, bool]:
    """Return perk-name lines, chosen font token and truncation flag."""
    large_font = pygame.font.SysFont("consolas", 22)
    small_font = pygame.font.SysFont("consolas", 20)
    clean_name = str(name or "").strip() or "Unknown"

    if large_font.size(clean_name)[0] <= max_width:
        return [clean_name], "large", False

    strict_large = _wrap_text_strict(large_font, clean_name, max_width)
    if 1 < len(strict_large) <= 2:
        return strict_large, "large", False

    if small_font.size(clean_name)[0] <= max_width:
        return [clean_name], "small", False

    strict_small = _wrap_text_strict(small_font, clean_name, max_width)
    if 1 < len(strict_small) <= 2:
        return strict_small, "small", False

    fallback = _wrap_text(small_font, clean_name, max_width, max_lines=2)
    truncated = "..." in " ".join(fallback)
    return fallback, "small", truncated


def get_menu_options(*, authenticated: bool = False) -> list[str]:
    """Main menu option labels."""
    auth_label = "Logout" if authenticated else "Login"
    return ["Play", auth_label, "Skins Shop", "How To Play", "Quit"]


def format_player_label(player_name: str, *, authenticated: bool = False) -> str:
    """Return menu player label with explicit empty-state text."""
    clean_name = player_name.strip()
    if authenticated and clean_name:
        return f"Player: {clean_name} (logged in)"
    return "Player: Guest"


def draw_menu(
    screen: pygame.Surface,
    width: int,
    height: int,
    selected_index: int,
    player_name: str,
    player_coins: int,
    leaderboard_lines: list[str],
    authenticated: bool,
    menu_message: str = "",
) -> None:
    """Render main menu with player summary and top leaderboard lines."""
    title_font = pygame.font.SysFont("arial", 56, bold=True)
    option_font = pygame.font.SysFont("arial", 36)
    body_font = pygame.font.SysFont("consolas", 22)
    leaderboard_font = pygame.font.SysFont("consolas", 18)

    layout = compute_menu_layout(
        width,
        height,
        option_count=5,
        leaderboard_count=len(leaderboard_lines),
        has_message=bool(menu_message),
        title_height=title_font.get_height(),
        option_height=option_font.get_height(),
        body_height=body_font.get_height(),
        leaderboard_row_height=leaderboard_font.get_height(),
    )

    title = title_font.render("Zombie Defense", True, (230, 230, 255))
    screen.blit(title, title.get_rect(center=(width // 2, int(layout["title_center_y"]))))

    name_text = body_font.render(format_player_label(player_name, authenticated=authenticated), True, (200, 220, 240))
    coin_label = f"Coins: {player_coins}" if authenticated else "Coins: login required"
    coins_text = body_font.render(coin_label, True, (255, 230, 110))
    screen.blit(name_text, name_text.get_rect(center=(width // 2, int(layout["name_center_y"]))))
    screen.blit(coins_text, coins_text.get_rect(center=(width // 2, int(layout["coins_center_y"]))))

    option_rects = list(layout["option_rects"])
    options = get_menu_options(authenticated=authenticated)
    for i, text in enumerate(options):
        color = (255, 240, 90) if i == selected_index else (230, 230, 230)
        label = option_font.render(text, True, color)
        option_rect = option_rects[i]
        if i == selected_index:
            pygame.draw.rect(screen, (52, 58, 70), option_rect.inflate(18, 10), border_radius=9)
        screen.blit(label, label.get_rect(center=option_rect.center))

    if menu_message:
        message = body_font.render(_ellipsize_text(body_font, menu_message, 700), True, (255, 208, 140))
        message_rect = layout["message_rect"]
        if isinstance(message_rect, pygame.Rect):
            screen.blit(message, message.get_rect(center=message_rect.center))

    controls_hint = body_font.render("F11 / ALT+ENTER = fullscreen", True, (170, 170, 180))
    hint_rect = layout["hint_rect"]
    if isinstance(hint_rect, pygame.Rect):
        screen.blit(controls_hint, controls_hint.get_rect(center=hint_rect.center))

    title_rect = layout["leaderboard_title_rect"]
    score_title = body_font.render("Top results (name | score | date)", True, (220, 220, 220))
    if isinstance(title_rect, pygame.Rect):
        screen.blit(score_title, score_title.get_rect(midleft=(title_rect.left + 2, title_rect.centery)))

    row_rects = list(layout["leaderboard_row_rects"])
    for index, row_rect in enumerate(row_rects):
        safe_line = _ellipsize_text(leaderboard_font, f"{index + 1}. {leaderboard_lines[index]}", row_rect.width - 8)
        label = leaderboard_font.render(safe_line, True, (190, 210, 220))
        screen.blit(label, (row_rect.left, row_rect.top))


def draw_visual_mode_select(
    screen: pygame.Surface,
    width: int,
    height: int,
    selected_index: int,
    option_labels: list[str],
) -> None:
    """Render pre-run visual mode picker shown after pressing Play."""
    panel_rect = pygame.Rect(width // 2 - 330, height // 2 - 215, 660, 430)
    _draw_panel(screen, panel_rect, alpha=238)

    title_font = pygame.font.SysFont("arial", 48, bold=True)
    body_font = pygame.font.SysFont("consolas", 24)
    hint_font = pygame.font.SysFont("consolas", 18)

    title = title_font.render("Choose Visual Mode", True, (236, 242, 248))
    subtitle = hint_font.render("Pick one mode for this run", True, THEME_MUTED)
    screen.blit(title, title.get_rect(center=(panel_rect.centerx, panel_rect.top + 58)))
    screen.blit(subtitle, subtitle.get_rect(center=(panel_rect.centerx, panel_rect.top + 94)))

    for idx, rect in enumerate(get_visual_mode_option_rects(width, height)):
        selected = idx == selected_index
        fill = (84, 74, 58) if selected else (52, 56, 68)
        border = (234, 194, 116) if selected else (124, 136, 158)
        pygame.draw.rect(screen, fill, rect, border_radius=9)
        pygame.draw.rect(screen, border, rect, 2, border_radius=9)
        label = body_font.render(option_labels[idx], True, (240, 244, 248))
        screen.blit(label, label.get_rect(center=rect.center))

    controls = hint_font.render("UP/DOWN select, ENTER confirm, ESC back, or click option", True, (176, 188, 204))
    screen.blit(controls, controls.get_rect(center=(panel_rect.centerx, panel_rect.bottom - 44)))


def draw_login_input(
    screen: pygame.Surface,
    width: int,
    height: int,
    username: str,
    password: str,
    active_field: str,
    error_message: str = "",
) -> None:
    """Render in-game login form with active field highlight."""
    title_font = pygame.font.SysFont("arial", 44, bold=True)
    body_font = pygame.font.SysFont("consolas", 24)
    small_font = pygame.font.SysFont("consolas", 18)

    panel_rect = pygame.Rect(width // 2 - 290, height // 2 - 170, 580, 340)
    _draw_panel(screen, panel_rect, alpha=230)

    title = title_font.render("Account Login", True, (236, 240, 248))
    subtitle = small_font.render("Login uses your web username + password", True, THEME_MUTED)
    screen.blit(title, title.get_rect(center=(width // 2, panel_rect.top + 54)))
    screen.blit(subtitle, subtitle.get_rect(center=(width // 2, panel_rect.top + 88)))

    username_rect = pygame.Rect(panel_rect.left + 50, panel_rect.top + 124, 480, 46)
    password_rect = pygame.Rect(panel_rect.left + 50, panel_rect.top + 196, 480, 46)

    username_active = active_field == "username"
    password_active = active_field == "password"

    for rect, is_active in ((username_rect, username_active), (password_rect, password_active)):
        fill = (68, 72, 84) if is_active else (52, 56, 68)
        border = THEME_ACCENT if is_active else (124, 136, 158)
        pygame.draw.rect(screen, fill, rect, border_radius=8)
        pygame.draw.rect(screen, border, rect, 2, border_radius=8)

    username_label = body_font.render("Username", True, (214, 224, 238))
    password_label = body_font.render("Password", True, (214, 224, 238))
    screen.blit(username_label, (username_rect.left, username_rect.top - 30))
    screen.blit(password_label, (password_rect.left, password_rect.top - 30))

    username_text = _ellipsize_text(body_font, username or "_", username_rect.width - 20)
    password_display = "*" * len(password) if password else "_"
    password_text = _ellipsize_text(body_font, password_display, password_rect.width - 20)

    screen.blit(body_font.render(username_text, True, (255, 241, 138)), (username_rect.left + 10, username_rect.top + 10))
    screen.blit(body_font.render(password_text, True, (255, 241, 138)), (password_rect.left + 10, password_rect.top + 10))

    if error_message:
        error_text = _ellipsize_text(small_font, error_message, panel_rect.width - 80)
        error = small_font.render(error_text, True, (255, 172, 160))
        screen.blit(error, error.get_rect(center=(width // 2, panel_rect.top + 264)))

    hint = small_font.render("TAB switch field, ENTER login, ESC back", True, (180, 186, 198))
    screen.blit(hint, hint.get_rect(center=(width // 2, panel_rect.top + 300)))


def draw_shop(
    screen: pygame.Surface,
    width: int,
    height: int,
    player_name: str,
    player_coins: int,
    shop_items: list[dict[str, object]],
    selected_index: int,
) -> None:
    """Render skins shop rows, status and controls hint."""
    title_font = pygame.font.SysFont("arial", 48, bold=True)
    body_font = pygame.font.SysFont("consolas", 24)

    title = title_font.render("Skins Shop", True, (245, 245, 250))
    summary = body_font.render(f"Player: {player_name}    Coins: {player_coins}", True, (255, 235, 120))
    hint = body_font.render("UP/DOWN + ENTER to buy/select, ESC to return", True, (180, 180, 180))

    screen.blit(title, title.get_rect(center=(width // 2, 70)))
    screen.blit(summary, summary.get_rect(center=(width // 2, 120)))
    screen.blit(hint, hint.get_rect(center=(width // 2, 160)))

    row_top = 210
    row_height = 52

    for idx, item in enumerate(shop_items):
        owned = bool(item["owned"])
        selected = bool(item["selected"])

        if selected:
            status = "SELECTED"
            status_color = (120, 235, 160)
        elif owned:
            status = "OWNED"
            status_color = (170, 220, 255)
        else:
            status = f"{int(item['price_coins'])} coins"
            status_color = (255, 210, 120)

        line = f"{item['display_name']:<12} | {status}"
        color = (255, 244, 110) if idx == selected_index else (220, 220, 220)
        label = body_font.render(line, True, color)

        y = row_top + idx * row_height
        if idx == selected_index:
            pygame.draw.rect(screen, (55, 58, 70), (width // 2 - 220, y - 8, 460, 40), border_radius=8)
        screen.blit(label, (width // 2 - 200, y))

        preview = pygame.Rect(width // 2 + 210, y + 4, 18, 18)
        pygame.draw.rect(screen, item["primary_color"], preview)

    back_index = len(shop_items)
    back_color = (255, 244, 110) if selected_index == back_index else (210, 210, 210)
    back_label = body_font.render("Back", True, back_color)
    y = row_top + back_index * row_height
    if selected_index == back_index:
        pygame.draw.rect(screen, (55, 58, 70), (width // 2 - 220, y - 8, 460, 40), border_radius=8)
    screen.blit(back_label, (width // 2 - 200, y))


def draw_hud(
    screen: pygame.Surface,
    score: int,
    kills: int,
    survival_time: float,
    health: int,
    max_health: int,
    wave: int,
    intermission_remaining: float,
    coins: int,
    run_scrap: int,
    active_weapon_key: str,
    active_weapon_name: str,
    active_weapon_ammo: str,
    active_weapon_reload: str,
    slot_labels: list[str],
    active_effects: list[str],
    intermission_hint: str = "",
    armory_button_text: str = "",
    armory_button_active: bool = False,
    mutation_button_text: str = "",
    mutation_button_active: bool = False,
    visual_mode_label: str = "",
    wave_rule_label: str = "",
) -> None:
    """Render gameplay HUD including stats, ammo and active effects."""
    font = pygame.font.SysFont("consolas", 20)
    small_font = pygame.font.SysFont("consolas", 18)

    # Top-left text-only cluster
    _draw_text_shadow(screen, font, f"Score: {score}   Kills: {kills}   Wave: {wave}", (16, 12), THEME_TEXT)
    time_line = f"Time: {survival_time:05.1f}s"
    if intermission_remaining > 0:
        time_line = f"{time_line}   Next: {intermission_remaining:0.1f}s"
    _draw_text_shadow(screen, font, time_line, (16, 36), THEME_MUTED)
    if intermission_hint:
        hint_panel = pygame.Rect(screen.get_width() // 2 - 250, 58, 500, 30)
        pygame.draw.rect(screen, (30, 42, 58), hint_panel, border_radius=7)
        pygame.draw.rect(screen, (150, 174, 208), hint_panel, 2, border_radius=7)
        hint_text = _ellipsize_text(small_font, intermission_hint, hint_panel.width - 20)
        hint_surface = small_font.render(hint_text, True, (224, 236, 248))
        screen.blit(hint_surface, hint_surface.get_rect(center=hint_panel.center))
    if wave_rule_label:
        rule_font = pygame.font.SysFont("consolas", 16)
        panel_top = 92 if intermission_hint else 60
        screen_width = screen.get_width()
        mutation_left = get_mutation_button_rect(screen_width).left - 12
        min_left = 206
        max_width = 580
        available_width = max(0, mutation_left - min_left)
        rule_width = min(max_width, available_width)
        if rule_width >= 180:
            preferred_left = screen_width // 2 - rule_width // 2
            left = min(max(min_left, preferred_left), mutation_left - rule_width)
            line_width = rule_width - 18
            rule_lines = _wrap_text(rule_font, wave_rule_label, line_width, max_lines=2)
            if not rule_lines:
                rule_lines = [_ellipsize_text(rule_font, wave_rule_label, line_width)]
            line_height = rule_font.get_height()
            line_gap = 2
            total_text_height = len(rule_lines) * line_height + (len(rule_lines) - 1) * line_gap
            panel_height = max(28, total_text_height + 10)
            rule_panel = pygame.Rect(left, panel_top, rule_width, panel_height)
        else:
            rule_panel = None
            rule_lines = []
        if rule_panel is not None:
            pygame.draw.rect(screen, (24, 32, 46), rule_panel, border_radius=7)
            pygame.draw.rect(screen, (122, 150, 188), rule_panel, 2, border_radius=7)
            line_height = rule_font.get_height()
            line_gap = 2
            total_text_height = len(rule_lines) * line_height + (len(rule_lines) - 1) * line_gap
            first_y = rule_panel.centery - total_text_height // 2
            for idx, line in enumerate(rule_lines):
                rule_surface = rule_font.render(line, True, (220, 232, 246))
                line_center_y = first_y + idx * (line_height + line_gap) + line_height // 2
                line_rect = rule_surface.get_rect(center=(rule_panel.centerx, line_center_y))
                screen.blit(rule_surface, line_rect)

    # Top-right currency cluster
    coins_text = f"Coins: {coins}"
    scrap_text = f"Scrap: {run_scrap}"
    coins_width = font.size(coins_text)[0]
    scrap_width = font.size(scrap_text)[0]
    _draw_text_shadow(screen, font, coins_text, (screen.get_width() - coins_width - 16, 12), (255, 220, 120))
    _draw_text_shadow(screen, font, scrap_text, (screen.get_width() - scrap_width - 16, 36), THEME_ACCENT)
    if visual_mode_label:
        mode_width = small_font.size(visual_mode_label)[0]
        _draw_text_shadow(screen, small_font, visual_mode_label, (screen.get_width() - mode_width - 16, 60), (182, 214, 248))

    if armory_button_text:
        button_rect = get_armory_button_rect(screen.get_width())
        button_fill = (84, 76, 60) if armory_button_active else (54, 60, 73)
        button_border = (233, 194, 116) if armory_button_active else (138, 150, 170)
        pygame.draw.rect(screen, button_fill, button_rect, border_radius=8)
        pygame.draw.rect(screen, button_border, button_rect, 2, border_radius=8)
        button_text = _ellipsize_text(small_font, armory_button_text, button_rect.width - 14)
        button_label = small_font.render(button_text, True, (242, 244, 248))
        screen.blit(button_label, button_label.get_rect(center=button_rect.center))

    if mutation_button_text:
        button_rect = get_mutation_button_rect(screen.get_width())
        mutation_font = pygame.font.SysFont("consolas", 15)
        button_fill = (64, 66, 84) if mutation_button_active else (46, 52, 66)
        button_border = (164, 192, 238) if mutation_button_active else (126, 142, 170)
        pygame.draw.rect(screen, button_fill, button_rect, border_radius=8)
        pygame.draw.rect(screen, button_border, button_rect, 2, border_radius=8)
        button_text = _ellipsize_text(mutation_font, mutation_button_text, button_rect.width - 14)
        button_label = mutation_font.render(button_text, True, (236, 242, 248))
        screen.blit(button_label, button_label.get_rect(center=button_rect.center))

    bar_x, bar_y = 16, 84
    bar_width, bar_height = 180, 14
    ratio = 0 if max_health == 0 else health / max_health
    pygame.draw.rect(screen, THEME_DANGER_BG, (bar_x, bar_y, bar_width, bar_height), border_radius=6)
    pygame.draw.rect(screen, THEME_DANGER, (bar_x, bar_y, int(bar_width * ratio), bar_height), border_radius=6)
    pygame.draw.rect(screen, (216, 226, 236), (bar_x, bar_y, bar_width, bar_height), 2, border_radius=6)

    # Bottom-right compact weapon module with sprite
    module_width = 356
    module_height = 206
    module_rect = pygame.Rect(screen.get_width() - module_width - 16, screen.get_height() - module_height - 14, module_width, module_height)
    panel = pygame.Surface(module_rect.size, pygame.SRCALPHA)
    panel.fill(THEME_WEAPON_PANEL)
    pygame.draw.rect(panel, (126, 138, 158, 210), panel.get_rect(), 1, border_radius=10)
    screen.blit(panel, module_rect.topleft)

    weapon_icon = get_weapon_icon(active_weapon_key)
    weapon_icon = pygame.transform.smoothscale(weapon_icon, WEAPON_ICON_RENDER_SIZE)
    screen.blit(weapon_icon, (module_rect.left + 14, module_rect.top + 14))

    max_text_width = module_rect.width - 112
    weapon_name_text = _ellipsize_text(font, active_weapon_name, max_text_width)
    ammo_text = _ellipsize_text(font, f"Ammo: {active_weapon_ammo}", max_text_width)
    _draw_text_shadow(screen, font, weapon_name_text, (module_rect.left + 98, module_rect.top + 12), THEME_TEXT)
    _draw_text_shadow(screen, font, ammo_text, (module_rect.left + 98, module_rect.top + 38), (206, 218, 232))
    if active_weapon_reload:
        reload_text = _ellipsize_text(small_font, active_weapon_reload, max_text_width)
        _draw_text_shadow(screen, small_font, reload_text, (module_rect.left + 98, module_rect.top + 62), (255, 194, 130))

    slot_font = pygame.font.SysFont("consolas", 17)
    slot_line_y = module_rect.top + 88
    slot_step = 16
    slot_text_max_width = module_rect.width - 28
    for index, label in enumerate(slot_labels):
        color = (172, 200, 230) if "Fallback" in label else (186, 198, 214)
        safe_label = _ellipsize_text(slot_font, label, slot_text_max_width)
        _draw_text_shadow(screen, slot_font, safe_label, (module_rect.left + 14, slot_line_y + index * slot_step), color)

    effect_start_y = slot_line_y + len(slot_labels) * slot_step + 4
    max_effects = max(0, min(3, (module_rect.bottom - 12 - effect_start_y) // 18))
    for idx, effect in enumerate(active_effects[:max_effects]):
        is_temporary = (
            effect.startswith("Rapid Fire")
            or effect.startswith("Freeze")
            or effect.startswith("Ammo Cache")
            or effect.startswith("Fortify")
            or effect.startswith("Scrap Magnet")
        )
        color = (255, 224, 146) if is_temporary else (200, 210, 226)
        safe_effect = _ellipsize_text(small_font, effect, slot_text_max_width)
        _draw_text_shadow(screen, small_font, safe_effect, (module_rect.left + 14, effect_start_y + idx * 18), color)


def get_wave_banner_animation(remaining: float, duration: float) -> tuple[float, int]:
    """Return (scale, alpha) for wave banner animation timeline."""
    if duration <= 0:
        return 1.0, 255

    clamped_remaining = max(0.0, min(remaining, duration))
    progress = 1.0 - (clamped_remaining / duration)

    scale = 0.92 + (1.20 - 0.92) * progress

    if progress < 0.2:
        alpha = int(255 * (progress / 0.2))
    elif progress > 0.8:
        alpha = int(255 * ((1.0 - progress) / 0.2))
    else:
        alpha = 255

    return scale, max(0, min(alpha, 255))


def draw_wave_banner(
    screen: pygame.Surface,
    wave: int,
    remaining: float,
    duration: float,
    is_boss: bool = False,
    subtitle: str = "",
) -> None:
    """Draw short-lived center banner for current wave start."""
    scale, alpha = get_wave_banner_animation(remaining, duration)
    if alpha <= 0:
        return

    has_subtitle = bool(str(subtitle or "").strip())
    panel_height = 152 if has_subtitle else 130
    panel = pygame.Surface((540, panel_height), pygame.SRCALPHA)
    panel_color = (68, 24, 24, alpha) if is_boss else (30, 42, 58, alpha)
    border_color = (210, 90, 90, alpha) if is_boss else (156, 176, 210, alpha)
    pygame.draw.rect(panel, panel_color, panel.get_rect(), border_radius=18)
    pygame.draw.rect(panel, border_color, panel.get_rect(), 3, border_radius=18)
    panel_rect = panel.get_rect(center=(screen.get_width() // 2, screen.get_height() // 2 - 10))
    screen.blit(panel, panel_rect)

    big_font = pygame.font.SysFont("arial", 76, bold=True)
    subtitle_font = pygame.font.SysFont("consolas", 23, bold=True)
    if is_boss:
        title_surface = big_font.render(f"BOSS WAVE {wave}", True, (255, 135, 120))
    else:
        title_surface = big_font.render(f"WAVE {wave}", True, (220, 230, 248))

    scaled_width = max(1, int(title_surface.get_width() * scale))
    scaled_height = max(1, int(title_surface.get_height() * scale))
    scaled_surface = pygame.transform.smoothscale(title_surface, (scaled_width, scaled_height))
    scaled_surface.set_alpha(alpha)

    title_center_y = screen.get_height() // 2 - 10 + (10 if has_subtitle else 0)
    rect = scaled_surface.get_rect(center=(screen.get_width() // 2, title_center_y))
    screen.blit(scaled_surface, rect)

    if has_subtitle:
        subtitle_text = _ellipsize_text(subtitle_font, str(subtitle), panel.get_width() - 24)
        subtitle_surface = subtitle_font.render(subtitle_text, True, (255, 216, 158) if is_boss else (206, 222, 246))
        subtitle_surface.set_alpha(alpha)
        subtitle_rect = subtitle_surface.get_rect(center=(screen.get_width() // 2, panel_rect.top + 28))
        screen.blit(subtitle_surface, subtitle_rect)


def draw_armory_overlay(
    screen: pygame.Surface,
    width: int,
    height: int,
    current_wave: int,
    run_scrap: int,
    armory_tab: str,
    armory_rows: list[dict[str, object]],
    selected_index: int,
    row_offset: int = 0,
    max_visible_rows: int = 8,
    message: str = "",
) -> None:
    """Draw intermission armory with progressive unlock statuses."""
    backdrop = pygame.Surface((width, height), pygame.SRCALPHA)
    backdrop.fill((8, 10, 8, 165))
    screen.blit(backdrop, (0, 0))

    panel_rect = get_armory_panel_rect(width, height)
    _draw_panel(screen, panel_rect, alpha=230)

    title_font = pygame.font.SysFont("arial", 44, bold=True)
    body_font = pygame.font.SysFont("consolas", 20)
    small_font = pygame.font.SysFont("consolas", 18)

    title = title_font.render("Field Armory", True, THEME_ACCENT)
    summary = body_font.render(f"Wave {current_wave}   Scrap: {run_scrap}", True, THEME_TEXT)
    hint = small_font.render("LEFT/RIGHT tabs, UP/DOWN select, ENTER/click buy, TAB/ESC close", True, THEME_MUTED)
    screen.blit(title, title.get_rect(center=(panel_rect.centerx, panel_rect.top + 44)))
    screen.blit(summary, summary.get_rect(center=(panel_rect.centerx, panel_rect.top + 86)))
    screen.blit(hint, hint.get_rect(center=(panel_rect.centerx, panel_rect.top + 114)))

    tab_rects = get_armory_tab_rects(width)
    for key, rect in tab_rects.items():
        is_active = key == armory_tab
        fill = (84, 74, 58) if is_active else (52, 56, 68)
        border = (234, 194, 116) if is_active else (122, 132, 152)
        pygame.draw.rect(screen, fill, rect, border_radius=7)
        pygame.draw.rect(screen, border, rect, 2, border_radius=7)
        label = "Weapons" if key == "weapons" else "Upgrades"
        text = small_font.render(label, True, (236, 242, 248) if is_active else (194, 204, 220))
        screen.blit(text, text.get_rect(center=rect.center))

    explain_rect = pygame.Rect(panel_rect.left + 26, panel_rect.bottom - 84, panel_rect.width - 52, 48)

    if not armory_rows:
        empty = body_font.render("No armory actions available.", True, (188, 202, 214))
        screen.blit(empty, empty.get_rect(center=(panel_rect.centerx, panel_rect.top + 238)))
    else:
        safe_offset = max(0, int(row_offset))
        safe_visible = max(1, int(max_visible_rows))
        visible_rows = armory_rows[safe_offset : safe_offset + safe_visible]
        safe_index = min(max(0, int(selected_index)), len(armory_rows) - 1)
        last_visible_row_rect: pygame.Rect | None = None

        if safe_offset > 0:
            up_text = small_font.render("... more above ...", True, THEME_MUTED)
            screen.blit(up_text, up_text.get_rect(center=(panel_rect.centerx, panel_rect.top + 178)))

        for visible_idx, row in enumerate(visible_rows):
            row_index = safe_offset + visible_idx
            row_rect = get_armory_row_rect(width, visible_idx)
            enabled = bool(row.get("enabled", True))
            if row_index == selected_index:
                pygame.draw.rect(screen, (70, 70, 76), row_rect, border_radius=8)
                pygame.draw.rect(screen, (228, 190, 116), row_rect, 2, border_radius=8)
            last_visible_row_rect = row_rect

            name = str(row.get("name", "Unknown"))
            detail = str(row.get("detail", ""))
            status = str(row.get("status", ""))
            if row_index == selected_index:
                color = (240, 243, 248)
            elif enabled:
                color = (202, 212, 224)
            else:
                color = (149, 156, 170)

            inner_left = row_rect.left + 12
            inner_right = row_rect.right - 12
            name_x = row_rect.left + 14
            detail_x = row_rect.left + int(row_rect.width * 0.45)
            status_max_width = int(row_rect.width * 0.30)
            status_text = _ellipsize_text(body_font, status, status_max_width)
            status_surface = body_font.render(status_text, True, color)
            status_x = inner_right - status_surface.get_width()

            detail_width = max(60, status_x - detail_x - 12)
            detail_text = _ellipsize_text(body_font, detail, detail_width)
            detail_surface = body_font.render(detail_text, True, color)

            name_width = max(80, detail_x - name_x - 12)
            name_text = _ellipsize_text(body_font, name, name_width)
            name_surface = body_font.render(name_text, True, color)

            text_y = row_rect.centery - name_surface.get_height() // 2
            screen.blit(name_surface, (name_x, text_y))
            screen.blit(detail_surface, (detail_x, row_rect.centery - detail_surface.get_height() // 2))
            screen.blit(status_surface, (status_x, row_rect.centery - status_surface.get_height() // 2))

        if safe_offset + len(visible_rows) < len(armory_rows):
            down_text = small_font.render("... more below ...", True, THEME_MUTED)
            marker_y = panel_rect.bottom - 106
            if last_visible_row_rect is not None:
                marker_y = min(explain_rect.top - 16, last_visible_row_rect.bottom + 10)
            screen.blit(down_text, down_text.get_rect(center=(panel_rect.centerx, marker_y)))

        selected_row = armory_rows[safe_index]
        explain_text = str(selected_row.get("explain", "")).strip()
        if explain_text:
            _draw_panel(screen, explain_rect, alpha=214)
            explain_font = pygame.font.SysFont("consolas", 16)
            explain_lines = _wrap_text(explain_font, explain_text, explain_rect.width - 14, 2)
            line_step = explain_font.get_height() + 1
            for line_index, line in enumerate(explain_lines):
                y = explain_rect.top + 6 + line_index * line_step
                if y + explain_font.get_height() > explain_rect.bottom - 2:
                    break
                line_surface = explain_font.render(line, True, (214, 226, 238))
                screen.blit(line_surface, (explain_rect.left + 8, y))

    if message:
        msg_text = _ellipsize_text(small_font, message, panel_rect.width - 54)
        msg = small_font.render(msg_text, True, (255, 214, 136))
        screen.blit(msg, msg.get_rect(center=(panel_rect.centerx, panel_rect.bottom - 26)))


def draw_perk_draft_overlay(
    screen: pygame.Surface,
    width: int,
    height: int,
    choices: list[dict[str, object]],
    selected_index: int,
) -> None:
    """Draw perk draft cards shown at wave milestones."""
    backdrop = pygame.Surface((width, height), pygame.SRCALPHA)
    backdrop.fill((10, 8, 10, 188))
    screen.blit(backdrop, (0, 0))

    panel_rect = pygame.Rect(width // 2 - 380, height // 2 - 190, 760, 380)
    _draw_panel(screen, panel_rect, alpha=236)

    title_font = pygame.font.SysFont("arial", 42, bold=True)
    body_font = pygame.font.SysFont("consolas", 22)
    small_font = pygame.font.SysFont("consolas", 18)
    name_large_font = pygame.font.SysFont("consolas", 22)
    name_small_font = pygame.font.SysFont("consolas", 20)

    title = title_font.render("Mutation Choice", True, THEME_ACCENT)
    hint = small_font.render("LEFT/RIGHT pick, ENTER confirm, or click card", True, THEME_MUTED)
    screen.blit(title, title.get_rect(center=(width // 2, panel_rect.top + 48)))
    screen.blit(hint, hint.get_rect(center=(width // 2, panel_rect.top + 84)))

    if not choices:
        return

    card_rects = get_perk_card_rects(width, height, len(choices))
    for idx, choice in enumerate(choices):
        rect = card_rects[idx]
        fill = (84, 74, 58) if idx == selected_index else (52, 56, 68)
        border = (234, 194, 116) if idx == selected_index else (124, 136, 158)
        pygame.draw.rect(screen, fill, rect, border_radius=10)
        pygame.draw.rect(screen, border, rect, 2, border_radius=10)

        if bool(choice.get("is_active", False)):
            tag = small_font.render("ACTIVE", True, (255, 206, 128))
            screen.blit(tag, (rect.left + 12, rect.top + 12))

        text_width = rect.width - 24
        name_zone_top = rect.top + 50
        name_zone_height = 58
        desc_zone_top = name_zone_top + name_zone_height + 6
        desc_zone_bottom = rect.bottom - 12

        name_lines, font_token, _truncated = compute_perk_name_layout(str(choice.get("name", "Unknown")), text_width)
        name_font = name_small_font if font_token == "small" else name_large_font
        line_step = name_font.get_height() + 2
        name_block_height = len(name_lines) * line_step
        name_start_y = name_zone_top + max(0, (name_zone_height - name_block_height) // 2)

        for line_index, line in enumerate(name_lines):
            name_surface = name_font.render(line, True, (236, 242, 248))
            y = name_start_y + line_index * line_step
            if y + name_surface.get_height() > desc_zone_top:
                break
            screen.blit(name_surface, name_surface.get_rect(centerx=rect.centerx, y=y))

        desc_area_height = max(24, desc_zone_bottom - desc_zone_top)
        desc_step = small_font.get_height() + 2
        max_desc_lines = max(1, desc_area_height // desc_step)
        desc_lines = _wrap_text_strict(small_font, str(choice.get("description", "")), text_width)
        for line_index, line in enumerate(desc_lines[:max_desc_lines]):
            line_surface = small_font.render(line, True, (196, 206, 220))
            y = desc_zone_top + line_index * desc_step
            if y + line_surface.get_height() > desc_zone_bottom:
                break
            screen.blit(line_surface, line_surface.get_rect(centerx=rect.centerx, y=y))

    selected = choices[min(max(0, selected_index), len(choices) - 1)]
    detail_top = panel_rect.bottom + 10
    detail_height = min(88, max(56, height - detail_top - 10))
    detail_rect = pygame.Rect(width // 2 - 360, detail_top, 720, detail_height)
    if detail_rect.height >= 52:
        _draw_panel(screen, detail_rect, alpha=228)
        detail_font = pygame.font.SysFont("consolas", 17)
        detail_text = f"{selected.get('name', 'Unknown')}: {selected.get('description', '')}".strip()
        detail_lines = _wrap_text_strict(detail_font, detail_text, detail_rect.width - 20)
        line_step = detail_font.get_height() + 2
        max_lines = max(1, (detail_rect.height - 12) // line_step)
        for line_index, line in enumerate(detail_lines[:max_lines]):
            y = detail_rect.top + 6 + line_index * line_step
            screen.blit(detail_font.render(line, True, (214, 224, 238)), (detail_rect.left + 10, y))


def draw_mutation_drawer(
    screen: pygame.Surface,
    width: int,
    height: int,
    temporary_effects: list[str],
    perk_effects: list[str],
    scroll_offset: int = 0,
) -> None:
    """Draw a non-blocking left drawer listing all current run effects."""
    panel_rect = pygame.Rect(12, 124, 336, max(260, height - 144))
    panel_surface = pygame.Surface(panel_rect.size, pygame.SRCALPHA)
    panel_surface.fill((18, 24, 34, 220))
    pygame.draw.rect(panel_surface, (126, 146, 178, 228), panel_surface.get_rect(), 2, border_radius=10)
    screen.blit(panel_surface, panel_rect.topleft)

    title_font = pygame.font.SysFont("arial", 30, bold=True)
    body_font = pygame.font.SysFont("consolas", 18)
    small_font = pygame.font.SysFont("consolas", 16)

    title = title_font.render("Current Mutations", True, (230, 238, 248))
    subtitle = small_font.render("Temporary + permanent run effects", True, THEME_MUTED)
    screen.blit(title, title.get_rect(center=(panel_rect.centerx, panel_rect.top + 28)))
    screen.blit(subtitle, subtitle.get_rect(center=(panel_rect.centerx, panel_rect.top + 54)))

    y = panel_rect.top + 82
    section_temp = body_font.render("Temporary Effects", True, (255, 220, 146))
    screen.blit(section_temp, (panel_rect.left + 14, y))
    y += 26

    temp_lines = temporary_effects if temporary_effects else ["None active"]
    temp_color = (214, 224, 236) if temporary_effects else (146, 160, 178)
    line_width = panel_rect.width - 28
    line_step = small_font.get_height() + 2
    for line in temp_lines:
        wrapped = _wrap_text_strict(small_font, line, line_width)
        if not wrapped:
            wrapped = [line]
        for wrapped_line in wrapped:
            screen.blit(small_font.render(wrapped_line, True, temp_color), (panel_rect.left + 14, y))
            y += line_step

    y += 6
    section_perk = body_font.render("Mutations / Perks", True, (170, 214, 255))
    screen.blit(section_perk, (panel_rect.left + 14, y))
    y += 26

    perk_wrapped_lines: list[str] = []
    perk_lines = perk_effects if perk_effects else ["No permanent mutations selected."]
    for line in perk_lines:
        wrapped = _wrap_text_strict(small_font, line, line_width)
        if not wrapped:
            wrapped = [line]
        perk_wrapped_lines.extend(wrapped)
        perk_wrapped_lines.append("")
    if perk_wrapped_lines and perk_wrapped_lines[-1] == "":
        perk_wrapped_lines.pop()

    available_height = panel_rect.bottom - 36 - y
    max_rows = max(1, available_height // line_step)
    max_offset = max(0, len(perk_wrapped_lines) - max_rows)
    safe_offset = max(0, min(int(scroll_offset), max_offset))
    visible_lines = perk_wrapped_lines[safe_offset : safe_offset + max_rows]
    color = (206, 218, 232) if perk_effects else (146, 160, 178)
    for line in visible_lines:
        screen.blit(small_font.render(line, True, color), (panel_rect.left + 14, y))
        y += line_step

    if safe_offset > 0:
        up_text = small_font.render("... more above ...", True, (150, 166, 186))
        screen.blit(up_text, up_text.get_rect(center=(panel_rect.centerx, panel_rect.top + 78)))
    if safe_offset < max_offset:
        down_text = small_font.render("... more below ...", True, (150, 166, 186))
        screen.blit(down_text, down_text.get_rect(center=(panel_rect.centerx, panel_rect.bottom - 34)))

    scroll_hint = small_font.render("Wheel or PgUp/PgDn to scroll", True, (146, 160, 178))
    screen.blit(scroll_hint, scroll_hint.get_rect(center=(panel_rect.centerx, panel_rect.bottom - 16)))


def _draw_howto_icon(
    screen: pygame.Surface,
    rect: pygame.Rect,
    token: str,
    accent: tuple[int, int, int],
) -> None:
    """Draw one lightweight icon token for guide cards."""
    center = rect.center
    base_radius = max(9, min(rect.width, rect.height) // 2 - 2)
    pygame.draw.circle(screen, (42, 48, 62), center, base_radius + 2)
    pygame.draw.circle(screen, accent, center, base_radius, 2)

    if token == "keys":
        key_w = max(7, rect.width // 5)
        key_h = max(7, rect.height // 5)
        offsets = [(-key_w - 2, 2), (0, 2), (key_w + 2, 2), (0, -key_h - 2)]
        for dx, dy in offsets:
            key_rect = pygame.Rect(0, 0, key_w, key_h)
            key_rect.center = (center[0] + dx, center[1] + dy)
            pygame.draw.rect(screen, accent, key_rect, 2, border_radius=3)
        return

    if token == "hud":
        frame = rect.inflate(-10, -14)
        pygame.draw.rect(screen, accent, frame, 2, border_radius=4)
        pygame.draw.line(screen, accent, (frame.left + 4, frame.top + 8), (frame.right - 4, frame.top + 8), 2)
        pygame.draw.line(screen, accent, (frame.left + 4, frame.centery), (frame.right - 4, frame.centery), 2)
        return

    if token == "flow":
        left = (center[0] - 14, center[1])
        mid = (center[0], center[1])
        right = (center[0] + 14, center[1])
        pygame.draw.circle(screen, accent, left, 4)
        pygame.draw.circle(screen, accent, mid, 4)
        pygame.draw.circle(screen, accent, right, 4)
        pygame.draw.line(screen, accent, left, mid, 2)
        pygame.draw.line(screen, accent, mid, right, 2)
        return

    if token.startswith("boss_"):
        pygame.draw.circle(screen, accent, center, 10, 2)
        if token == "boss_ravager":
            pygame.draw.line(screen, accent, (center[0] - 12, center[1]), (center[0] + 12, center[1]), 3)
        elif token == "boss_broodlord":
            pygame.draw.circle(screen, accent, center, 15, 2)
        elif token == "boss_phantom":
            pygame.draw.arc(screen, accent, pygame.Rect(center[0] - 12, center[1] - 12, 24, 24), 0.3, 2.9, 3)
        elif token == "boss_zone_caster":
            pygame.draw.circle(screen, accent, center, 15, 2)
            pygame.draw.circle(screen, accent, center, 6, 2)
        elif token == "boss_stealth_assassin":
            points = [(center[0], center[1] - 13), (center[0] + 11, center[1]), (center[0], center[1] + 13), (center[0] - 11, center[1])]
            pygame.draw.polygon(screen, accent, points, 2)
        else:
            pygame.draw.circle(screen, accent, center, 16, 2)
        return

    if token.startswith("weapon:"):
        weapon_key = token.split(":", 1)[1]
        icon = pygame.transform.smoothscale(get_weapon_icon(weapon_key), (52, 26))
        icon_rect = icon.get_rect(center=center)
        screen.blit(icon, icon_rect.topleft)
        return

    if token == "ammo":
        pygame.draw.rect(screen, accent, (center[0] - 10, center[1] - 7, 20, 14), 2, border_radius=3)
        pygame.draw.line(screen, accent, (center[0] - 8, center[1]), (center[0] + 8, center[1]), 2)
        return

    if token == "power_temp":
        pygame.draw.line(screen, accent, (center[0] - 10, center[1]), (center[0] + 10, center[1]), 3)
        pygame.draw.line(screen, accent, (center[0], center[1] - 10), (center[0], center[1] + 10), 3)
        return

    if token == "power_defense":
        points = [(center[0], center[1] - 12), (center[0] + 11, center[1] - 2), (center[0] + 7, center[1] + 12), (center[0] - 7, center[1] + 12), (center[0] - 11, center[1] - 2)]
        pygame.draw.polygon(screen, accent, points, 2)
        return

    if token == "power_resource":
        pygame.draw.arc(screen, accent, pygame.Rect(center[0] - 12, center[1] - 12, 24, 24), 3.14, 6.2, 3)
        pygame.draw.rect(screen, accent, (center[0] - 12, center[1], 4, 8))
        pygame.draw.rect(screen, accent, (center[0] + 8, center[1], 4, 8))
        return

    if token == "perk":
        pygame.draw.circle(screen, accent, center, 11, 2)
        pygame.draw.circle(screen, accent, center, 4)
        return

    if token == "economy":
        pygame.draw.circle(screen, accent, center, 12, 2)
        pygame.draw.line(screen, accent, (center[0], center[1] - 8), (center[0], center[1] + 8), 2)
        pygame.draw.line(screen, accent, (center[0] - 4, center[1] - 4), (center[0] + 4, center[1] - 4), 2)
        pygame.draw.line(screen, accent, (center[0] - 4, center[1] + 4), (center[0] + 4, center[1] + 4), 2)
        return

    if token == "mutator":
        pygame.draw.circle(screen, accent, center, 12, 2)
        pygame.draw.circle(screen, accent, center, 6, 2)
        pygame.draw.line(screen, accent, (center[0] - 14, center[1]), (center[0] - 8, center[1]), 2)
        pygame.draw.line(screen, accent, (center[0] + 8, center[1]), (center[0] + 14, center[1]), 2)
        return

    pygame.draw.circle(screen, accent, center, 6)


def draw_howto_screen(
    screen: pygame.Surface,
    width: int,
    height: int,
    sections: list[dict[str, object]],
    *,
    selected_section_index: int = 0,
    scroll_offset: int = 0,
) -> int:
    """Render standalone visual guide and return clamped scroll offset."""
    safe_sections = list(sections)
    if not safe_sections:
        return 0

    safe_index = max(0, min(int(selected_section_index), len(safe_sections) - 1))
    section = safe_sections[safe_index]
    cards = list(section.get("cards", []))
    panel = get_howto_panel_rect(width, height)
    sidebar_width = max(166, min(236, panel.width // 3))
    content_left = panel.left + sidebar_width + 34
    content_width = panel.width - sidebar_width - 56

    backdrop = pygame.Surface((width, height), pygame.SRCALPHA)
    backdrop.fill((8, 11, 16, 186))
    screen.blit(backdrop, (0, 0))
    _draw_panel(screen, panel, alpha=240)

    title_font = pygame.font.SysFont("arial", 44, bold=True)
    subtitle_font = pygame.font.SysFont("consolas", 20)
    body_font = pygame.font.SysFont("consolas", 17)
    hint_font = pygame.font.SysFont("consolas", 16)

    title = title_font.render("How To Play", True, (236, 242, 248))
    subtitle = hint_font.render("Visual Guide", True, THEME_ACCENT)
    screen.blit(title, title.get_rect(midleft=(panel.left + 22, panel.top + 52)))
    screen.blit(subtitle, subtitle.get_rect(midleft=(panel.left + 24, panel.top + 80)))

    category_rects = get_howto_category_rects(width, height, len(safe_sections))
    for idx, rect in enumerate(category_rects):
        selected = idx == safe_index
        fill = (82, 74, 58) if selected else (50, 56, 68)
        border = (234, 194, 116) if selected else (120, 132, 154)
        pygame.draw.rect(screen, fill, rect, border_radius=7)
        pygame.draw.rect(screen, border, rect, 2, border_radius=7)
        text = _ellipsize_text(hint_font, str(safe_sections[idx].get("title", "Section")), rect.width - 16)
        label = hint_font.render(text, True, (238, 242, 248))
        screen.blit(label, label.get_rect(center=rect.center))

    section_title = subtitle_font.render(str(section.get("title", "")), True, (236, 242, 248))
    section_intro = _wrap_text_strict(hint_font, str(section.get("intro", "")), content_width - 12)
    section_title_y = panel.top + 66
    screen.blit(section_title, (content_left, section_title_y))

    intro_y = section_title_y + subtitle_font.get_height() + 4
    intro_step = hint_font.get_height() + 2
    visible_intro = section_intro[:2]
    for idx, line in enumerate(visible_intro):
        screen.blit(hint_font.render(line, True, (188, 202, 220)), (content_left, intro_y + idx * intro_step))

    content_top = intro_y + len(visible_intro) * intro_step + 12
    max_content_bottom = panel.bottom - 44
    if content_top > max_content_bottom - 80:
        content_top = max(panel.top + 112, max_content_bottom - 80)
    content_rect = pygame.Rect(content_left, content_top, content_width, max(80, max_content_bottom - content_top))

    line_step = body_font.get_height() + 3
    card_width = content_rect.width - 6
    card_heights: list[int] = []
    wrapped_cards: list[list[str]] = []
    for card in cards:
        bullets = list(card.get("bullets", []))
        wrapped: list[str] = []
        for bullet in bullets:
            for line in _wrap_text_strict(body_font, f"- {bullet}", card_width - 92):
                wrapped.append(line)
        wrapped_cards.append(wrapped)
        card_heights.append(max(84, 52 + len(wrapped) * line_step))

    total_cards_height = sum(card_heights) + max(0, len(cards) - 1) * 10
    max_scroll = max(0, total_cards_height - content_rect.height)
    safe_scroll = max(0, min(int(scroll_offset), max_scroll))

    clip_before = screen.get_clip()
    screen.set_clip(content_rect)
    draw_y = content_rect.top - safe_scroll
    for card_idx, card in enumerate(cards):
        card_rect = pygame.Rect(content_rect.left, draw_y, card_width, card_heights[card_idx])
        if card_rect.bottom >= content_rect.top and card_rect.top <= content_rect.bottom:
            accent = tuple(card.get("accent", (170, 196, 226)))
            if len(accent) != 3:
                accent = (170, 196, 226)
            pygame.draw.rect(screen, (44, 50, 62), card_rect, border_radius=8)
            pygame.draw.rect(screen, accent, card_rect, 2, border_radius=8)

            icon_rect = pygame.Rect(card_rect.left + 10, card_rect.top + 10, 56, 42)
            _draw_howto_icon(screen, icon_rect, str(card.get("icon", "")), accent)

            title_surface = hint_font.render(_ellipsize_text(hint_font, str(card.get("title", "")), card_rect.width - 82), True, (240, 244, 248))
            screen.blit(title_surface, (card_rect.left + 76, card_rect.top + 10))

            bullet_y = card_rect.top + 32
            for line in wrapped_cards[card_idx]:
                screen.blit(body_font.render(line, True, (206, 218, 232)), (card_rect.left + 76, bullet_y))
                bullet_y += line_step
                if bullet_y > card_rect.bottom - line_step:
                    break
        draw_y += card_heights[card_idx] + 10
    screen.set_clip(clip_before)

    footer_text = "UP/DOWN section, CLICK select, PGUP/PGDN scroll, ESC back"
    footer = hint_font.render(footer_text, True, THEME_MUTED)
    screen.blit(footer, footer.get_rect(center=(panel.centerx, panel.bottom - 24)))
    return safe_scroll


def draw_pause_overlay(
    screen: pygame.Surface,
    width: int,
    height: int,
    selected_index: int,
    *,
    settings_open: bool = False,
    settings_selected_index: int = 0,
    is_fullscreen: bool = False,
) -> None:
    """Draw pause menu or pause settings panel over gameplay."""
    backdrop = pygame.Surface((width, height), pygame.SRCALPHA)
    backdrop.fill((5, 7, 10, 168))
    screen.blit(backdrop, (0, 0))

    panel_rect = pygame.Rect(width // 2 - 230, height // 2 - 190, 460, 380)
    _draw_panel(screen, panel_rect, alpha=238)

    title_font = pygame.font.SysFont("arial", 50, bold=True)
    body_font = pygame.font.SysFont("consolas", 24)
    small_font = pygame.font.SysFont("consolas", 18)

    title = title_font.render("Paused", True, (236, 242, 248))
    screen.blit(title, title.get_rect(center=(panel_rect.centerx, panel_rect.top + 56)))

    if settings_open:
        subtitle = small_font.render("Settings", True, THEME_ACCENT)
        screen.blit(subtitle, subtitle.get_rect(center=(panel_rect.centerx, panel_rect.top + 96)))

        option_labels = [
            f"Toggle Fullscreen: {'ON' if is_fullscreen else 'OFF'}",
            "Back",
        ]
        for idx, rect in enumerate(get_pause_settings_option_rects(width, height)):
            selected = idx == settings_selected_index
            fill = (78, 72, 58) if selected else (52, 56, 68)
            border = (234, 194, 116) if selected else (126, 138, 160)
            pygame.draw.rect(screen, fill, rect, border_radius=8)
            pygame.draw.rect(screen, border, rect, 2, border_radius=8)
            text = body_font.render(option_labels[idx], True, (236, 242, 248))
            screen.blit(text, text.get_rect(center=rect.center))

        controls = small_font.render("UP/DOWN select, ENTER apply, ESC back", True, THEME_MUTED)
        screen.blit(controls, controls.get_rect(center=(panel_rect.centerx, panel_rect.bottom - 84)))
        hint = small_font.render("F11 and ALT+ENTER also toggle fullscreen.", True, (156, 172, 194))
        screen.blit(hint, hint.get_rect(center=(panel_rect.centerx, panel_rect.bottom - 56)))
        return

    option_labels = ["Resume", "How To Play", "Settings", "Quit to Menu"]
    for idx, rect in enumerate(get_pause_main_option_rects(width, height)):
        selected = idx == selected_index
        fill = (78, 72, 58) if selected else (52, 56, 68)
        border = (234, 194, 116) if selected else (126, 138, 160)
        pygame.draw.rect(screen, fill, rect, border_radius=8)
        pygame.draw.rect(screen, border, rect, 2, border_radius=8)
        text = body_font.render(option_labels[idx], True, (236, 242, 248))
        screen.blit(text, text.get_rect(center=rect.center))

    controls = small_font.render("UP/DOWN select, ENTER confirm, ESC resume", True, THEME_MUTED)
    controls_center_y = panel_rect.bottom - 28
    screen.blit(controls, controls.get_rect(center=(panel_rect.centerx, controls_center_y)))


def draw_game_over(
    screen: pygame.Surface,
    width: int,
    height: int,
    score: int,
    kills: int,
    survival_time: float,
    coins_earned_run: int,
) -> None:
    """Render game-over summary and restart/menu controls."""
    big_font = pygame.font.SysFont("arial", 54, bold=True)
    body_font = pygame.font.SysFont("arial", 30)

    title = big_font.render("GAME OVER", True, (255, 90, 90))
    stats = body_font.render(
        f"Score: {score} | Kills: {kills} | Time: {survival_time:0.1f}s | Coins +{coins_earned_run}",
        True,
        (240, 240, 240),
    )
    help_text = body_font.render("R = restart, M = menu, ESC = quit", True, (190, 190, 190))

    screen.blit(title, title.get_rect(center=(width // 2, height // 2 - 70)))
    screen.blit(stats, stats.get_rect(center=(width // 2, height // 2 - 10)))
    screen.blit(help_text, help_text.get_rect(center=(width // 2, height // 2 + 40)))

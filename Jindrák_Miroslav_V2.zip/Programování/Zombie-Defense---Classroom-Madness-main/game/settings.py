"""Local settings persistence for lightweight UX preferences."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

BASE_DIR = Path(__file__).resolve().parent.parent
SETTINGS_FILE = BASE_DIR / "game" / "settings.json"
_VISUAL_MODES = {"day", "night", "blackout"}


def _load_raw_settings(file_path: Path = SETTINGS_FILE) -> dict[str, Any]:
    """Load raw settings JSON object, returning empty dict on missing/corrupt data."""
    # Settings are best-effort; corrupted or missing files should never block startup.
    if not file_path.exists():
        return {}

    try:
        payload = json.loads(file_path.read_text(encoding="utf-8"))
    except json.JSONDecodeError:
        return {}

    if isinstance(payload, dict):
        return payload
    return {}


def load_last_player_name(file_path: Path = SETTINGS_FILE) -> str | None:
    """Return remembered login username (with legacy fallback) or None."""
    payload = _load_raw_settings(file_path)
    name = payload.get("last_login_username")
    if not isinstance(name, str):
        # Backward-compatibility with older settings key.
        name = payload.get("last_player_name")
    if not isinstance(name, str):
        return None

    clean_name = name.strip()
    return clean_name or None


def save_last_player_name(name: str, file_path: Path = SETTINGS_FILE) -> None:
    """Persist remembered login username if non-empty."""
    clean_name = name.strip()
    if not clean_name:
        return

    # Preserve other settings keys by updating existing payload in place.
    payload = _load_raw_settings(file_path)
    payload["last_login_username"] = clean_name

    file_path.parent.mkdir(parents=True, exist_ok=True)
    file_path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")


def load_visual_mode(file_path: Path = SETTINGS_FILE) -> str:
    """Return persisted visual mode with safe fallback."""
    payload = _load_raw_settings(file_path)
    mode = payload.get("visual_mode")
    if not isinstance(mode, str):
        return "night"

    normalized = mode.strip().lower()
    if normalized not in _VISUAL_MODES:
        return "night"
    return normalized


def save_visual_mode(mode: str, file_path: Path = SETTINGS_FILE) -> None:
    """Persist visual mode when value is supported."""
    normalized = str(mode).strip().lower()
    if normalized not in _VISUAL_MODES:
        normalized = "night"

    payload = _load_raw_settings(file_path)
    payload["visual_mode"] = normalized

    file_path.parent.mkdir(parents=True, exist_ok=True)
    file_path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")

﻿"""Power-up pickups and temporary combat modifiers."""

from __future__ import annotations

import random
from dataclasses import dataclass
from enum import Enum, auto

import pygame


class PowerUpType(Enum):
    """Supported power-up effects."""

    RAPID_FIRE = auto()
    HEAL_PACK = auto()
    FREEZE_BLAST = auto()
    AMMO_CACHE = auto()
    FORTIFY_FIELD = auto()
    SCRAP_MAGNET = auto()


@dataclass
class PowerUpPickup:
    """World pickup that expires if not collected."""

    kind: PowerUpType
    position: pygame.Vector2
    ttl: float = 8.0
    radius: int = 12


class PowerUpManager:
    """Spawns, updates and applies power-up effects."""

    def __init__(self, drop_chance: float = 0.12):
        """Initialize PowerUpManager runtime state."""
        self.drop_chance = drop_chance
        self.drop_chance_multiplier = 1.0
        self.pickups: list[PowerUpPickup] = []
        self.rapid_fire_remaining = 0.0
        self.freeze_remaining = 0.0
        self.fortify_remaining = 0.0
        self.scrap_magnet_remaining = 0.0
        self.ammo_cache_feedback_remaining = 0.0
        self.ammo_cache_feedback_text = ""

    def reset(self) -> None:
        """Clear all pickups and active timers."""
        self.pickups.clear()
        self.drop_chance_multiplier = 1.0
        self.rapid_fire_remaining = 0.0
        self.freeze_remaining = 0.0
        self.fortify_remaining = 0.0
        self.scrap_magnet_remaining = 0.0
        self.ammo_cache_feedback_remaining = 0.0
        self.ammo_cache_feedback_text = ""

    def update(self, dt: float) -> None:
        """Advance pickup lifetime and active effect timers."""
        # Expire pickups in place, then keep only still-valid world drops.
        for pickup in self.pickups:
            pickup.ttl -= dt
        self.pickups = [pickup for pickup in self.pickups if pickup.ttl > 0]

        self.rapid_fire_remaining = max(0.0, self.rapid_fire_remaining - dt)
        self.freeze_remaining = max(0.0, self.freeze_remaining - dt)
        self.fortify_remaining = max(0.0, self.fortify_remaining - dt)
        self.scrap_magnet_remaining = max(0.0, self.scrap_magnet_remaining - dt)
        self.ammo_cache_feedback_remaining = max(0.0, self.ammo_cache_feedback_remaining - dt)
        if self.ammo_cache_feedback_remaining == 0.0:
            self.ammo_cache_feedback_text = ""

    def maybe_spawn_drop(self, position: pygame.Vector2, ammo_pressure: float = 0.0) -> None:
        """Roll for a random drop at the given world position."""
        # Raise drop chance when ammo pressure is high to smooth difficulty spikes.
        scarcity = max(0.0, min(1.0, float(ammo_pressure)))
        chance_scale = 1.0 + scarcity * 0.35
        effective_drop_chance = max(
            0.0,
            min(0.95, float(self.drop_chance) * float(self.drop_chance_multiplier) * chance_scale),
        )
        if random.random() > effective_drop_chance:
            return

        ammo_weight = 0.10 + scarcity * 0.48
        kind = random.choices(
            [
                PowerUpType.RAPID_FIRE,
                PowerUpType.HEAL_PACK,
                PowerUpType.FREEZE_BLAST,
                PowerUpType.AMMO_CACHE,
                PowerUpType.FORTIFY_FIELD,
                PowerUpType.SCRAP_MAGNET,
            ],
            weights=[0.34, 0.24, 0.16, ammo_weight, 0.14, 0.12],
            k=1,
        )[0]
        self.pickups.append(PowerUpPickup(kind=kind, position=pygame.Vector2(position)))

    def collect_at_player(self, player) -> list[PowerUpType]:
        """Apply pickups intersecting player, returning collected kinds."""
        collected: list[PowerUpType] = []
        remaining: list[PowerUpPickup] = []

        # Split into collected/remaining lists so effects apply exactly once.
        for pickup in self.pickups:
            if pickup.position.distance_to(player.position) <= pickup.radius + player.radius:
                collected.append(pickup.kind)
                self._apply_effect(pickup.kind, player)
            else:
                remaining.append(pickup)

        self.pickups = remaining
        return collected

    def _apply_effect(self, kind: PowerUpType, player) -> None:
        """Apply one power-up effect bundle and refresh active multipliers."""
        if kind == PowerUpType.RAPID_FIRE:
            self.rapid_fire_remaining = max(self.rapid_fire_remaining, 6.0)
        elif kind == PowerUpType.HEAL_PACK:
            player.heal(25)
        elif kind == PowerUpType.FREEZE_BLAST:
            self.freeze_remaining = max(self.freeze_remaining, 4.0)
        elif kind == PowerUpType.FORTIFY_FIELD:
            self.fortify_remaining = max(self.fortify_remaining, 5.0)
        elif kind == PowerUpType.SCRAP_MAGNET:
            self.scrap_magnet_remaining = max(self.scrap_magnet_remaining, 7.0)
        elif kind == PowerUpType.AMMO_CACHE:
            return

    @property
    def shoot_cooldown_multiplier(self) -> float:
        """Multiplier for player shoot cooldown."""
        return 0.55 if self.rapid_fire_remaining > 0 else 1.0

    @property
    def zombie_speed_multiplier(self) -> float:
        """Multiplier for zombie movement speed."""
        return 0.35 if self.freeze_remaining > 0 else 1.0

    @property
    def incoming_damage_multiplier(self) -> float:
        """Multiplier for incoming player damage while temporary shield is active."""
        return 0.65 if self.fortify_remaining > 0 else 1.0

    @property
    def scrap_gain_multiplier(self) -> float:
        """Multiplier for run scrap gains while scrap magnet is active."""
        return 1.50 if self.scrap_magnet_remaining > 0 else 1.0

    def register_ammo_cache_feedback(self, text: str, duration: float = 2.2) -> None:
        """Show short-lived ammo-cache resolution feedback in HUD effect lines."""
        message = str(text).strip()
        if not message:
            return
        self.ammo_cache_feedback_text = message
        self.ammo_cache_feedback_remaining = max(float(self.ammo_cache_feedback_remaining), max(0.5, float(duration)))

    def active_effect_labels(self) -> list[str]:
        """Human-readable status labels for HUD."""
        labels: list[str] = []
        if self.rapid_fire_remaining > 0:
            labels.append(f"Rapid Fire {self.rapid_fire_remaining:0.1f}s")
        if self.freeze_remaining > 0:
            labels.append(f"Freeze {self.freeze_remaining:0.1f}s (zombies slowed)")
        if self.fortify_remaining > 0:
            labels.append(f"Fortify {self.fortify_remaining:0.1f}s (-35% incoming)")
        if self.scrap_magnet_remaining > 0:
            labels.append(f"Scrap Magnet {self.scrap_magnet_remaining:0.1f}s (+50% scrap)")
        if self.ammo_cache_feedback_remaining > 0 and self.ammo_cache_feedback_text:
            labels.append(self.ammo_cache_feedback_text)
        return labels

    @staticmethod
    def pickup_color(kind: PowerUpType) -> tuple[int, int, int]:
        """Return color tuple for a pickup kind identifier."""
        if kind == PowerUpType.RAPID_FIRE:
            return (255, 210, 70)
        if kind == PowerUpType.HEAL_PACK:
            return (80, 220, 120)
        if kind == PowerUpType.AMMO_CACHE:
            return (205, 205, 255)
        if kind == PowerUpType.FORTIFY_FIELD:
            return (255, 142, 108)
        if kind == PowerUpType.SCRAP_MAGNET:
            return (110, 236, 188)
        return (120, 200, 255)

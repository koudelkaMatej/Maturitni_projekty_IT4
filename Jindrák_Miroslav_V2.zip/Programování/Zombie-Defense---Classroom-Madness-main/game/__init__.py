"""Game package for Zombie Defense classroom project."""

# Package marker module intentionally kept minimal.

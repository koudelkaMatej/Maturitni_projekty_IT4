﻿"""Camera transform helpers for scrolling world rendering."""

from __future__ import annotations

import pygame


class Camera:
    """Convert between world and screen coordinates for a clamped camera."""

    def __init__(self, width: int, height: int, world_rect: pygame.Rect):
        """Initialize Camera runtime state."""
        self.width = width
        self.height = height
        self.world_rect = world_rect
        self.offset = pygame.Vector2(world_rect.left, world_rect.top)

    def update(self, target_world_pos: pygame.Vector2) -> None:
        """Center camera on target while staying inside world bounds."""
        desired_x = target_world_pos.x - self.width / 2
        desired_y = target_world_pos.y - self.height / 2

        max_x = self.world_rect.right - self.width
        max_y = self.world_rect.bottom - self.height

        # Handle worlds smaller than viewport by pinning to world origin.
        if max_x < self.world_rect.left:
            desired_x = self.world_rect.left
        else:
            desired_x = max(self.world_rect.left, min(desired_x, max_x))

        if max_y < self.world_rect.top:
            desired_y = self.world_rect.top
        else:
            desired_y = max(self.world_rect.top, min(desired_y, max_y))

        self.offset.update(desired_x, desired_y)

    def world_to_screen(self, world_pos: pygame.Vector2) -> pygame.Vector2:
        """Translate world-space position into screen-space position."""
        return pygame.Vector2(world_pos.x - self.offset.x, world_pos.y - self.offset.y)

    def screen_to_world(self, screen_pos: pygame.Vector2) -> pygame.Vector2:
        """Translate screen-space position into world-space position."""
        return pygame.Vector2(screen_pos.x + self.offset.x, screen_pos.y + self.offset.y)

    @property
    def view_rect(self) -> pygame.Rect:
        """Current camera viewport in world coordinates."""
        return pygame.Rect(int(self.offset.x), int(self.offset.y), self.width, self.height)

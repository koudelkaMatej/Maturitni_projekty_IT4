﻿"""Player entity for top-down zombie defense gameplay."""

from __future__ import annotations

import pygame


class Player:
    """Represents the controllable player circle and combat stats."""

    def __init__(self, x: float, y: float, speed: float = 280, radius: int = 18):
        """Initialize Player runtime state."""
        # Player position is stored in world-space coordinates.
        self.position = pygame.Vector2(x, y)
        self.speed = speed
        self.radius = radius

        # Health values are integer gameplay stats used by combat systems.
        self.max_health = 100
        self.health = self.max_health

        # Skin colors are runtime-overridable by shop/profile selection.
        self.color = (70, 160, 255)
        self.barrel_color = (220, 240, 255)

    def reset(self, x: float, y: float) -> None:
        """Reset position and health before a new run."""
        # Reset keeps existing cosmetics but restores spawn + full HP.
        self.position.update(x, y)
        self.health = self.max_health

    def update(
        self,
        dt: float,
        input_vector: pygame.Vector2,
        world_rect: pygame.Rect,
        speed_multiplier: float = 1.0,
    ) -> None:
        """Move player and clamp to world bounds."""
        # Normalize input so diagonal movement is not faster than straight movement.
        if input_vector.length_squared() > 0:
            input_vector = input_vector.normalize()
        self.position += input_vector * self.speed * max(0.0, float(speed_multiplier)) * dt

        # Keep full player body inside world bounds.
        self.position.x = max(world_rect.left + self.radius, min(self.position.x, world_rect.right - self.radius))
        self.position.y = max(world_rect.top + self.radius, min(self.position.y, world_rect.bottom - self.radius))

    def take_damage(self, amount: int) -> None:
        """Reduce health but never below zero."""
        # Health floor avoids negative values leaking into HUD/game-over checks.
        self.health = max(0, self.health - int(amount))

    def heal(self, amount: int) -> None:
        """Restore health up to max health."""
        # Healing is clamped so overheal is never possible.
        self.health = min(self.max_health, self.health + int(amount))

    def apply_skin(self, primary_color: tuple[int, int, int], secondary_color: tuple[int, int, int]) -> None:
        """Set cosmetic skin colors."""
        self.color = primary_color
        self.barrel_color = secondary_color

    @property
    def is_alive(self) -> bool:
        """Whether the player is still alive."""
        return self.health > 0

    def draw(self, screen: pygame.Surface, screen_position: pygame.Vector2 | None = None) -> None:
        """Render the player's body."""
        # Optional screen_position lets camera-space rendering reuse world entity code.
        position = screen_position or self.position
        pygame.draw.circle(screen, self.color, (int(position.x), int(position.y)), self.radius)

    def draw_barrel(
        self,
        screen: pygame.Surface,
        aim_direction: pygame.Vector2,
        screen_position: pygame.Vector2 | None = None,
    ) -> None:
        """Render simple weapon barrel aimed towards current direction."""
        position = screen_position or self.position
        # Fall back to facing right when no aim input is available.
        if aim_direction.length_squared() == 0:
            aim_direction = pygame.Vector2(1, 0)
        else:
            aim_direction = aim_direction.normalize()

        end_pos = position + aim_direction * (self.radius + 10)
        pygame.draw.line(
            screen,
            self.barrel_color,
            (int(position.x), int(position.y)),
            (int(end_pos.x), int(end_pos.y)),
            4,
        )

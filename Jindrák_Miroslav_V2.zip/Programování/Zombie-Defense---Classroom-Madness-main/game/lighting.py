﻿"""Lighting pass rendering for darkness and directional flashlight."""

from __future__ import annotations

import math

import pygame


def _normalized_direction(aim_direction: pygame.Vector2) -> pygame.Vector2:
    """Return a safe normalized aim direction."""
    # Default to +X when mouse is exactly on the player center.
    if aim_direction.length_squared() == 0:
        return pygame.Vector2(1, 0)
    return aim_direction.normalize()


def get_flashlight_cone_points(
    player_screen_pos: pygame.Vector2,
    aim_direction: pygame.Vector2,
    *,
    cone_length: int = 280,
    cone_angle_deg: float = 60,
) -> list[tuple[int, int]]:
    """Return polygon points describing the current flashlight cone."""
    # Build cone vertices around the aimed forward vector.
    direction = _normalized_direction(aim_direction)
    half_angle = math.radians(cone_angle_deg / 2)
    # Rotate around forward vector to get left/right cone edges.
    left_vec = direction.rotate_rad(-half_angle) * cone_length
    right_vec = direction.rotate_rad(half_angle) * cone_length
    forward = direction * cone_length

    tip = player_screen_pos + forward
    left = player_screen_pos + left_vec
    right = player_screen_pos + right_vec

    return [
        (int(player_screen_pos.x), int(player_screen_pos.y)),
        (int(left.x), int(left.y)),
        (int(tip.x), int(tip.y)),
        (int(right.x), int(right.y)),
    ]


def apply_cone_visibility_mask(
    source: pygame.Surface,
    cone_points: list[tuple[int, int]],
) -> pygame.Surface:
    """Keep only source pixels that fall inside the flashlight cone polygon."""
    # Multiply source alpha by a polygon mask to preserve only visible area.
    masked = source.copy()
    mask = pygame.Surface(source.get_size(), pygame.SRCALPHA)
    if cone_points:
        # White polygon keeps source alpha where the cone is visible.
        pygame.draw.polygon(mask, (255, 255, 255, 255), cone_points)
    masked.blit(mask, (0, 0), special_flags=pygame.BLEND_RGBA_MULT)
    return masked


def render_darkness_overlay(
    screen: pygame.Surface,
    player_screen_pos: pygame.Vector2,
    aim_direction: pygame.Vector2,
    cone_length: int = 280,
    cone_angle_deg: float = 60,
    darkness_alpha: int = 190,
) -> None:
    """Draw dark overlay and carve out only one hard-edged flashlight cone."""
    # Darkness pass draws once per frame and punches a transparent cone hole.
    overlay = pygame.Surface(screen.get_size(), pygame.SRCALPHA)
    overlay.fill((0, 0, 0, darkness_alpha))

    cone_points = get_flashlight_cone_points(
        player_screen_pos,
        aim_direction,
        cone_length=cone_length,
        cone_angle_deg=cone_angle_deg,
    )
    # Transparent polygon carves view space out of the darkness overlay.
    pygame.draw.polygon(overlay, (0, 0, 0, 0), cone_points)

    screen.blit(overlay, (0, 0))
